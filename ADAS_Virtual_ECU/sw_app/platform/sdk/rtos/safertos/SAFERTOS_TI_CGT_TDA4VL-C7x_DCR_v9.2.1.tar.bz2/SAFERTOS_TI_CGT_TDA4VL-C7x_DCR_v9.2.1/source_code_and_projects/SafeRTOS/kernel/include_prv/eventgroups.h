/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court, Long Ashton
    Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/


#ifndef EVENT_GROUPS_H
#define EVENT_GROUPS_H

#ifdef __cplusplus
extern "C" {
#endif

#include "eventGroupsAPI.h"
/*-----------------------------------------------------------------------------
 * Constants
 *---------------------------------------------------------------------------*/

/* The top 8 bits of the eventBitsType are used to hold control flags. */
#define evgrpCONTROL_FLAGS_SHIFT            ( portTICK_COUNT_NUM_BITS - 8U )

#define evgrpCLEAR_EVENTS_ON_EXIT_BIT       ( ( ( eventBitsType ) 0x01U << evgrpCONTROL_FLAGS_SHIFT ) )
#define evgrpUNBLOCKED_DUE_TO_BIT_SET       ( ( ( eventBitsType ) 0x02U << evgrpCONTROL_FLAGS_SHIFT ) )
#define evgrpWAIT_FOR_ALL_BITS              ( ( ( eventBitsType ) 0x04U << evgrpCONTROL_FLAGS_SHIFT ) )
#define evgrpUNBLOCKED_DUE_TO_DELETION      ( ( ( eventBitsType ) 0x08U << evgrpCONTROL_FLAGS_SHIFT ) )
#define evgrpEVENT_LIST_ITEM_VALUE_IN_USE   ( ( ( eventBitsType ) 0x80U << evgrpCONTROL_FLAGS_SHIFT ) )
#define evgrpEVENT_BITS_CONTROL_BYTES       ( ( ( eventBitsType ) 0xFFU << evgrpCONTROL_FLAGS_SHIFT ) )

/* Constant representing the case where no event bits are set. */
#define evgrpNO_EVENT_BITS_SET              ( ( eventBitsType ) 0 )


/*-----------------------------------------------------------------------------
 * Private API
 *---------------------------------------------------------------------------*/

/* Functions beyond this part are not part of the public API and are intended
 * for use by the kernel only. */

/* Tests the validity of the event group, returning pdTRUE if the event group
 * is valid, pdFALSE otherwise. */
KERNEL_FUNCTION portBaseType xEventGroupIsEventGroupHandleValid( const eventGroupType *pxEventGroup );

/*---------------------------------------------------------------------------*/


#ifdef __cplusplus
}
#endif

#endif /* EVENT_GROUPS_H */
