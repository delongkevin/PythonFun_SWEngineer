/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#ifndef SAFERTOS_CONFIG_H
#define SAFERTOS_CONFIG_H

#define configTICK_TIMER_ID             ( 2 )
#define configTICK_TIMER_INT_NUM        ( 16 )

#define configSEM_TIMER_ID              ( 3 )
#define configSEM_TIMER_INT_NUM         ( 17 )

#define configYIELD_INT_NUM             ( 14u )

/*--------------------------------------------------------------------------*/

#ifndef configMESSAGE_BUFFER_LENGTH_TYPE
    #define configMESSAGE_BUFFER_LENGTH_TYPE unsigned long
#endif
/*--------------------------------------------------------------------------*/

/* Number of Task priorities. */
#define configMAX_PRIORITIES            ( 16 )

/* Minimal size for Task's stacks. */
#define configMINIMAL_STACK_SIZE        ( 16 * 1024 )

/* System tick rate. */
#define configCPU_CLOCK_HZ              ( 1000 * 1000 * 1000 )
#define configSYSTICK_CLOCK_HZ          ( 19200000 )

#define configTICK_RATE_HZ              ( ( portTickType ) 1000UL )

/* This macro calculates the number of ticks per millisecond.
 * NOTE: This integer calculation is only correct for values of
 * configTICK_RATE_HZ less than or equal to 1000 that are also divisors
 * of 1000.
 */
#define configTICK_RATE_MS              ( ( portTickType ) 1000UL / configTICK_RATE_HZ )

/* Size of the Queue registry for use with the StateViewer plugin.
 * Set it to 0 to disable. */
#define configQUEUE_REGISTRY_SIZE       ( 0 )

/*
 * Section placement macros.
 */

#define configKERNEL_UNPRIV_FUNC_DEF
#define configKERNEL_FUNC_DEF           __attribute__ ( ( section ( ".KERNEL_FUNCTION" ) ) )
#define configKERNEL_INIT_FUNC_DEF      __attribute__ ( ( section ( ".KERNEL_FUNCTION" ) ) )
#define configKERNEL_CREATE_FUNC_DEF    __attribute__ ( ( section ( ".KERNEL_FUNCTION" ) ) )
#define configKERNEL_DELETE_FUNC_DEF    __attribute__ ( ( section ( ".KERNEL_FUNCTION" ) ) )
#define configKERNEL_DATA_DEF           __attribute__ ( ( section ( ".KERNEL_DATA" ) ) )
#define configKERNEL_DATA_MIRROR_DEF    __attribute__ ( ( section ( ".KERNEL_DATA" ) ) )

/* This defines the number of attempts the streambuffer code will attempt to gain
 * the lock on a StreamBuffer whilst in a critical section */
#define configMAX_SB_LOCK_ATTEMPTS      ( 20 )

/*
 * Feature inclusion macros.
 */
#define configINCLUDE_CRC_FEATURE       ( 0 )   /* Not yet supported. */

#endif /* SAFERTOS_CONFIG_H */
