/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#include <stdint.h>

/* Scheduler Includes */
#include "SafeRTOS_API.h"
#include "portable.h"
#include "task.h"
#include "mutex.h"
#include "evtmplx.h"
#include "list.h"

#include "c7x.h"

/*-----------------------------------------------------------------------------
 * Constant Definitions
 *---------------------------------------------------------------------------*/

/* Allowed ranges for clock and tick rate. */
#define portCPU_CLOCK_HZ_MIN                ( 1000000UL )
#define portTICK_RATE_HZ_MAX                ( 20000UL )

#define portNO_CRITICAL_SECTION_NESTING     ( ( portStackType ) 0x00UL )
#define portTSR_INITIAL_VALUE               ( 0x0000000000000003UL ) /* Exceptions & Interrupts enabled */

#define portROOT_SUPERVISOR_MODE            ( ( portStackType ) 3 )

/*-----------------------------------------------------------------------------
 * Public Port External Linker Variables
 *---------------------------------------------------------------------------*/

/* Region boundaries are imported from the linker command file. */

extern const portUInt64Type lnkStartFlashAddress;
extern const portUInt64Type lnkEndFlashAddress;


/*-----------------------------------------------------------------------------
 * Functions accessed from asm
 *---------------------------------------------------------------------------*/

KERNEL_FUNCTION void vPortControlCheckFailed( void );
KERNEL_FUNCTION void vPortSystemCallHookCheckFailed( void );

/*-----------------------------------------------------------------------------
 * Local Prototypes
 *---------------------------------------------------------------------------*/

/* Configures the TCB within the host application provided buffer. */
KERNEL_CREATE_FUNCTION static xTCB *prvSetupTCB( const xTaskParameters * const pxTaskParameters );

/* Ensure that the parameters passed by the application into the port layer are valid. */
KERNEL_INIT_FUNCTION static portBaseType prvCheckKernelConfiguration( void );

/* Sets the interrupt mask, keeping track of the critical nesting depth. */
void vPortEnterCritical( void );

/* Clears the interrupt mask, keeping track of the critical nesting depth. */
void vPortExitCritical( void );

/* MCDC Test Point: PROTOTYPE */

/* As this port is potentially able to be in ROM the user must pass in the
 * system timing parameters (normally constants from a config header file
 * are used. These are stored in the following variables ready for when
 * the scheduler is started. */
KERNEL_DATA static portUInt32Type       ulTimerClockHz = 0UL;
KERNEL_DATA static portUInt32Type       ulTickRateHz = 0UL;

/* Each task maintains its own interrupt status in the critical nesting
 * variable. This will get set to zero when the first task starts.
 * Note that this is global scope because it is accessed from portasm.asm. */
KERNEL_DATA volatile portUInt32Type ulCriticalNesting = 0UL;

/* Hook function passed in by the application software.
 * The hook function can be passed in as NULL with no adverse effect. */
KERNEL_DATA void *pvSystemCallHookFunction = NULL;

/* Hook mirror. */
KERNEL_DATA_MIRROR portCodeAddressType uxSCHookMirror = 0U;

/* The application defines whether any additional space should be
 * reserved on each task stack. */
KERNEL_DATA static portUnsignedBaseType uxAdditionalStackCheckMarginBytes = 0U;

/* Declare a TCB for the idle task. */
KERNEL_DATA static xTCB xIdleTaskTCB = { 0 };

/* The Portable Layer is responsible for the idle task parameters. */
KERNEL_DATA static xTaskParameters xIdleTaskParameters = { 0 };

/* Set to 1 to pend a context switch from an ISR. */
KERNEL_DATA portBaseType xPortYieldRequired = pdFALSE;

KERNEL_DATA portUnsignedBaseType uxPortYieldInterruptNum = 0U;
/*
 *  ======== Task_exit should never happen ========
 */
KERNEL_FUNCTION static void vPortTaskExit( void )
{
    /* MCDC Test Point: STD "vPortTaskExit" */
    vPortErrorHook( pxCurrentTCB, errDID_NOT_YIELD );
}
/*---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * Public function definitions
 *---------------------------------------------------------------------------*/

KERNEL_INIT_FUNCTION portBaseType xPortInitialize( const xPORT_INIT_PARAMETERS * const pxInitParameters )
{
    portBaseType xReturn;

    /* Ensure a NULL pointer hasn't been supplied. */
    if( NULL == pxInitParameters )
    {
        xReturn = errNULL_PARAMETER_SUPPLIED;
        /* MCDC Test Point: STD_IF "xPortInitialize" */
    }
    else
    {
        /* Interrupts are turned off in the CPU itself to ensure tick does
         * not execute    while the scheduler is being started.  Interrupts are
         * automatically turned back on in the CPU when the first task starts
         * executing.
         */
        portSET_INTERRUPT_MASK();

        xReturn = pdPASS;

        ulTimerClockHz = pxInitParameters->ulTimerClockHz;
        ulTickRateHz = pxInitParameters->ulTickRateHz;

        /* Enable yield interrupt using an intrinsic function call. */
        uxPortYieldInterruptNum = pxInitParameters->uxYieldInterruptNumber;
        __set_indexed( __EESET, 0, ( 1L << uxPortYieldInterruptNum ) );

        ulCriticalNesting = 0xAAAAAAAAUL;

        /* Store SVC hook and its mirror. */
        pvSystemCallHookFunction = pxInitParameters->pvSystemCallHookFunction;
        uxSCHookMirror = ~( ( portCodeAddressType ) pxInitParameters->pvSystemCallHookFunction );

        /* Each stack has a boundary. Prior to saving the context of a task to
         * the task stack the kernel will ensure that the boundary is far
         * enough away that the save process does not move the stack pointer
         * past the stack boundary.
         * The user can set uxAdditionalStackCheckMarginBytes to provide a
         * larger margin - such that the task will will check that there is
         * enough at least uxAdditionalStackCheckMarginBytes between the stack
         * pointer and the stack boundary once the task context has been saved.
         * If there is too little stack available then the error hook function
         * is called. */
        uxAdditionalStackCheckMarginBytes = pxInitParameters->uxAdditionalStackCheckMarginBytes;

        /* Initialise the Idle task TCB. */
        vPortSetWordAlignedBuffer( &xIdleTaskTCB, 0U, sizeof( xTCB ) );

        /* Initialise Idle task default parameters. */
        xIdleTaskParameters.pvTaskCode = &vIdleTask;
        xIdleTaskParameters.pcTaskName = "IDLE";
        xIdleTaskParameters.pxTCB = &xIdleTaskTCB;
        xIdleTaskParameters.pvParameters = NULL;
        xIdleTaskParameters.uxPriority = taskIDLE_PRIORITY;

        /* Initialise Idle task configurable parameters. */
        xIdleTaskParameters.pcStackBuffer = pxInitParameters->pcIdleTaskStackBuffer;
        xIdleTaskParameters.uxStackDepthBytes = pxInitParameters->uxIdleTaskStackSizeBytes;

        xIdleTaskParameters.pvObject = pxInitParameters->pvIdleTaskTLSObject;

        /* MCDC Test Point: STD_ELSE "xPortInitialize" */
    }

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_CREATE_FUNCTION portBaseType xPortCheckTaskParameters( const xTaskParameters * const pxTaskParameters )
{
    portBaseType xReturn = pdPASS;
    portUnsignedBaseType uxTaskStackBaseAddress = ( portUnsignedBaseType ) pxTaskParameters->pcStackBuffer;
    portUnsignedBaseType uxTaskStackSize = pxTaskParameters->uxStackDepthBytes;
    portUnsignedBaseType uxMinimumStackSize;

    /* The stack must be at least large enough to hold two lots of task context
     * registers. */
    uxMinimumStackSize = uxAdditionalStackCheckMarginBytes + ( 2U * portCONTEXT_SIZE_BYTES );
    if( uxTaskStackSize < uxMinimumStackSize )
    {
        xReturn = errSUPPLIED_BUFFER_TOO_SMALL;
        /* MCDC Test Point: STD_IF "xPortCheckTaskParameters" */
    }
    /* MCDC Test Point: ADD_ELSE "xPortCheckTaskParameters" */

    /* If the stack is large enough, check for alignment. */
    if( pdPASS == xReturn )
    {
        /* Is the stack size valid? */
        if( 0UL != ( uxTaskStackBaseAddress & portSTACK_ALIGNMENT_MASK ) )
        {
            /* The stack's base address is not aligned correctly. */
            xReturn = errINVALID_ALIGNMENT;

            /* MCDC Test Point: STD_IF "xPortCheckTaskParameters" */
        }
        else if( 0UL != ( uxTaskStackSize & portSTACK_ALIGNMENT_MASK ) )
        {
            /* The stack size is not a multiple of 32, which means the stack
             * doesn't end on an aligned address. */
            xReturn = errINVALID_BUFFER_SIZE;

            /* MCDC Test Point: STD_ELSE_IF "xPortCheckTaskParameters" */
        }
        else
        {
            /* MCDC Test Point: STD_ELSE "xPortCheckTaskParameters" */
        }
    }
    /* MCDC Test Point: ADD_ELSE "xPortCheckTaskParameters" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_CREATE_FUNCTION void vPortInitialiseTask( const xTaskParameters * const pxTaskParameters )
{
    xTCB *pxTCB;
    portStackType *pxTopOfStack;
    portDataAddressType xAlignedStackAddress;

    /* Configure the TCB associated with the task. */
    pxTCB = prvSetupTCB( pxTaskParameters );

    /* Cache the stack pointer. */
    xAlignedStackAddress = ( portDataAddressType ) pxTCB->pxTopOfStack;
    xAlignedStackAddress &= ( ~portWORD_ALIGNMENT_MASK ); /* align SP */

    pxTopOfStack = ( portStackType * ) xAlignedStackAddress;
    pxTopOfStack--;
    pxTopOfStack--;

/* 512 bit (64 byte) registers */
/* Streaming engine registers */
/*  SE1_3 ( offset 54 + 8*51 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  SE1_2 ( offset 54 + 8*50 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  SE1_1 ( offset 54 + 8*49 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;


/*  SE1_0 ( offset 54 + 8*48 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  SE0_3 ( offset 54 + 8*47 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  SE0_2 ( offset 54 + 8*46 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  SE0_1 ( offset 54 + 8*45 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  SE0_0 ( offset 54 + 8*44 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/* streaming address generator control registers */
/*  STRACR3 .VB0 + ( 54 + 8*43 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  STRACR2 .VB0 + ( 54 + 8*42 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  STRACR1 .VB0 + ( 54 + 8*41 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  STRACR0 .VB0 + ( 54 + 8*40 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/* streaming address generator counter registers */
/*  STRACNTR3( offset 54 + 8*39 ) */
    *pxTopOfStack = ( portStackType ) 0xC003030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;

/*  STRACNTR2( offset 54 + 8*38 ) */
    *pxTopOfStack = ( portStackType ) 0xC002020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;

/*  STRACNTR1( offset 54 + 8*37 ) */
    *pxTopOfStack = ( portStackType ) 0xC001010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;

/*  STRACNTR0( offset 54 + 8*36 ) */
    *pxTopOfStack = ( portStackType ) 0xC000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  .C unit Control Registers */
/*  CUCR3  ( offset 54 + 8*35 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  CUCR2  ( offset 54 + 8*34 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  CUCR1  ( offset 54 + 8*33 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  CUCR0  ( offset 54 + 8*32 ) */
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;


/*  VBM7   ( offset 54 + 8*31 ) */
    *pxTopOfStack = ( portStackType ) 0xB207070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;

/*  VBM6   ( offset 54 + 8*30 ) */
    *pxTopOfStack = ( portStackType ) 0xB206060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;

/*  VBM5   ( offset 54 + 8*29 ) */
    *pxTopOfStack = ( portStackType ) 0xB205050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;

/*  VBM4   ( offset 54 + 8*28 ) */
    *pxTopOfStack = ( portStackType ) 0xB204040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;

/*  VBM3   ( offset 54 + 8*27 ) */
    *pxTopOfStack = ( portStackType ) 0xB203030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;

/*  VBM2   ( offset 54 + 8*26 ) */
    *pxTopOfStack = ( portStackType ) 0xB202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;

/*  VBM1   ( offset 54 + 8*25 ) */
    *pxTopOfStack = ( portStackType ) 0xB201010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;

/*  VBM0   ( offset 54 + 8*24 ) */
    *pxTopOfStack = ( portStackType ) 0xB200000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/*  VBL7   ( offset 54 + 8*23 ) */
    *pxTopOfStack = ( portStackType ) 0xB107070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;

/*  VBL6   ( offset 54 + 8*22 ) */
    *pxTopOfStack = ( portStackType ) 0xB106060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;

/*  VBL5   ( offset 54 + 8*21 ) */
    *pxTopOfStack = ( portStackType ) 0xB105050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;

/*  VBL4   ( offset 54 + 8*20 ) */
    *pxTopOfStack = ( portStackType ) 0xB104040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;

/*  VBL3   ( offset 54 + 8*19 ) */
    *pxTopOfStack = ( portStackType ) 0xB103030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;

/*  VBL2   ( offset 54 + 8*18 ) */
    *pxTopOfStack = ( portStackType ) 0xB102020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;

/*  VBL1   ( offset 54 + 8*17 ) */
    *pxTopOfStack = ( portStackType ) 0xB101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;

/*  VBL0   ( offset 54 + 8*16 ) */
    *pxTopOfStack = ( portStackType ) 0xB100000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;


/*  VB15   ( offset 54 + 8*15 ) */
    *pxTopOfStack = ( portStackType ) 0xB015151515151515;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1515151515151515;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1515151515151515;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1515151515151515;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1515151515151515;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1515151515151515;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1515151515151515;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1515151515151515;
    pxTopOfStack--;

/*  VB14   ( offset 54 + 8*14 ) */
    *pxTopOfStack = ( portStackType ) 0xB014141414141414;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1414141414141414;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1414141414141414;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1414141414141414;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1414141414141414;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1414141414141414;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1414141414141414;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1414141414141414;
    pxTopOfStack--;

/*  VB13   ( offset 54 + 8*13 ) */
    *pxTopOfStack = ( portStackType )0xB013131313131313;
     pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1313131313131313;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1313131313131313;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1313131313131313;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1313131313131313;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1313131313131313;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1313131313131313;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1313131313131313;
    pxTopOfStack--;

/*  VB12   ( offset 54 + 8*12 ) */
    *pxTopOfStack = ( portStackType )0xB012121212121212;
     pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1212121212121212;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1212121212121212;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1212121212121212;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1212121212121212;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1212121212121212;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1212121212121212;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1212121212121212;
    pxTopOfStack--;

/*  VB11   ( offset 54 + 8*11 ) */
    *pxTopOfStack = ( portStackType ) 0xB011111111111111;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1111111111111111;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1111111111111111;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1111111111111111;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1111111111111111;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1111111111111111;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1111111111111111;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1111111111111111;
    pxTopOfStack--;

/*  VB10   ( offset 54 + 8*10 ) */
    *pxTopOfStack = ( portStackType ) 0xB010101010101010;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1010101010101010;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1010101010101010;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1010101010101010;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1010101010101010;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1010101010101010;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1010101010101010;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x1010101010101010;
    pxTopOfStack--;

/*  VB9    ( offset 54 + 8*9 ) */
    *pxTopOfStack = ( portStackType ) 0xB009090909090909;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0909090909090909;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0909090909090909;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0909090909090909;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0909090909090909;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0909090909090909;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0909090909090909;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0909090909090909;
    pxTopOfStack--;

/*  VB8    ( offset 54 + 8*8 ) */
    *pxTopOfStack = ( portStackType ) 0xB008080808080808;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0808080808080808;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0808080808080808;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0808080808080808;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0808080808080808;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0808080808080808;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0808080808080808;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0808080808080808;
    pxTopOfStack--;

/*  VB7    ( offset 54 + 8*7 ) */
    *pxTopOfStack = ( portStackType ) 0xB007070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0707070707070707;
    pxTopOfStack--;

/*  VB6    ( offset 54 + 8*6 ) */
    *pxTopOfStack = ( portStackType ) 0xB006060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0606060606060606;
    pxTopOfStack--;

/*  VB5    ( offset 54 + 8*5 ) */
    *pxTopOfStack = ( portStackType ) 0xB005050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0505050505050505;
    pxTopOfStack--;

/*  VB4    ( offset 54 + 8*4 ) */
    *pxTopOfStack = ( portStackType ) 0xB004040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0404040404040404;
    pxTopOfStack--;

/*  VB3    ( offset 54 + 8*3 ) */
    *pxTopOfStack = ( portStackType ) 0xB003030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0303030303030303;
    pxTopOfStack--;

/*  VB2    ( offset 54 + 8*2 ) */
    *pxTopOfStack = ( portStackType ) 0xB002020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0202020202020202;
    pxTopOfStack--;

/*  VB1    ( offset 54 + 8*1 ) */
    *pxTopOfStack = ( portStackType ) 0xB001010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0101010101010101;
    pxTopOfStack--;

/*  VB0   ( offset 54 ) */
    *pxTopOfStack = ( portStackType ) 0xB000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;
    pxTopOfStack--;

/* The following are double word registers */

    *pxTopOfStack = ( portStackType ) portROOT_SUPERVISOR_MODE;             /* RXMR - Return Execution Mode Register ( offset 53 ) */
    pxTopOfStack--;

    *pxTopOfStack = ( portStackType ) 0xF007070707070707;                   /* P7 - Predicate registers ( offset 52 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xF006060606060606;                   /* P6 ( offset 51 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xF005050505050505;                   /* P5 ( offset 50 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xF004040404040404;                   /* P4 ( offset 49 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xF003030303030303;                   /* P3 ( offset 48 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xF002020202020202;                   /* P2 ( offset 47 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xF001010101010101;                   /* P1 ( offset 46 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xF000000000000000;                   /* P0 ( offset 45 ) */
    pxTopOfStack--;

    *pxTopOfStack = ( portStackType ) __GPLY;                               /* GPLY - Galois polynomial register ( offset 44 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) __GFPGFR;                             /* GFPGFR - Galois field multiply control register ( offset 43 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0x0000000000000000;                   /* FSR - Flag Status Register ( offset 42 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) __FPCR;                               /* FPCR - Floating-point Configuration Register ( offset 41 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) pxTaskParameters->pvTaskCode;         /* RP - Return Pointer Register ( offset 40 ) */
    pxTopOfStack--;

    *pxTopOfStack = ( portStackType ) 0xD014141414141414;                   /* D14 ( offset 39 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD013131313131313;                   /* D13 ( offset 38 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD012121212121212;                   /* D12 ( offset 37 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD011111111111111;                   /* D11 ( offset 36 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD010101010101010;                   /* D10 ( offset 35 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD009090909090909;                   /* D9 ( offset 34 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD008080808080808;                   /* D8 ( offset 33 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD007070707070707;                   /* D7 ( offset 32 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD006060606060606;                   /* D6 ( offset 31 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD005050505050505;                   /* D5 ( offset 30 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD004040404040404;                   /* D4 ( offset 29 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD003030303030303;                   /* D3 ( offset 28 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD002020202020202;                   /* D2 ( offset 27 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD001010101010101;                   /* D1 ( offset 26 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xD000000000000000;                   /* D0 ( offset 25 ) */
    pxTopOfStack--;

    *pxTopOfStack = ( portStackType ) 0xA207070707070707;                   /* AM7 ( offset 24 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA206060606060606;                   /* AM6 ( offset 23 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA205050505050505;                   /* AM5 ( offset 22 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA204040404040404;                   /* AM4 ( offset 21 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA203030303030303;                   /* AM3 ( offset 20 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA202020202020202;                   /* AM2 ( offset 19 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA201010101010101;                   /* AM1 ( offset 18 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA200000000000000;                   /* AM0 ( offset 17 ) */
    pxTopOfStack--;

    *pxTopOfStack = ( portStackType ) 0xA107070707070707;                   /* AL7 ( offset 16 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA106060606060606;                   /* AL6 ( offset 15 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA105050505050505;                   /* AL5 ( offset 14 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA104040404040404;                   /* AL4 ( offset 13 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA103030303030303;                   /* AL3 ( offset 12 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA102020202020202;                   /* AL2 ( offset 11 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA101010101010101;                   /* AL1 ( offset 10 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA100000000000000;                   /* AL0 ( offset 9 ) */
    pxTopOfStack--;

    *pxTopOfStack = ( portStackType ) 0xA007070707070707;                   /* A7 ( offset 8 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA006060606060606;                   /* A6 ( offset 7 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA005050505050505;                   /* A5 ( offset 6 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) pxTaskParameters->pvParameters;       /* A4 ( offset 5 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA003030303030303;                   /* A3 ( offset 4 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA002020202020202;                   /* A2 ( offset 3 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA001010101010101;                   /* A1 ( offset 2 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA000000000000000;                   /* A0 ( offset 1 ) */
    pxTopOfStack--;

/* dword context offsets - never use 1 since 16 bytes need to remain free @SP */

    *pxTopOfStack = ( portStackType ) vPortTaskExit;                        /* Return address of task function ( context offset 15 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) portNO_CRITICAL_SECTION_NESTING;      /* CRITNEST_CNT - Critical nesting count ( context offset 14 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) __TSR;                                /* TSR - Task State Register ( context offset 13 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) __TCSP;                               /* TCSP - Task Context Save Pointer Register ( context offset 12 ) */
    pxTopOfStack--;

    *pxTopOfStack = ( portStackType ) 0xB015151515151515;                   /* B15 ? ( context offset 11 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xB014141414141414;                   /* B14 ? ( context offset 10 ) */
    pxTopOfStack--;

    *pxTopOfStack = ( portStackType ) 0xA015151515151515;                   /* A15 ( context offset 9 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA014141414141414;                   /* A14 ( context offset 8 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA013131313131313;                   /* A13 ( context offset 7 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA012121212121212;                   /* A12 ( context offset 6 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA011111111111111;                   /* A11 ( context offset 5 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA010101010101010;                   /* A10 ( context offset 4 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA009090909090909;                   /* A9 ( context offset 3 ) */
    pxTopOfStack--;
    *pxTopOfStack = ( portStackType ) 0xA008080808080808;                   /* A8 ( context offset 2 ) */
    pxTopOfStack--;
    pxTopOfStack--; /* for alignment */

    pxTCB->pxTopOfStack = pxTopOfStack;

    /* Update the Top of Stack and Top of Stack Mirror variables in the TCB
     * after the initial context has been placed on the stack. */
    pxTCB->uxTopOfStackMirror = ~( ( portDataAddressType ) pxTCB->pxTopOfStack );
    /* MCDC Test Point: STD "vPortInitialiseTask" */
}
/*---------------------------------------------------------------------------*/

KERNEL_INIT_FUNCTION portBaseType xPortStartScheduler( void )
{
    portBaseType xReturn = pdFALSE;

    xReturn = prvCheckKernelConfiguration();

    if( pdPASS == xReturn )
    {
        /* Create the idle task at the lowest priority. */
        xReturn = xTaskCreate( &xIdleTaskParameters, ( portTaskHandleType * ) NULL );

        /* MCDC Test Point: STD_IF "xPortStartScheduler" */
    }
    /* MCDC Test Point: ADD_ELSE "xPortStartScheduler" */

    /* If the idle task was created successfully, configure the system tick and start. */
    if( pdPASS == xReturn )
    {
        /* Start the timer that generates the tick ISR.
         * Interrupts are disabled here already. */
        vApplicationSetupTickInterruptHook( ulTimerClockHz,
                                            ulTickRateHz );

        /* Start the first task executing. */
        portSTART_FIRST_TASK();
        /* MCDC Test Point: STD_IF "xPortStartScheduler" */
    }
    /* MCDC Test Point: ADD_ELSE "xPortStartScheduler" */

    /* We will only reach here if prvCheckKernelConfiguration() fails or if the
     * idle task isn't created, otherwise the scheduler will be running. */
    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xPortIsTaskHandleValid( portTaskHandleType xTaskToCheck )
{
    portBaseType xReturn = pdTRUE;
    xTCB *pxTCB;

    /* First ensure we've not been given a NULL pointer to check. */
    if( NULL == xTaskToCheck )
    {
        xReturn = pdFALSE;

        /* MCDC Test Point: STD_IF "xPortIsTaskHandleValid" */
    }
    else
    {
        /* Set a pointer to the TCB buffer. */
        pxTCB = ( xTCB * )xTaskToCheck;

        if( ( portDataAddressType )( pxTCB->pxStackLimit ) != ~( pxTCB->uxStackLimitMirror ) )
        {
            /* The stack limit mirror is not as expected. */
            xReturn = pdFALSE;

            /* MCDC Test Point: STD_IF "xPortIsTaskHandleValid" */
        }
        else if( ( portDataAddressType )( pxTCB->pxTopOfStack ) != ~( pxTCB->uxTopOfStackMirror ) )
        {
            /* The top of stack mirror is not as expected. */
            xReturn = pdFALSE;
            /* MCDC Test Point: STD_ELSE_IF "xPortIsTaskHandleValid" */
        }
        else if( portSTACK_IN_USE != *( pxTCB->pxStackInUseMarker ) )
        {
            /* The pxStackInUseMarker is not as expected. */
            xReturn = pdFALSE;

            /* MCDC Test Point: STD_ELSE_IF "xPortIsTaskHandleValid" */
        }
        else
        {
            /* MCDC Test Point: STD_ELSE "xPortIsTaskHandleValid" */
        }
    }

    return xReturn;
}
/*---------------------------------------------------------------------------*/

/* Port specific helper function that will add any required port specific
 * declarations to a kernel task parameter structure. */
KERNEL_INIT_FUNCTION void vPortAddKernelTaskParams( xTaskParameters *pxKernelTaskParams )
{
    ( void )pxKernelTaskParams;
    /* MCDC Test Point: STD "vPortAddKernelTaskParams" */
}
/*---------------------------------------------------------------------------*/

void vPortRestoreKernelTaskPrivileges( void )
{
    /* Raise the privilege in case it has been reduced by application code. */
    /* MCDC Test Point: STD "vPortRestoreKernelTaskPrivileges" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION void vPortEnterCritical( void )
{
    ++ulCriticalNesting;
    portSET_INTERRUPT_MASK();
    /* MCDC Test Point: STD "vPortEnterCritical" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION void vPortExitCritical( void )
{
    if( 0UL != ulCriticalNesting )
    {
        /* MCDC Test Point: STD_IF "vPortExitCritical" */
        --ulCriticalNesting;
        if( 0UL == ulCriticalNesting )
        {
            portCLEAR_INTERRUPT_MASK();
            /* MCDC Test Point: STD_IF "vPortExitCritical" */
        }
        /* MCDC Test Point: ADD_ELSE "vPortExitCritical" */
    }
    /* MCDC Test Point: ADD_ELSE "vPortExitCritical" */
}
/*---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * Kernel Hook Functions
 *---------------------------------------------------------------------------*/

KERNEL_FUNCTION void vPortErrorHook( portTaskHandleType xHandleOfTaskWithError,
                                     portBaseType xErrorCode )
{
    /* MCDC Test Point: STD "vPortErrorHook" */

    /* Call the application defined error hook. */
    vApplicationErrorHook( xHandleOfTaskWithError, xErrorCode );
}
/*---------------------------------------------------------------------------*/

KERNEL_DELETE_FUNCTION void vPortTaskDeleteHook( portTaskHandleType xTaskBeingDeleted )
{
    /* MCDC Test Point: STD "vPortTaskDeleteHook" */

    /* Call the application defined Task-Delete hook function. */
    vApplicationTaskDeleteHook( xTaskBeingDeleted );
}
/*---------------------------------------------------------------------------*/

KERNEL_UNPRIV_FUNCTION void vPortIdleHook( void )
{
    /* MCDC Test Point: STD "vPortIdleHook" */

    /* Call the application defined Idle hook function. */
    vApplicationIdleHook();
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION void vPortTickHook( void )
{
    /* MCDC Test Point: STD "vPortTickHook" */

    /* Call the application defined Tick hook function. */
    vApplicationTickHook();
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION void vPortControlCheckFailed( void )
{
    /* MCDC Test Point: STD "vPortControlCheckFailed" */
    vPortErrorHook( pxCurrentTCB,
                    errINVALID_TASK_SELECTED );
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION void vPortSystemCallHookCheckFailed( void )
{
    /* MCDC Test Point: STD "vPortSystemCallHookCheckFailed" */
    vPortErrorHook( NULL,
                    errBAD_HOOK_FUNCTION_ADDRESS );
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xPortCopyBytes( void *pvDestination,
                                             const void *pvSource,
                                             portUnsignedBaseType uxLength )
{
    const portUInt8Type *pucSourceBytes = ( const portUInt8Type * ) pvSource;
    portUInt8Type *pucDestBytes = ( portUInt8Type * ) pvDestination;
    portUnsignedBaseType uxBitMask;

    uxBitMask = ( ( portUnsignedBaseType ) pvDestination ) | ( ( portUnsignedBaseType ) pvSource ) | uxLength;
    uxBitMask &= ( sizeof( portUnsignedBaseType ) - 1U );

    if( 0U != uxBitMask )
    {
        /* Copy bytes. */
        /* MCDC Test Point: WHILE_EXTERNAL "vPortCopyBytes" "( 0U != uxLength )" */
        while( 0U != uxLength )
        {
            uxLength--;
            *( ( portUInt8Type * )( pucDestBytes + uxLength ) ) = *( ( const portUInt8Type * )( pucSourceBytes + uxLength ) );
            /* MCDC Test Point: WHILE_INTERNAL "vPortCopyBytes" "( 0U != uxLength )" */
        }
        /* MCDC Test Point: STD_IF "vPortCopyBytes" */
    }
    else
    {
        /* Copy words. */
        /* MCDC Test Point: WHILE_EXTERNAL "vPortCopyBytes" "( 0U != uxLength )" */
        while( 0U != uxLength )
        {
            uxLength -= sizeof( portUnsignedBaseType );
            *( ( portUnsignedBaseType * )( pucDestBytes + uxLength ) ) = *( ( const portUnsignedBaseType * )( pucSourceBytes + uxLength ) );
            /* MCDC Test Point: WHILE_INTERNAL "vPortCopyBytes" "( 0U != uxLength )" */
        }
        /* MCDC Test Point: STD_ELSE "vPortCopyBytes" */
    }
    return pdPASS;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION void vPortSetWordAlignedBuffer( void *pvDestination,
                                                portUInt64Type ulValue,
                                                portUnsignedBaseType uxLength )
{
    portUInt8Type *pucDestBytes = ( portUInt8Type * ) pvDestination;

    do
    {
        uxLength -= sizeof( portUnsignedBaseType );
        *( ( portUnsignedBaseType * )( pucDestBytes + uxLength ) ) = ulValue;

        /* MCDC Test Point: WHILE_INTERNAL "vPortSetWordAlignedBuffer" "( 0U != uxLength )" */
    } while( 0U != uxLength );
}
/*---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
 * Filescope functions
 *---------------------------------------------------------------------------*/

KERNEL_CREATE_FUNCTION static xTCB *prvSetupTCB( const xTaskParameters *const pxTaskParameters )
{
    xTCB *pxNewTCB;
    portInt8Type *pcTopOfStack;
    portUnsignedBaseType uxStackDepthBytes;
    portDataAddressType uxOffset;
    portInt8Type *pcMaxStack;

    /* Set a pointer to the TCB buffer. */
    pxNewTCB = pxTaskParameters->pxTCB;

    /* Store the base address of the task's stack buffer. */
    pxNewTCB->pcStackBaseAddress = pxTaskParameters->pcStackBuffer;

    /* Calculate the top of stack address. */
    uxStackDepthBytes = pxTaskParameters->uxStackDepthBytes & ~portSTACK_ALIGNMENT_MASK;
    pcTopOfStack = pxTaskParameters->pcStackBuffer + ( uxStackDepthBytes - sizeof( portStackType ) );
    vPortSetWordAlignedBuffer( pxNewTCB->pcStackBaseAddress,
                               0xFFFFFFFFFFFFFFFFU,
                               uxStackDepthBytes );

    /* Set the 'StackInUse' and 'Top of Stack' pointers ensuring correct
     * alignment. */
    pxNewTCB->pxStackInUseMarker = ( portStackType * ) pcTopOfStack;
    pxNewTCB->pxTopOfStack = ( portStackType * )( ( ( portDataAddressType ) pcTopOfStack -
                                                      sizeof( portStackType ) ) &
                                                  ~portSTACK_ALIGNMENT_MASK );

    /* Calculate the stack limit - this is the minimum amount of space required
     * on the task stack for the context switch. */
    pcMaxStack = ( pxTaskParameters->pcStackBuffer +
                   portCONTEXT_SIZE_BYTES +
                   uxAdditionalStackCheckMarginBytes );

    /* The stack limit must be 8-byte aligned as the processor forces the SP to
     * the next 8-byte boundary on entry to an exception handler. */
    uxOffset = ( ( portDataAddressType ) pcMaxStack & portSTACK_ALIGNMENT_MASK );
    if( 0U != uxOffset )
    {
        pcMaxStack += ( safertosapiSTACK_ALIGNMENT - uxOffset );
        /* MCDC Test Point: STD_IF "prvSetupTCB" */
    }
    /* MCDC Test Point: ADD_ELSE "prvSetupTCB" */

    /* Store the stack limit in the TCB. */
    pxNewTCB->pxStackLimit = ( portStackType * ) pcMaxStack;

    /* Set uxStackLimitMirror to the bitwise inverse of pxStackLimit. */
    pxNewTCB->uxStackLimitMirror = ~( ( portDataAddressType ) pxNewTCB->pxStackLimit );

    /* Setup the TCB. */
    pxNewTCB->uxPriority = pxTaskParameters->uxPriority;
    pxNewTCB->uxBasePriority = pxTaskParameters->uxPriority;
    pxNewTCB->pcNameOfTask = pxTaskParameters->pcTaskName;
    vListInitialiseItem( &( pxNewTCB->xStateListItem ) );
    vListInitialiseItem( &( pxNewTCB->xEventListItem ) );

    /* Set the pxTCB as a link back from the xListItem. This is so we can get
     * back to the containing TCB from a generic item in a list. */
    listSET_LIST_ITEM_OWNER( &( pxNewTCB->xStateListItem ), pxNewTCB );

    /* Tasks are stored within event lists such that the list references tasks
     * in priority order - high priority to low priority. The ItemValue is used
     * to hold the priority in this case - but because ordered lists actually
     * sort themselves so that low values come before high values, the priority
     * assigned to the ItemValue has to be inverted. Thus high priority tasks
     * get a low ItemValue value, and low priority tasks get a high ItemValue
     * value. */
    listSET_LIST_ITEM_VALUE( &( pxNewTCB->xEventListItem ),
                             ( portTickType )( configMAX_PRIORITIES - pxTaskParameters->uxPriority ) );
    listSET_LIST_ITEM_OWNER( &( pxNewTCB->xEventListItem ), pxNewTCB );

    /* Initialise notification parameters. */
    pxNewTCB->uxNotifiedValue = 0U;
    pxNewTCB->xNotifyState = taskNOTIFICATION_NOT_WAITING;

    /* Initialise TLS Object. */
    pxNewTCB->pvObject = pxTaskParameters->pvObject;

    /* Initialise the mutexes held list. */
    vMutexInitHeldList( pxNewTCB );

    /* Initialise the list of evt mplx objects owned by this task if event
     * multiplex is included. */
    vEvtMplxInitTaskEvtMplxObjects( pxNewTCB );

    return pxNewTCB;
}
/*---------------------------------------------------------------------------*/

KERNEL_INIT_FUNCTION static portBaseType prvCheckKernelConfiguration( void )
{
    portBaseType xReturn = pdFAIL;

    /* NOTE: the Flash does not start at 0, so we  check against the upper and lower limit. */
    const portCodeAddressType uxUsedFlashLowerLimit = ( portCodeAddressType ) &lnkStartFlashAddress;
    const portCodeAddressType uxUsedFlashUpperLimit = ( portCodeAddressType ) &lnkEndFlashAddress;

    /* Perform the required checks. */
    /* MCDC Test Point: EXP_IF_AND "prvCheckKernelConfiguration" �( NULL != pvSystemCallHookFunction )� "( pvSystemCallHookFunction < uxUsedFlashLowerLimit )� */
    /* MCDC Test Point: EXP_IF_AND "prvCheckKernelConfiguration" "( NULL != pvSystemCallHookFunction )� �( pvSystemCallHookFunction >= uxUsedFlashUpperLimit )� */
    if( 0UL == ulTickRateHz )
    {
        xReturn = errBAD_OR_NO_TICK_RATE_CONFIGURATION;
        /* MCDC Test Point: STD_IF "prvCheckKernelConfiguration" */
    }
    else if( ulTickRateHz > portTICK_RATE_HZ_MAX )
    {
        xReturn = errBAD_OR_NO_TICK_RATE_CONFIGURATION;
        /* MCDC Test Point: STD_ELSE_IF "prvCheckKernelConfiguration" */
    }
    else if( ( NULL != pvSystemCallHookFunction ) &&
             ( ( portCodeAddressType ) pvSystemCallHookFunction < uxUsedFlashLowerLimit ) )
    {
        /* Note that the system call hook is allowed to be NULL but, if defined,
         * it must be within the Flash range. */
        xReturn = errBAD_HOOK_FUNCTION_ADDRESS;
        /* MCDC Test Point: STD_ELSE_IF "prvCheckKernelConfiguration" */
    }
    else if( ( NULL != pvSystemCallHookFunction ) &&
             ( ( portCodeAddressType ) pvSystemCallHookFunction >= uxUsedFlashUpperLimit ) )
    {
        /* Note that the system call hook is allowed to be NULL but, if defined,
         * it must be within the Flash range. */
        xReturn = errBAD_HOOK_FUNCTION_ADDRESS;
        /* MCDC Test Point: STD_ELSE_IF "prvCheckKernelConfiguration" */
    }
    else
    {
        xReturn = pdPASS;

        /* MCDC Test Point: STD_ELSE "prvCheckKernelConfiguration" */
    }

    return xReturn;
}
/*---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
 * Overridable Hook Functions
 *---------------------------------------------------------------------------*/

KERNEL_UNPRIV_FUNCTION portWEAK_FUNCTION void vApplicationIdleHook( void )
{
    /* MCDC Test Point: STD "vApplicationIdleHook" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION void vApplicationTickHook( void )
{
    /* MCDC Test Point: STD "vApplicationTickHook" */
}
/*---------------------------------------------------------------------------*/

KERNEL_DELETE_FUNCTION portWEAK_FUNCTION void vApplicationTaskDeleteHook( portTaskHandleType xTaskBeingDeleted )
{
    ( void ) xTaskBeingDeleted;

    /* MCDC Test Point: STD "vApplicationTaskDeleteHook" */
}
/*---------------------------------------------------------------------------*/


