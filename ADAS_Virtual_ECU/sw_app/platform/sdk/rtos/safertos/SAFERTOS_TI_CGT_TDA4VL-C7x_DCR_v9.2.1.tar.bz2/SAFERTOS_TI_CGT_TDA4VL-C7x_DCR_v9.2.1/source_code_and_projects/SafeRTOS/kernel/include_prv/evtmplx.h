/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organizzation,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court, Long Ashton
    Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/


#ifndef EVT_MPLX_H
#define EVT_MPLX_H

#ifdef __cplusplus
extern "C" {
#endif

#include "evtmplxAPI.h"
#include "eventgroups.h"

/* This constant should not be used directly by the user application.
 * Its purpose is to allow a call to xEvtMplxWaitKrnl() to unblock if an event
 * group associated with the event multiplex object is deleted while the task is
 * blocking. */
#define evtmplxEVENT_GROUP_DELETED            ( ( portUnsignedBaseType ) 0x80000000U )

/*-----------------------------------------------------------------------------
 * Private API
 *---------------------------------------------------------------------------*/
KERNEL_DELETE_FUNCTION void vEvtMplxTaskDeleted( xTCB *pxTCB );

/* Function that updates all registered event multiplex objects whenever task
 * notifications are sent or retrieved. */
KERNEL_FUNCTION portBaseType xEvtMplxUpdateTaskEvtMplxObjects( const xTCB *pxTCB, portUnsignedBaseType uxCurrentStatus );

/* Function that updates all registered event multiplex objects whenever messages are
 * sent or received on a queue. */
KERNEL_FUNCTION portBaseType xEvtMplxUpdateQueueEvtMplxObjects( const xQUEUE *const pxQueue );

/* Updates all registered event multiplex objects whenever event group bits are set
 * or cleared. */
KERNEL_FUNCTION portBaseType xEvtMplxUpdateEventGroupEvtMplxObjects( const eventGroupType *pxEventGroup );

/* Informs all registered event multiplex objects that the event group has been
 * deleted. */
KERNEL_DELETE_FUNCTION portBaseType xEvtMplxRemoveEventGroupEvtMplxObjects( const eventGroupType *pxEventGroup );

/* Initialise event multiplex object lists */
KERNEL_FUNCTION void vEvtMplxInitQueueEvtMplxObjects( xQUEUE *const pxQueue );
KERNEL_FUNCTION void vEvtMplxInitTaskEvtMplxObjects( xTCB *const pxTCB );
KERNEL_FUNCTION void vEvtMplxInitEventGroupEvtMplxObjects( eventGroupType *pxEventGroup );

/*---------------------------------------------------------------------------*/


#ifdef __cplusplus
}
#endif

#endif /* EVT_MPLX_H */
