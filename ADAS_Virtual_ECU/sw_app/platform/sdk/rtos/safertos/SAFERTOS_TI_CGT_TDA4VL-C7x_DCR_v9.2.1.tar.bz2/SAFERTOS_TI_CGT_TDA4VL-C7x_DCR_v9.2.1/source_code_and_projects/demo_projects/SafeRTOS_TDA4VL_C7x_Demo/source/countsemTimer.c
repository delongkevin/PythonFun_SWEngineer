/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

/*-----------------------------------------------------------------------------
 * Counting Semaphore Timer Initialisation and Configuration Function.
 *---------------------------------------------------------------------------*/

/* Scheduler include files. */
#include "SafeRTOS_API.h"
#include <stdio.h>
#include "countsem.h"
#include "countsemTimer.h"
#include "PortSpecifics.h"
#include "ti/osal/TimerP.h"
#include "ti/osal/DebugP.h"
#include "Hwi.h"

TimerP_Handle pCntSemTimHandle = NULL;
void vSafeDemoRtiTickHandler( uintptr_t arg );
void vPortInitTimerCLECCfg( portUInt32Type ulTimerId, portUInt32Type ulTimerIntNum );

/*-----------------------------------------------------------------------------
 * Counting Semaphore TI PDK ISR Timer Initialisation
 *---------------------------------------------------------------------------*/
void vCountSemTimerInit( void )
{
    TimerP_Params xTimerParams;

    vPortInitTimerCLECCfg( configSEM_TIMER_ID,
                           configSEM_TIMER_INT_NUM );

    TimerP_Params_init( &xTimerParams );
    xTimerParams.runMode    = TimerP_RunMode_CONTINUOUS;
    xTimerParams.startMode  = TimerP_StartMode_AUTO;
    xTimerParams.periodType = TimerP_PeriodType_MICROSECS;
    xTimerParams.period     = ( 1000000UL / countsemCOUNTSEM_ISR_TIMER_FREQUENCY );
    xTimerParams.intNum     = configSEM_TIMER_INT_NUM;

    pCntSemTimHandle = TimerP_create( configSEM_TIMER_ID,
                                      &vSafeDemoRtiTickHandler,
                                      &xTimerParams );
    /* don't expect the handle to be null */
    DebugP_assert ( pCntSemTimHandle != NULL );
}
/*---------------------------------------------------------------------------*/

/* Tick timer interrupt handler corresponding to TI PDK library prototype. */
void vSafeDemoRtiTickHandler( uintptr_t arg )
{
    volatile portFloat32Type fTimerValueA;
    volatile portFloat32Type fTimerValueB;
    volatile portFloat32Type fTimerValueC;
    volatile portFloat32Type fTimerAnswer;

    ( void ) arg;
    {
        /* Execute some basic floating point maths. */
        fTimerValueA = -56.93F;
        fTimerValueB = 530.2F;
        fTimerValueC = -2.045F;
        fTimerAnswer = ( ( fTimerValueA / fTimerValueB ) * fTimerValueC );

        /* Call the counting semaphore demo timer ISR. */
        vCountingSemaphoreTimerHandler();

        /* Context switch if needed. */
        safertosapiYIELD_FROM_ISR();
    }
}
/*---------------------------------------------------------------------------*/
