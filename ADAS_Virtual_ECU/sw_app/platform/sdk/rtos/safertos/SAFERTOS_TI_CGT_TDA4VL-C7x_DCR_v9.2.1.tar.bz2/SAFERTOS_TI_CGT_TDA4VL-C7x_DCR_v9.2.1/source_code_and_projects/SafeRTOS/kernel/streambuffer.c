/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

/* SafeRTOS includes. */
#include "SafeRTOS.h"
#include "streambuffer.h"
#include "task.h"

/*---------------------------------------------------------------------------*/

/* The number of bytes used to hold the length of a message in the buffer. */
#define sbBYTES_TO_STORE_MESSAGE_LENGTH ( ( portUnsignedBaseType ) sizeof( configMESSAGE_BUFFER_LENGTH_TYPE ) )

/* Set if the stream buffer was created as a message buffer, in which case it holds discrete messages rather than a stream. */
#define sbFLAGS_IS_MESSAGE_BUFFER       ( ( portUInt8Type ) 1U )

/* We pass a ticks to wait time of 1 when we fail to get the sb spinlock */
#define sbONE_TICK                      ( ( portTickType ) 1U )

/* Used when attempting to lock the SB */
#define sbUNLOCKED_LOOP_AGAIN           ( ( portBaseType ) 2 )

/*---------------------------------------------------------------------------*/

/*
 * Get the number of bytes used by the next message on a message buffer.
 * Assumes we already have the interrupt mask set and have the SB lock.
 * May return an error code if it fails to read from the message buffer.
 */
KERNEL_FUNCTION static portBaseType prvGetNextMessageLengthFromISR( StreamBufferHandle_t xStreamBuffer,
                                                                    configMESSAGE_BUFFER_LENGTH_TYPE *pxNextMessageLengthBytes );
/*
 * Add uxCount bytes from pucData into the pxStreamBuffer message buffer.
 * Returns pass if all of the data was written, or an error code if no data was written.
 */
KERNEL_FUNCTION static portBaseType prvWriteBytesToBuffer( StreamBufferHandle_t xStreamBuffer,
                                                           const portUInt8Type  pucData[],
                                                           portUnsignedBaseType uxCount,
                                                           portBaseType         xIsInInterrupt );

/*
 * If the stream buffer is being used as a message buffer, then reads an entire
 * message out of the buffer. If the stream buffer is being used as a stream
 * buffer then read as many bytes as possible from the buffer.
 * prvReadBytesFromBuffer() is called to actually extract the bytes from the
 * buffer's data storage area.
 */
KERNEL_FUNCTION static portBaseType prvReadMessageFromBuffer( StreamBufferHandle_t xStreamBuffer,
                                                              portUInt8Type        *pucRxData,
                                                              portUnsignedBaseType uxBufferLengthBytes,
                                                              portUnsignedBaseType uxBytesAvailable,
                                                              portUnsignedBaseType uxBytesToStoreMessageLength,
                                                              portUnsignedBaseType *puxReceivedLength,
                                                              portBaseType         xIsInInterrupt );

/*
 * If the stream buffer is being used as a message buffer, then writes an entire
 * message to the buffer. If the stream buffer is being used as a stream
 * buffer then write as many bytes as possible to the buffer.
 * prvWriteBytestoBuffer() is called to actually send the bytes to the buffer's
 * data storage area.
 */
KERNEL_FUNCTION static portBaseType prvWriteMessageToBuffer( StreamBufferHandle_t xStreamBuffer,
                                                             portUInt8Type        pucTxData[],
                                                             portUnsignedBaseType uxDataLengthBytes,
                                                             portUnsignedBaseType uxSpace,
                                                             portUnsignedBaseType uxRequiredSpace,
                                                             portUnsignedBaseType *puxBytesWritten,
                                                             portBaseType         xIsInInterrupt );

/*
 * Read uxMaxCount bytes from the pxStreamBuffer message buffer and write them
 * to pucData.
 */
KERNEL_FUNCTION static portBaseType prvReadBytesFromBuffer( StreamBufferHandle_t xStreamBuffer,
                                                            portUInt8Type        pucData[],
                                                            portUnsignedBaseType uxMaxCount,
                                                            portUnsignedBaseType uxBytesAvailable,
                                                            portUnsignedBaseType *puxReceivedLength,
                                                            portBaseType         xIsInInterrupt );

/*
 * Called by pxStreamBufferCreate() to
 * initialise the members of the newly created stream buffer structure.
 */
KERNEL_FUNCTION static void prvInitialiseNewStreamBuffer( StreamBufferHandle_t xStreamBuffer,
                                                          portUInt8Type        *const pucBuffer,
                                                          portUnsignedBaseType uxBufferSizeBytes,
                                                          portUnsignedBaseType uxTriggerLevelBytes,
                                                          portUnsignedBaseType uxFlags );

/* Called by stream buffer create function to check the supplied function arguments before they're used - returns an error code. */

KERNEL_CREATE_FUNCTION static portBaseType prvCheckStreamBufferCreateParameters( portUnsignedBaseType uxBufferSizeBytes,
                                                                                 portUnsignedBaseType uxTriggerLevelBytes,
                                                                                 portUnsignedBaseType uxIsMessageBuffer,
                                                                                 portUInt8Type *const pucStreamBufferStorageArea,
                                                                                 StreamBuffer_t       *pxStreamBuffer,
                                                                                 StreamBufferHandle_t *pxStreamBufferHandle );

KERNEL_FUNCTION static portBaseType prvIsStreamBufferHandleValid( StreamBufferHandle_t xStreamBuffer );

/* Functions that both enter/exit a critical section and take/give a port-specific inter-core lock for the streambuffer. */
KERNEL_FUNCTION static portBaseType prvEnterCriticalAndLockSB( StreamBufferHandle_t xStreamBufferHandle );
KERNEL_FUNCTION static void prvExitCriticalAndUnlockSB( StreamBufferHandle_t xStreamBufferHandle );

/* Functions that both set/clear the interrupt mask and take/give a port-specific inter-core lock for the streambuffer. */
KERNEL_FUNCTION static portBaseType prvSetInterruptMaskAndLockSB( StreamBufferHandle_t xStreamBufferHandle,
                                                                  portUnsignedBaseType *puxSavedInterruptStatus );
KERNEL_FUNCTION static void prvClearInterruptMaskAndUnlockSB( StreamBufferHandle_t xStreamBufferHandle,
                                                              portUnsignedBaseType uxSavedInterruptStatus );

KERNEL_FUNCTION portBaseType xStreamBufferAttemptToLock( StreamBufferHandle_t xStreamBufferHandle );
KERNEL_FUNCTION void vStreamBufferReleaseLock( StreamBufferHandle_t  xStreamBufferHandle );

KERNEL_FUNCTION static portUnsignedBaseType prvFindMinimumValue( portUnsignedBaseType uxA,
                                                                 portUnsignedBaseType uxB );

/*---------------------------------------------------------------------------*/

KERNEL_CREATE_FUNCTION portBaseType xStreamBufferCreateKrnl( StreamBufferHandle_t  *pxStreamBufferHandle,
                                                             portUnsignedBaseType  uxBufferSizeBytes,
                                                             portUnsignedBaseType  uxTriggerLevelBytes,
                                                             portUnsignedBaseType  uxIsMessageBuffer,
                                                             portUInt8Type *const  pucStreamBufferStorageArea,
                                                             StreamBuffer_t *const pxStreamBuffer )
{
    portBaseType  xReturn;
    portUInt8Type uxFlags;

    xReturn = prvCheckStreamBufferCreateParameters( uxBufferSizeBytes,
                                                    uxTriggerLevelBytes,
                                                    uxIsMessageBuffer,
                                                    pucStreamBufferStorageArea,
                                                    pxStreamBuffer,
                                                    pxStreamBufferHandle );

    if( pdPASS == xReturn )
    {
        if( pdPASS != portCOPY_DATA_TO_TASK( pxStreamBufferHandle, &pxStreamBuffer, sizeof( StreamBufferHandle_t * ) ) )
        {
            xReturn = errINVALID_DATA_RANGE;
            /* MCDC Test Point: STD_IF "xStreamBufferCreateKrnl" */
        }
        else
        {
            if( pdFALSE != uxIsMessageBuffer )
            {
                /* Message buffer. */
                uxFlags = sbFLAGS_IS_MESSAGE_BUFFER;

                /* MCDC Test Point: STD_IF "xStreamBufferCreateKrnl" */
            }
            else
            {
                /* Stream buffer. */
                uxFlags = 0U;

                /* MCDC Test Point: STD_ELSE "xStreamBufferCreateKrnl" */
            }

            prvInitialiseNewStreamBuffer( pxStreamBuffer,
                                          pucStreamBufferStorageArea,
                                          uxBufferSizeBytes,
                                          uxTriggerLevelBytes,
                                          uxFlags );

            /* MCDC Test Point: STD_IF "xStreamBufferCreateKrnl" */
        }
        /* MCDC Test Point: STD_IF "xStreamBufferCreateKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferCreateKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xStreamBufferSendKrnl( StreamBufferHandle_t xStreamBuffer,
                                                    portUInt8Type        *pucTxData,
                                                    portUnsignedBaseType uxDataLengthBytes,
                                                    portTickType         xTicksToWait,
                                                    portUnsignedBaseType *puxBytesWritten )
{
    portUnsignedBaseType uxSpace                = 0U;
    portBaseType         xTaskHasTimedOut       = pdFALSE;
    portUnsignedBaseType uxRequiredSpace        = uxDataLengthBytes;
    portBaseType         xTaskNotificationError;
    portBaseType         xReturn                = prvIsStreamBufferHandleValid( xStreamBuffer );
    portUnsignedBaseType uxTempBytesWritten     = 0U;
    xTimeOutType         xTimeOut;
    portBaseType         xLockStatus;
    portUnsignedBaseType uxCoreWaiting;
    portTaskHandleType   xTaskWaiting;

    if( pdPASS == xReturn )
    {
        /* MCDC Test Point: EXP_IF_OR "xStreamBufferSendKrnl" "( NULL == pucTxData )" "( NULL == puxBytesWritten )" */
        if( ( NULL == pucTxData ) || ( NULL == puxBytesWritten ) )
        {
            xReturn = errNULL_PARAMETER_SUPPLIED;
            /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
        }
        else if( pdPASS != portCOPY_DATA_TO_TASK( puxBytesWritten, &uxTempBytesWritten, ( portUnsignedBaseType ) sizeof( uxTempBytesWritten ) ) )
        {
            xReturn = errINVALID_DATA_RANGE;
            /* MCDC Test Point: STD_ELSE_IF "xStreamBufferSendKrnl" */
        }
        else if( uxDataLengthBytes > xStreamBuffer->uxLength )
        {
            xReturn = errSUPPLIED_BUFFER_TOO_SMALL;
            /* MCDC Test Point: STD_ELSE_IF "xStreamBufferSendKrnl" */
        }
        else
        {
            /* This block is here for MISRA */
            /* MCDC Test Point: STD_ELSE "xStreamBufferSendKrnl" */
        }
        /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferSendKrnl" */

    if( pdPASS == xReturn )
    {
        /* This send function is used to write to both message buffers and stream
         * buffers. If this is a message buffer then the space needed must be
         * increased by the amount of bytes needed to store the length of the
         * message. */
        if( ( portUInt8Type ) 0 != ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) )
        {
            uxRequiredSpace += ( configMESSAGE_BUFFER_LENGTH_TYPE ) sbBYTES_TO_STORE_MESSAGE_LENGTH;
            /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferSendKrnl" */

        if( ( portTickType ) 0 != xTicksToWait )
        {
            if( pdTRUE != xTaskIsSchedulerSuspended() )
            {
                vTaskSetTimeOut( &xTimeOut );

                do
                {
                    /* Wait until the required number of bytes are free in the message buffer. */
                    uxSpace = xStreamBuffer->uxLength - xStreamBuffer->uxBytesStored;

                    if( uxSpace < uxRequiredSpace )
                    {
                        xLockStatus = prvEnterCriticalAndLockSB( xStreamBuffer );
                        if( pdPASS == xLockStatus )
                        {
                            xStreamBuffer->xTaskWaitingToSend = xTaskGetCurrentTaskHandleKrnl();
                            xStreamBuffer->xTaskWaitingToSendCore = portGET_CPU_ID();
                            vStreamBufferRegisterMulticoreTxWaiting( xStreamBuffer );

                            prvExitCriticalAndUnlockSB( xStreamBuffer );
                            /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
                        }
                        else
                        {
                            /* MCDC Test Point: STD_ELSE "xStreamBufferSendKrnl" */
                            /* We failed to lock the streambuffer here, so we're going to fail later
                             * too, when we lock before doing the actual copy. */
                            xReturn = errSB_LOCK_UNAVAILABLE;
                            break;
                        }
                        /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
                    }
                    else
                    {
                        /* MCDC Test Point: STD_ELSE "xStreamBufferSendKrnl" */
                        /* We have enough space in the streambuffer to send so we can break here safely */
                        break;
                    }

                    xReturn = xTaskNotifyWaitKrnl( 0U, 0U, NULL, xTicksToWait );

                    xLockStatus = prvEnterCriticalAndLockSB( xStreamBuffer );
                    if( pdPASS == xLockStatus )
                    {
                        xStreamBuffer->xTaskWaitingToSend = NULL;
                        xStreamBuffer->xTaskWaitingToSendCore = sbSTREAM_BUFFER_NO_CORE;
                        vStreamBufferRegisterMulticoreTxTimeout( xStreamBuffer );

                        prvExitCriticalAndUnlockSB( xStreamBuffer );
                        /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
                    }
                    else
                    {
                        /* MCDC Test Point: STD_ELSE "xStreamBufferSendKrnl" */
                        /* It was okay to fail locking when setting the task waiting variables before because we could just
                         * exit the function and leave the SB in the same state as we found it. We can't do that here, as
                         * leaving those variables set without clearing them and leaving this function would leave the SB
                         * in an inconsistent state. We don't want to call the error hook however because we don't want this
                         * core to fail as a result of another core failing. */
                        xReturn = errSB_CORRUPTED;
                    }

                    xTaskHasTimedOut = xTaskCheckForTimeOut( &xTimeOut, &xTicksToWait );

                    /* MCDC Test Point: WHILE_INTERNAL "xStreamBufferSendKrnl" "( pdFALSE == xTaskHasTimedOut )" "( errSB_LOCK_UNAVAILABLE == xReturn )" */
                } while( ( pdFALSE == xTaskHasTimedOut ) || ( errSB_LOCK_UNAVAILABLE == xReturn ) );

                /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
            }
            else
            {
                xReturn = errSCHEDULER_IS_SUSPENDED;

                /* MCDC Test Point: STD_ELSE "xStreamBufferSendKrnl" */
            }
            /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferSendKrnl" */

        /* Recalculate the space if we had timed out, otherwise calculate for first time */
        uxSpace = xStreamBuffer->uxLength - xStreamBuffer->uxBytesStored;

        /* If we failed to get the streambuffer lock or there is no space, don't copy */
        if( pdPASS == xReturn )
        {
            if( pdTRUE == xTaskHasTimedOut )
            {
                xReturn = errSB_NOTIFICATION_TIMEOUT;
                /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
            }
            /* MCDC Test Point: ADD_ELSE "xStreamBufferSendKrnl" */

            /* Attempt to write as many bytes as we can - at this point, we may have timed out and only have space
             * for some of the target message. Note that prvWriteMessageToBuffer() may decide not to write data. */
            xReturn = prvWriteMessageToBuffer( xStreamBuffer,       /* The streambuffer we are sending to */
                                               pucTxData,           /* The data we want to send */
                                               uxDataLengthBytes,   /* The amount of data to send */
                                               uxSpace,             /* How much space is actually on the streambuffer */
                                               uxRequiredSpace,     /* The space required for the data copy - possibly includes messagebuffer overhead. */
                                               puxBytesWritten,     /* The number of bytes actually written will be passed out here */
                                               pdFALSE );           /* This is not an interrupt context */

            /* If we did write some data, and we exceeded the trigger level, then we could notify a waiting receiver. */
            if( *puxBytesWritten > 0U )
            {
                /* Was a task waiting for the data? */
                if( xStreamBuffer->uxBytesStored >= xStreamBuffer->uxTriggerLevelBytes )
                {
                    /* We want a lock on the streambuffer so that we can cache the receiving core and
                     * task without a receiver interacting with the SB. */
                    xLockStatus = prvEnterCriticalAndLockSB( xStreamBuffer );
                    if( pdPASS == xLockStatus )
                    {
                        uxCoreWaiting = xStreamBuffer->xTaskWaitingToReceiveCore;
                        xTaskWaiting = xStreamBuffer->xTaskWaitingToReceive;
                        prvExitCriticalAndUnlockSB( xStreamBuffer );

                        if( uxCoreWaiting != sbSTREAM_BUFFER_NO_CORE )
                        {
                            /* Check to see if we are on the same core */
                            if( uxCoreWaiting == portGET_CPU_ID() )
                            {
                                /* We're on the same core so we can send a standard task notification */
                                xTaskNotificationError = xTaskNotifySendKrnl( xTaskWaiting,
                                                                              taskNOTIFICATION_NO_ACTION,
                                                                              0U );

                                if( pdPASS != xTaskNotificationError )
                                {
                                    vPortErrorHook( xStreamBuffer->xTaskWaitingToReceive, xTaskNotificationError );
                                    /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
                                }
                                /* MCDC Test Point: ADD_ELSE "xStreamBufferSendKrnl" */

                                /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
                            }
                            else
                            {
                                /* Multicore - call the weak function to perhaps wake up the other core. */
                                vStreamBufferSendCompletedMulticore( xStreamBuffer );
                                /* MCDC Test Point: STD_ELSE "xStreamBufferSendKrnl" */
                            }
                            /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
                        }
                        /* MCDC Test Point: ADD_ELSE "xStreamBufferSendKrnl" */

                        /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
                    }
                    else
                    {
                        xReturn = errWAITING_TASK_NOT_NOTIFIED;
                        /* MCDC Test Point: STD_ELSE "xStreamBufferSendKrnl" */
                    }

                    /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
                }
                /* MCDC Test Point: ADD_ELSE "xStreamBufferSendKrnl" */

                /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
            }
            /* MCDC Test Point: ADD_ELSE "xStreamBufferSendKrnl" */

            /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferSendKrnl" */

        /* MCDC Test Point: STD_IF "xStreamBufferSendKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferSendKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xStreamBufferSendFromISRKrnl( StreamBufferHandle_t xStreamBuffer,
                                                           portUInt8Type        *pucTxData,
                                                           portUnsignedBaseType uxDataLengthBytes,
                                                           portUnsignedBaseType *puxBytesWritten )
{
    portUnsignedBaseType uxSpaceOnSB            = 0U;
    portUnsignedBaseType uxRequiredSpace        = uxDataLengthBytes;
    portBaseType         xTaskNotificationError;
    portBaseType         xReturn                = prvIsStreamBufferHandleValid( xStreamBuffer );
    portUnsignedBaseType uxTempBytesWritten     = 0U;
    portBaseType         xLockStatus;
    portUnsignedBaseType uxSavedInterruptStatus;
    portUnsignedBaseType uxCoreWaiting;
    portTaskHandleType   xTaskWaiting;

    if( pdPASS == xReturn )
    {
        /* MCDC Test Point: EXP_IF_OR "xStreamBufferSendFromISRKrnl" "( NULL == pucTxData )" "( NULL == puxBytesWritten )" */
        if( ( NULL == pucTxData ) || ( NULL == puxBytesWritten ) )
        {
            xReturn = errNULL_PARAMETER_SUPPLIED;
            /* MCDC Test Point: STD_IF "xStreamBufferSendFromISRKrnl" */
        }
        else if( uxDataLengthBytes > xStreamBuffer->uxLength )
        {
            xReturn = errSUPPLIED_BUFFER_TOO_SMALL;
            /* MCDC Test Point: STD_ELSE_IF "xStreamBufferSendFromISRKrnl" */
        }
        else if( pdPASS != portCOPY_DATA_TO_ISR( puxBytesWritten, &uxTempBytesWritten, ( portUnsignedBaseType ) sizeof( uxTempBytesWritten ) ) )
        {
            xReturn = errINVALID_DATA_RANGE;
            /* MCDC Test Point: STD_ELSE_IF "xStreamBufferSendFromISRKrnl" */
        }
        else
        {
            /* This case is here for MISRA compliance */
            /* MCDC Test Point: STD_ELSE "xStreamBufferSendFromISRKrnl" */
        }
        /* MCDC Test Point: STD_IF "xStreamBufferSendFromISRKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferSendFromISRKrnl" */

    if( pdPASS == xReturn )
    {
        /* Get the space available on the streambuffer */
        uxSpaceOnSB = xStreamBuffer->uxLength - xStreamBuffer->uxBytesStored;

        /* This send function is used to write to both message buffers and stream
         * buffers. If this is a message buffer then the space needed must be
         * increased by the amount of bytes needed to store the length of the
         * message. */
        if( ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( portUInt8Type ) 0 )
        {
            uxRequiredSpace += ( portUnsignedBaseType ) sbBYTES_TO_STORE_MESSAGE_LENGTH;
            /* MCDC Test Point: STD_IF "xStreamBufferSendFromISRKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferSendFromISRKrnl" */

        xReturn = prvWriteMessageToBuffer( xStreamBuffer,           /* The streambuffer we are sending to */
                                           pucTxData,               /* The data we want to send */
                                           uxDataLengthBytes,       /* The amount of data to send */
                                           uxSpaceOnSB,             /* How much space is actually on the streambuffer */
                                           uxRequiredSpace,         /* The space required for the data copy - possibly includes messagebuffer overhead. */
                                           puxBytesWritten,         /* The number of bytes actually written will be passed out here */
                                           pdTRUE );                /* This is an interrupt context */

        if( *puxBytesWritten > 0U )
        {
            /* Was a task waiting for the data? */
            if( xStreamBuffer->uxBytesStored >= xStreamBuffer->uxTriggerLevelBytes )
            {
                xLockStatus = prvSetInterruptMaskAndLockSB( xStreamBuffer, &uxSavedInterruptStatus );
                if( pdPASS == xLockStatus )
                {
                    uxCoreWaiting = xStreamBuffer->xTaskWaitingToReceiveCore;
                    xTaskWaiting = xStreamBuffer->xTaskWaitingToReceive;
                    prvClearInterruptMaskAndUnlockSB( xStreamBuffer, uxSavedInterruptStatus );

                    if( uxCoreWaiting != sbSTREAM_BUFFER_NO_CORE )
                    {
                        /* Check to see if we are on the same core, if we dont do a multicore notification */
                        if( portGET_CPU_ID() == uxCoreWaiting )
                        {
                            xTaskNotificationError = xTaskNotifySendFromISRKrnl( xTaskWaiting,
                                                                                 taskNOTIFICATION_NO_ACTION,
                                                                                 0U );
                            if( pdPASS != xTaskNotificationError )
                            {
                                /* MCDC Test Point: STD_IF "xStreamBufferSendFromISRKrnl" */
                                vPortErrorHook( xTaskWaiting, xTaskNotificationError );
                            }
                            /* MCDC Test Point: ADD_ELSE "xStreamBufferSendFromISRKrnl" */

                            /* MCDC Test Point: STD_IF "xStreamBufferSendFromISRKrnl" */
                        }
                        else
                        {
                            /* Multicore */
                            vStreamBufferSendCompletedFromISRMulticore( xStreamBuffer );
                            /* MCDC Test Point: STD_ELSE "xStreamBufferSendFromISRKrnl" */
                        }
                        /* MCDC Test Point: STD_IF "xStreamBufferSendFromISRKrnl" */
                    }
                    /* MCDC Test Point: ADD_ELSE "xStreamBufferSendFromISRKrnl" */

                    /* MCDC Test Point: STD_IF "xStreamBufferSendFromISRKrnl" */
                }
                else
                {
                    xReturn = errWAITING_TASK_NOT_NOTIFIED;
                    /* MCDC Test Point: STD_ELSE "xStreamBufferSendFromISRKrnl" */
                }

                /* MCDC Test Point: STD_IF "xStreamBufferSendFromISRKrnl" */
            }
            /* MCDC Test Point: ADD_ELSE "xStreamBufferSendFromISRKrnl" */

            /* MCDC Test Point: STD_IF "xStreamBufferSendFromISRKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferSendFromISRKrnl" */

        /* MCDC Test Point: STD_IF "xStreamBufferSendFromISRKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferSendFromISRKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xStreamBufferReceiveKrnl( StreamBufferHandle_t xStreamBuffer,
                                                       portUInt8Type        *pucRxData,
                                                       portUnsignedBaseType uxBufferLengthBytes,
                                                       portUnsignedBaseType *puxTotalBytesRead,
                                                       portTickType         xTicksToWait )
{
    portUnsignedBaseType uxBytesAvailable            = 0U;
    portUnsignedBaseType uxBytesToStoreMessageLength = 0U;
    portUnsignedBaseType uxTotalBytesToRead          = 0U;
    portBaseType         xTaskHasTimedOut            = pdFALSE;
    portBaseType         xTaskNotificationError      = pdFALSE;
    portUnsignedBaseType uxTotalBytesRead            = 0U;
    portBaseType         xReturn                     = prvIsStreamBufferHandleValid( xStreamBuffer );
    xTimeOutType         xTimeOut;
    portBaseType         xLockStatus;
    portUnsignedBaseType uxCoreWaiting;
    portTaskHandleType   xTaskWaiting;

    if( pdPASS == xReturn )
    {
        /* MCDC Test Point: EXP_IF_OR "xStreamBufferReceiveKrnl" "( NULL == pucRxData )" "( NULL == puxTotalBytesRead )" */
        /* MCDC Test Point: EXP_IF_AND "xStreamBufferReceiveKrnl" "( sbBYTES_TO_STORE_MESSAGE_LENGTH > uxBufferLengthBytes )" "( ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( portUInt8Type ) 0 )" */

        if( ( NULL == pucRxData ) || ( NULL == puxTotalBytesRead ) )
        {
            xReturn = errNULL_PARAMETER_SUPPLIED;
            /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
        }
        else if( ( sbBYTES_TO_STORE_MESSAGE_LENGTH > uxBufferLengthBytes ) &&
                 ( ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( portUInt8Type ) 0 ) )
        {
            xReturn = errSUPPLIED_BUFFER_TOO_SMALL;
            /* MCDC Test Point: STD_ELSE_IF "xStreamBufferReceiveKrnl" */
        }
        else if( 0U == uxBufferLengthBytes )
        {
            xReturn = errSUPPLIED_BUFFER_TOO_SMALL;
            /* MCDC Test Point: STD_ELSE_IF "xStreamBufferReceiveKrnl" */
        }
        else if( pdPASS != portCOPY_DATA_TO_TASK( puxTotalBytesRead, &uxTotalBytesRead, ( portUnsignedBaseType ) sizeof( uxTotalBytesRead ) ) )
        {
            xReturn = errINVALID_DATA_RANGE;
            /* MCDC Test Point: STD_ELSE_IF "xStreamBufferReceiveKrnl" */
        }
        else
        {
            /* This case is here for MISRA compliance */
            /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */
        }
        /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveKrnl" */

    if( pdPASS == xReturn )
    {
        /* This receive function is used by both message buffers, which store
         * discrete messages, and stream buffers, which store a continuous
         * stream of bytes. Discrete messages include an additional
         * sbBYTES_TO_STORE_MESSAGE_LENGTH bytes that hold the length of the
         * message. */
        if( ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( portUInt8Type ) 0 )
        {
            uxBytesToStoreMessageLength = ( portUnsignedBaseType ) sbBYTES_TO_STORE_MESSAGE_LENGTH;
            /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
        }
        else
        {
            uxBytesToStoreMessageLength = 0U;
            /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */
        }

        if( ( portTickType ) 0 != xTicksToWait )
        {
            if( pdTRUE != xTaskIsSchedulerSuspended() )
            {
                vTaskSetTimeOut( &xTimeOut );

                do
                {
                    uxBytesAvailable = xStreamBuffer->uxBytesStored;

                    /* If this function was invoked by a message buffer read then
                     * uxBytesToStoreMessageLength holds the number of bytes used to hold
                     * the length of the next discrete message. If this function was
                     * invoked by a stream buffer read then uxBytesToStoreMessageLength will
                     * be 0. */
                    if( uxBytesAvailable <= uxBytesToStoreMessageLength )
                    {
                        xLockStatus = prvEnterCriticalAndLockSB( xStreamBuffer );
                        if( pdPASS == xLockStatus )
                        {
                            xStreamBuffer->xTaskWaitingToReceive = xTaskGetCurrentTaskHandleKrnl();
                            xStreamBuffer->xTaskWaitingToReceiveCore = portGET_CPU_ID();
                            vStreamBufferRegisterMulticoreRxWaiting( xStreamBuffer );

                            prvExitCriticalAndUnlockSB( xStreamBuffer );
                            /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
                        }
                        else
                        {
                            /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */
                            /* We failed to lock the streambuffer here, so we're going to fail later
                             * too, when we lock before doing the actual copy. */
                            xReturn = errSB_LOCK_UNAVAILABLE;
                            break;
                        }
                    }
                    else
                    {
                        /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */
                        /* We have data to receive, break out of the loop. */
                        break;
                    }

                    /* Wait for data to be available. */
                    xReturn = xTaskNotifyWaitKrnl( 0U, 0U, NULL, xTicksToWait );

                    xLockStatus = prvEnterCriticalAndLockSB( xStreamBuffer );
                    if( pdPASS == xLockStatus )
                    {
                        xStreamBuffer->xTaskWaitingToReceive = NULL;
                        xStreamBuffer->xTaskWaitingToReceiveCore = sbSTREAM_BUFFER_NO_CORE;
                        vStreamBufferRegisterMulticoreRxTimeout( xStreamBuffer );

                        prvExitCriticalAndUnlockSB( xStreamBuffer );
                        /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
                    }
                    else
                    {
                        /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */
                        /* It was okay to fail locking when setting the task waiting variables before because we could
                         * just exit the function and leave the SB in the same state as we found it. We can't do that
                         * here, as leaving those variables set without clearing them and leaving this function would
                         * leave the SB in an inconsistent state. We don't want to call the error hook however because
                         * we don't want this core to fail as a result of another core failing.*/
                        xReturn = errSB_CORRUPTED;
                    }
                    xTaskHasTimedOut = xTaskCheckForTimeOut( &xTimeOut, &xTicksToWait );

                    /* MCDC Test Point: WHILE_INTERNAL "xStreamBufferReceiveKrnl" "( pdFALSE == xTaskHasTimedOut )" */
                } while( pdFALSE == xTaskHasTimedOut );

                /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
            }
            else
            {
                xReturn = errSCHEDULER_IS_SUSPENDED;
                uxBytesAvailable = xStreamBuffer->uxBytesStored;
                /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */
            }

            /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
        }
        else
        {
            uxBytesAvailable = xStreamBuffer->uxBytesStored;
            /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */
        }

        if( pdPASS == xReturn )
        {
            /* Whether receiving a discrete message (where uxBytesToStoreMessageLength
             * holds the number of bytes used to store the message length) or a stream of
             * bytes (where uxBytesToStoreMessageLength is zero), the number of bytes
             * available must be greater than uxBytesToStoreMessageLength to be able to
             * read bytes from the buffer. */
            if( sbFLAGS_IS_MESSAGE_BUFFER == ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) )
            {
                xReturn = xStreamBufferNextMessageLengthBytesKrnl( xStreamBuffer, &uxTotalBytesToRead );
                uxTotalBytesToRead += uxBytesToStoreMessageLength;

                /* MCDC Test Point: EXP_IF_AND "xStreamBufferReceiveKrnl" "( 0U != uxBytesAvailable )" "( uxBytesAvailable < uxTotalBytesToRead )" "Deviate: FF" */
                if( ( 0U != uxBytesAvailable ) && ( uxBytesAvailable < uxTotalBytesToRead ) )
                {
                    uxTotalBytesToRead = uxBytesAvailable;
                    xReturn = errSB_CORRUPT_MESSAGE;
                    /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
                }
                /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveKrnl" */

                /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
            }
            else
            {
                uxTotalBytesToRead = prvFindMinimumValue( uxBytesAvailable, uxBufferLengthBytes );
                /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */
            }

            /* At this point, if we are reading from a streambuffer, xReturn will be pdPASS.
             * If we are reading from a message buffer, xReturn could be pdPASS, errSB_CORRUPT_MESSAGE, or another error.
             * The other error would be from failing to read the number of bytes in the next message which is unrecoverable.
             * If the message was corrupted, the message is read anyway to allow the host application to attempt to recover. */

            /* MCDC Test Point: EXP_IF_OR "xStreamBufferReceiveKrnl" "( pdPASS == xReturn )" "( errSB_CORRUPT_MESSAGE == xReturn )" "Deviate: TT" */
            if( ( pdPASS == xReturn ) || ( errSB_CORRUPT_MESSAGE == xReturn ) )
            {
                if( uxTotalBytesToRead <= uxBufferLengthBytes )
                {
                    /* Note that we have already checked that we can do copy into puxTotalBytesRead so we can directly supply it here */
                    xReturn = prvReadMessageFromBuffer( xStreamBuffer,                  /* The streambuffer to read from */
                                                        pucRxData,                      /* The location to read to - not yet validated other than non-NULL */
                                                        uxBufferLengthBytes,            /* The length of the above buffer */
                                                        uxTotalBytesToRead,             /* How many bytes we are going to attempt to read */
                                                        uxBytesToStoreMessageLength,    /* How many bytes are required by the overhead - 0 for SB, >0 for MB */
                                                        puxTotalBytesRead,              /* The number of bytes that are read is passed out here */
                                                        pdFALSE );                      /* This is not in an ISR context */

                    /* Was a task waiting for space in the buffer? */
                    if( *puxTotalBytesRead > 0U )
                    {
                        if( ( xStreamBuffer->uxLength - xStreamBuffer->uxBytesStored ) >= xStreamBuffer->uxTriggerLevelBytes )
                        {
                            xLockStatus = prvEnterCriticalAndLockSB( xStreamBuffer );
                            if( pdPASS == xLockStatus )
                            {
                                uxCoreWaiting = xStreamBuffer->xTaskWaitingToSendCore;
                                xTaskWaiting = xStreamBuffer->xTaskWaitingToSend;
                                prvExitCriticalAndUnlockSB( xStreamBuffer );

                                if( sbSTREAM_BUFFER_NO_CORE != uxCoreWaiting )
                                {
                                    /* Check to see if we are on the same core, if we dont do a multicore notification */
                                    if( portGET_CPU_ID() == uxCoreWaiting )
                                    {
                                        xTaskNotificationError =  xTaskNotifySendKrnl( xTaskWaiting,
                                                                                       taskNOTIFICATION_NO_ACTION,
                                                                                       0U );

                                        if( pdPASS != xTaskNotificationError )
                                        {
                                            vPortErrorHook( xTaskWaiting, xTaskNotificationError );
                                            /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
                                        }
                                        /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveKrnl" */

                                        /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
                                    }
                                    else
                                    {
                                        /* Multicore */
                                        vStreamBufferReceiveCompletedMulticore( xStreamBuffer );
                                        /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */
                                    }
                                    /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
                                }
                                /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */

                                /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
                            }
                            else
                            {
                                xReturn = errWAITING_TASK_NOT_NOTIFIED;
                                /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */
                            }
                            /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
                        }
                        /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveKrnl" */

                        /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
                    }
                    /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveKrnl" */

                    /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
                }
                else
                {
                    xReturn = errSUPPLIED_BUFFER_TOO_SMALL;
                    /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveKrnl" */
                }
                /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
            }
            /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveKrnl" */

            /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveKrnl" */

        /* MCDC Test Point: STD_IF "xStreamBufferReceiveKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xStreamBufferReceiveFromISRKrnl( StreamBufferHandle_t xStreamBuffer,
                                                              portUInt8Type        *pucRxData,
                                                              portUnsignedBaseType uxBufferLengthBytes,
                                                              portUnsignedBaseType *puxTotalBytesRead )
{
    portUnsignedBaseType uxBytesAvailable;
    portUnsignedBaseType uxBytesToStoreMessageLength;
    portUnsignedBaseType uxTotalBytesRead = 0U;
    portUnsignedBaseType uxTotalBytesToRead = 0U;
    portBaseType         xTaskNotificationError;
    portBaseType         xReturn = prvIsStreamBufferHandleValid( xStreamBuffer );
    portBaseType         xLockStatus;
    portUnsignedBaseType uxSavedInterruptStatus;
    portUnsignedBaseType uxCoreWaiting;
    portTaskHandleType   xTaskWaiting;

    if( pdPASS == xReturn )
    {
        /* MCDC Test Point: EXP_IF_OR "xStreamBufferReceiveFromISRKrnl" "( NULL == pucRxData )" "( NULL == puxTotalBytesRead )" */
        /* MCDC Test Point: EXP_IF_AND "xStreamBufferReceiveFromISRKrnl" "( sbBYTES_TO_STORE_MESSAGE_LENGTH > uxBufferLengthBytes )" "( ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( portUInt8Type ) 0 )" */

        if( ( NULL == pucRxData ) || ( NULL == puxTotalBytesRead ) )
        {
            xReturn = errNULL_PARAMETER_SUPPLIED;
            /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
        }
        else if( ( sbBYTES_TO_STORE_MESSAGE_LENGTH > uxBufferLengthBytes ) &&
                 ( ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( portUInt8Type ) 0 ) )
        {
            xReturn = errSUPPLIED_BUFFER_TOO_SMALL;
            /* MCDC Test Point: STD_ELSE_IF "xStreamBufferReceiveKrnl" */
        }
        else if( 0U == uxBufferLengthBytes )
        {
            xReturn = errSUPPLIED_BUFFER_TOO_SMALL;
            /* MCDC Test Point: STD_ELSE_IF "xStreamBufferReceiveFromISRKrnl" */
        }
        else if( pdPASS != portCOPY_DATA_TO_ISR( puxTotalBytesRead, &uxTotalBytesRead, ( portUnsignedBaseType ) sizeof( uxTotalBytesRead ) ) )
        {
            xReturn = errINVALID_DATA_RANGE;
            /* MCDC Test Point: STD_ELSE_IF "xStreamBufferReceiveFromISRKrnl" */
        }
        else
        {
            /* This case is here for MISRA compliance */
            /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveFromISRKrnl" */
        }
        /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
    }
    /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveFromISRKrnl" */

    if( pdPASS == xReturn )
    {
        /* This receive function is used by both message buffers, which store
         * discrete messages, and stream buffers, which store a continuous stream of
         * bytes. Discrete messages include an additional
         * sbBYTES_TO_STORE_MESSAGE_LENGTH bytes that hold the length of the
         * message. */
        if( ( portUInt8Type ) 0 != ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) )
        {
            uxBytesToStoreMessageLength = ( portUnsignedBaseType ) sbBYTES_TO_STORE_MESSAGE_LENGTH;
            /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
        }
        else
        {
            uxBytesToStoreMessageLength = 0U;
            /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveFromISRKrnl" */
        }
        uxBytesAvailable = xStreamBuffer->uxBytesStored;

        if( sbFLAGS_IS_MESSAGE_BUFFER == ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) )
        {
            xReturn = prvGetNextMessageLengthFromISR( xStreamBuffer, &uxTotalBytesToRead );
            uxTotalBytesToRead += uxBytesToStoreMessageLength;

            /* MCDC Test Point: EXP_IF_AND "xStreamBufferReceiveFromISRKrnl" "( 0 != uxBytesAvailable )" "( uxBytesAvailable < uxTotalBytesToRead )" "Deviate: FF" */
            if( ( 0 != uxBytesAvailable ) && ( uxBytesAvailable < uxTotalBytesToRead ) )
            {
                uxTotalBytesToRead = uxBytesAvailable;
                xReturn = errSB_CORRUPT_MESSAGE;
                /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
            }
            /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveFromISRKrnl" */

            /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
        }
        else
        {
            uxTotalBytesToRead = prvFindMinimumValue( uxBytesAvailable, uxBufferLengthBytes );
            /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveFromISRKrnl" */
        }

        /* At this point, if we are reading from a streambuffer, xReturn will be pdPASS.
         * If we are reading from a message buffer, xReturn could be pdPASS, errSB_CORRUPT_MESSAGE, or another error.
         * The other error would be from failing to read the number of bytes in the next message which is unrecoverable.
         * If the message was corrupted, the message is read anyway to allow the host application to attempt to recover. */

        /* MCDC Test Point: EXP_IF_OR "xStreamBufferReceiveKrnl" "( pdPASS == xReturn )" "( errSB_CORRUPT_MESSAGE == xReturn )" "Deviate: TT" */
        if( ( pdPASS == xReturn ) || ( errSB_CORRUPT_MESSAGE == xReturn ) )
        {
            /* Whether receiving a discrete message (where uxBytesToStoreMessageLength
            * holds the number of bytes used to store the message length) or a stream of
            * bytes (where uxBytesToStoreMessageLength is zero), the number of bytes
            * available must be greater than uxBytesToStoreMessageLength to be able to
            * read bytes from the buffer. */

            if( uxTotalBytesToRead <= uxBufferLengthBytes )
            {
                /* Note that we have already checked that we can do copy into puxTotalBytesRead so we can directly supply it here */
                xReturn = prvReadMessageFromBuffer( xStreamBuffer,                  /* The streambuffer to read from */
                                                    pucRxData,                      /* The location to read to - not yet validated other than non-NULL */
                                                    uxBufferLengthBytes,            /* The length of the above buffer */
                                                    uxTotalBytesToRead,             /* How many bytes we are going to attempt to read */
                                                    uxBytesToStoreMessageLength,    /* How many bytes are required by the overhead - 0 for SB, >0 for MB */
                                                    puxTotalBytesRead,              /* The number of bytes that are read is passed out here */
                                                    pdTRUE );                       /* This is in an ISR context */

                /* Was a task waiting for space in the buffer? */
                if( *puxTotalBytesRead > ( portBaseType ) 0 )
                {
                    if( ( xStreamBuffer->uxLength - xStreamBuffer->uxBytesStored ) >= xStreamBuffer->uxTriggerLevelBytes )
                    {
                        xLockStatus = prvSetInterruptMaskAndLockSB( xStreamBuffer, &uxSavedInterruptStatus );
                        if( pdPASS == xLockStatus )
                        {
                            uxCoreWaiting = xStreamBuffer->xTaskWaitingToSendCore;
                            xTaskWaiting = xStreamBuffer->xTaskWaitingToSend;
                            prvClearInterruptMaskAndUnlockSB( xStreamBuffer, uxSavedInterruptStatus );

                            if( uxCoreWaiting != sbSTREAM_BUFFER_NO_CORE )
                            {
                                /* Check to see if we are on the same core, if we dont do a multicore notification */
                                if( uxCoreWaiting == portGET_CPU_ID() )
                                {
                                    xTaskNotificationError = xTaskNotifySendFromISRKrnl( xTaskWaiting,
                                                                                         taskNOTIFICATION_NO_ACTION,
                                                                                         0U );

                                    if( pdPASS != xTaskNotificationError )
                                    {
                                        vPortErrorHook( xTaskWaiting, xTaskNotificationError );
                                        /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
                                    }
                                    /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveFromISRKrnl" */

                                    /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
                                }
                                else
                                {
                                    /* Multicore */
                                    vStreamBufferReceiveCompletedFromISRMulticore( xStreamBuffer );
                                    /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveFromISRKrnl" */
                                }

                                /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
                            }
                            /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveFromISRKrnl" */

                            /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
                        }
                        else
                        {
                            xReturn = errWAITING_TASK_NOT_NOTIFIED;
                            /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveFromISRKrnl" */
                        }

                        /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
                    }
                    /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveFromISRKrnl" */

                    /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
                }
                /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveFromISRKrnl" */

                /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
            }
            else
            {
                xReturn = errSUPPLIED_BUFFER_TOO_SMALL;
                /* MCDC Test Point: STD_ELSE "xStreamBufferReceiveFromISRKrnl" */
            }
            /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveFromISRKrnl" */

        /* MCDC Test Point: STD_IF "xStreamBufferReceiveFromISRKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferReceiveFromISRKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xStreamBufferIsEmptyKrnl( StreamBufferHandle_t xStreamBuffer, portUnsignedBaseType *puxIsEmpty )
{
    portBaseType xReturn = prvIsStreamBufferHandleValid( xStreamBuffer );
    portUnsignedBaseType uxTempIsEmpty;

    if( pdTRUE == xReturn )
    {
        if( NULL != puxIsEmpty )
        {
            if( 0U == xStreamBuffer->uxBytesStored )
            {
                uxTempIsEmpty = ( portUnsignedBaseType ) pdTRUE;
                /* MCDC Test Point: STD_IF "xStreamBufferIsEmptyKrnl" */
            }
            else
            {
                uxTempIsEmpty = ( portUnsignedBaseType ) pdFALSE;
                /* MCDC Test Point: STD_ELSE "xStreamBufferIsEmptyKrnl" */
            }

            if( pdPASS != portCOPY_DATA_TO_TASK( puxIsEmpty, &uxTempIsEmpty, sizeof( portUnsignedBaseType ) ) )
            {
                xReturn = errINVALID_DATA_RANGE;
                /* MCDC Test Point: STD_IF "xStreamBufferIsEmptyKrnl" */
            }
            /* MCDC Test Point: ADD_ELSE "xStreamBufferIsEmptyKrnl" */
        }
        else
        {
            xReturn = errNULL_PARAMETER_SUPPLIED;
            /* MCDC Test Point: STD_ELSE "xStreamBufferIsEmptyKrnl" */
        }
        /* MCDC Test Point: STD_IF "xStreamBufferIsEmptyKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferIsEmptyKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xStreamBufferIsFullKrnl( StreamBufferHandle_t xStreamBuffer, portUnsignedBaseType *puxIsFull )
{
    portUnsignedBaseType uxBytesToStoreMessageLength;
    portUnsignedBaseType uxSpace                     = 0U;
    portBaseType         xReturn                     = prvIsStreamBufferHandleValid( xStreamBuffer );
    portUnsignedBaseType uxTempIsFull;

    if( pdTRUE == xReturn )
    {
        if( NULL != puxIsFull )
        {
            /* This function is used by both message buffers, which store discrete messages, and
             * stream buffers, which store a continuous stream of bytes. Discrete messages include an
             * additional sbBYTES_TO_STORE_MESSAGE_LENGTH bytes that hold the length of the message. */
            if( ( portUInt8Type ) 0 != ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) )
            {
                uxBytesToStoreMessageLength = ( portUnsignedBaseType ) sbBYTES_TO_STORE_MESSAGE_LENGTH - 1U;
                /* MCDC Test Point: STD_IF "xStreamBufferIsFullKrnl" */
            }
            else
            {
                uxBytesToStoreMessageLength = 0U;
                /* MCDC Test Point: STD_ELSE "xStreamBufferIsFullKrnl" */
            }

            /* We can ignore this return value as the handle is being checked at the top of this function */
            ( void ) xStreamBufferSpacesAvailableKrnl( xStreamBuffer, &uxSpace );

            /* True if the available space equals zero. */
            if( uxSpace <= uxBytesToStoreMessageLength )
            {
                uxTempIsFull = ( portUnsignedBaseType ) pdTRUE;
                /* MCDC Test Point: STD_IF "xStreamBufferIsFullKrnl" */
            }
            else
            {
                uxTempIsFull = ( portUnsignedBaseType ) pdFALSE;
                /* MCDC Test Point: STD_ELSE "xStreamBufferIsFullKrnl" */
            }

            if( pdPASS != portCOPY_DATA_TO_TASK( puxIsFull, &uxTempIsFull, sizeof( portUnsignedBaseType ) ) )
            {
                xReturn = errINVALID_DATA_RANGE;
                /* MCDC Test Point: STD_IF "xStreamBufferIsFullKrnl" */
            }
            /* MCDC Test Point: ADD_ELSE "xStreamBufferIsFullKrnl" */

            /* MCDC Test Point: STD_IF "xStreamBufferIsFullKrnl" */
        }
        else
        {
            xReturn = errNULL_PARAMETER_SUPPLIED;
            /* MCDC Test Point: STD_ELSE "xStreamBufferIsFullKrnl" */
        }

        /* MCDC Test Point: STD_IF "xStreamBufferIsFullKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferIsFullKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xStreamBufferResetKrnl( StreamBufferHandle_t xStreamBuffer )
{
    portUnsignedBaseType uxTempIndex;
    portBaseType         xReturn = prvIsStreamBufferHandleValid( xStreamBuffer );
    portBaseType         xLockStatus;

    if( pdTRUE == xReturn )
    {
        xReturn = pdFAIL;

        /* SAFERTOSTRACE STREAMBUFFERRESET */

        xLockStatus = prvEnterCriticalAndLockSB( xStreamBuffer );
        if( pdPASS == xLockStatus )
        {
            /* Can only reset a message buffer if there are no tasks blocked on it. */
            if( NULL == xStreamBuffer->xTaskWaitingToReceive )
            {
                if( NULL == xStreamBuffer->xTaskWaitingToSend )
                {
                    for( uxTempIndex = 0U; uxTempIndex < xStreamBuffer->uxLength; uxTempIndex++ )
                    {
                        xStreamBuffer->pucBuffer[ uxTempIndex ] = 0U;
                        /* MCDC Test Point: STD "xStreamBufferResetKrnl" */
                    }

                    xStreamBuffer->uxHead = 0U;
                    xStreamBuffer->uxTail = 0U;

                    /* This function call itself does not enter a critical section/ lock the SB,
                     * so it is important that we are already in a critical section */
                    prvInitialiseNewStreamBuffer( xStreamBuffer,
                                                  xStreamBuffer->pucBuffer,
                                                  xStreamBuffer->uxLength,
                                                  xStreamBuffer->uxTriggerLevelBytes,
                                                  xStreamBuffer->uxFlags );

                    xReturn = pdPASS;

                    /* SAFERTOSTRACE STREAMBUFFERRESET */

                    /* MCDC Test Point: STD_IF "xStreamBufferResetKrnl" */
                }
                /* MCDC Test Point: ADD_ELSE "xStreamBufferResetKrnl" */

                /* MCDC Test Point: STD_IF "xStreamBufferResetKrnl" */
            }
            /* MCDC Test Point: ADD_ELSE "xStreamBufferResetKrnl" */

            prvExitCriticalAndUnlockSB( xStreamBuffer );

            /* MCDC Test Point: STD_IF "xStreamBufferResetKrnl" */
        }
        else
        {
            xReturn = errSB_LOCK_UNAVAILABLE;
        }
        /* MCDC Test Point: STD_IF "xStreamBufferResetKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferResetKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xStreamBufferSpacesAvailableKrnl( StreamBufferHandle_t xStreamBuffer,
                                                               portUnsignedBaseType *puxSpace )
{
    portBaseType         xReturn     = prvIsStreamBufferHandleValid( xStreamBuffer );
    portUnsignedBaseType uxTempSpace;

    if( NULL == puxSpace )
    {
        xReturn = errNULL_PARAMETER_SUPPLIED;
        /* MCDC Test Point: STD_IF "xStreamBufferSpacesAvailableKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferSpacesAvailableKrnl" */

    if( pdPASS == xReturn )
    {
        uxTempSpace = xStreamBuffer->uxLength - xStreamBuffer->uxBytesStored;
        if( pdPASS != portCOPY_DATA_TO_TASK( puxSpace, &uxTempSpace, ( portUnsignedBaseType ) sizeof( uxTempSpace ) ) )
        {
            xReturn = errINVALID_DATA_RANGE;
            /* MCDC Test Point: STD_IF "xStreamBufferSpacesAvailableKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferSpacesAvailableKrnl" */

        /* MCDC Test Point: STD_IF "xStreamBufferSpacesAvailableKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferSpacesAvailableKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xStreamBufferBytesAvailableKrnl( StreamBufferHandle_t xStreamBuffer,
                                                              portUnsignedBaseType *puxBytesAvailable )
{
    portBaseType xReturn = prvIsStreamBufferHandleValid( xStreamBuffer );
    portUnsignedBaseType uxTempBytesStored;

    if( NULL == puxBytesAvailable )
    {
        xReturn = errNULL_PARAMETER_SUPPLIED;
        /* MCDC Test Point: STD_IF "xStreamBufferBytesAvailableKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferBytesAvailableKrnl" */

    if( pdPASS == xReturn )
    {
        uxTempBytesStored = xStreamBuffer->uxBytesStored;
        if( pdPASS != portCOPY_DATA_TO_TASK( puxBytesAvailable, &uxTempBytesStored, ( portUnsignedBaseType ) sizeof( uxTempBytesStored ) ) )
        {
            xReturn = errINVALID_DATA_RANGE;
            /* MCDC Test Point: STD_IF "xStreamBufferBytesAvailableKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferBytesAvailableKrnl" */

        /* MCDC Test Point: STD_IF "xStreamBufferBytesAvailableKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferBytesAvailableKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xStreamBufferSetTriggerLevelKrnl( StreamBufferHandle_t xStreamBuffer,
                                                               portUnsignedBaseType uxTriggerLevel )
{
    portBaseType xReturn = prvIsStreamBufferHandleValid( xStreamBuffer );

    /* It is not valid for the trigger level to be 0. */
    if( 0U == uxTriggerLevel )
    {
        xReturn = errINVALID_PARAMETERS;
        /* MCDC Test Point: STD_IF "xStreamBufferSetTriggerLevelKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferSetTriggerLevelKrnl" */

    if( pdPASS == xReturn )
    {
        if( uxTriggerLevel > xStreamBuffer->uxLength )
        {
            xReturn = errINVALID_PARAMETERS;
            /* MCDC Test Point: STD_IF "xStreamBufferSetTriggerLevelKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferSetTriggerLevelKrnl" */

        /* MCDC Test Point: STD_IF "xStreamBufferSetTriggerLevelKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferSetTriggerLevelKrnl" */

    if( pdPASS == xReturn )
    {
        xStreamBuffer->uxTriggerLevelBytes = uxTriggerLevel;
        /* MCDC Test Point: STD_IF "xStreamBufferSetTriggerLevelKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferSetTriggerLevelKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xStreamBufferNextMessageLengthBytesKrnl( StreamBufferHandle_t xStreamBuffer,
                                                                      configMESSAGE_BUFFER_LENGTH_TYPE *pxNextMessageLengthBytes )
{
    portUnsignedBaseType             uxBytesAvailable;
    portUnsignedBaseType             uxOriginalTail;
    portUnsignedBaseType             uxOriginalBytesStored;
    portBaseType                     xLockStatus;
    portBaseType                     xReturn                     = prvIsStreamBufferHandleValid( xStreamBuffer );
    configMESSAGE_BUFFER_LENGTH_TYPE xTempNextMessageLengthBytes = ( configMESSAGE_BUFFER_LENGTH_TYPE ) 0;

    if( NULL == pxNextMessageLengthBytes )
    {
        xReturn = errNULL_PARAMETER_SUPPLIED;
        /* MCDC Test Point: STD_IF "xStreamBufferNextMessageLengthBytesKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferNextMessageLengthBytesKrnl" */

    if( pdPASS == xReturn )
    {
        /* Ensure the stream buffer is being used as a message buffer. */
        if( ( portUInt8Type ) 0 != ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) )
        {
            uxBytesAvailable = xStreamBuffer->uxBytesStored;
            if( uxBytesAvailable >= sbBYTES_TO_STORE_MESSAGE_LENGTH )
            {
                /* The number of bytes available is greater than the number of bytes
                 * required to hold the length of the next message, so another message
                 * is available. Return its length without removing the length bytes
                 * from the buffer. A copy of the tail is stored so the buffer can be
                 * returned to its prior state as the message is not actually being
                 * removed from the buffer. */
                xLockStatus = prvEnterCriticalAndLockSB( xStreamBuffer );
                if( pdPASS == xLockStatus )
                {
                    uxOriginalTail = xStreamBuffer->uxTail;
                    uxOriginalBytesStored = xStreamBuffer->uxBytesStored;

                    xReturn = prvReadBytesFromBuffer( xStreamBuffer,
                                                      ( portUInt8Type * )( void * ) &xTempNextMessageLengthBytes,
                                                      sbBYTES_TO_STORE_MESSAGE_LENGTH,
                                                      uxBytesAvailable,
                                                      NULL,              /* We do not need to know how many bytes we copied */
                                                      pdFALSE );         /* We are not in an ISR context */

                    xStreamBuffer->uxTail = uxOriginalTail;
                    xStreamBuffer->uxBytesStored = uxOriginalBytesStored;

                    prvExitCriticalAndUnlockSB( xStreamBuffer );
                    /* MCDC Test Point: STD_IF "xStreamBufferNextMessageLengthBytesKrnl" */
                }
                else
                {
                    xReturn = errSB_LOCK_UNAVAILABLE;
                    /* MCDC Test Point: STD_ELSE "xStreamBufferNextMessageLengthBytesKrnl" */
                }

                /* MCDC Test Point: STD_IF "xStreamBufferNextMessageLengthBytesKrnl" */
            }
            /* MCDC Test Point: ADD_ELSE "xStreamBufferNextMessageLengthBytesKrnl" */

            /* MCDC Test Point: STD_IF "xStreamBufferNextMessageLengthBytesKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferNextMessageLengthBytesKrnl" */

        /* MCDC Test Point: STD_IF "xStreamBufferNextMessageLengthBytesKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferNextMessageLengthBytesKrnl" */

    if( errNULL_PARAMETER_SUPPLIED != xReturn )
    {
        if( pdPASS != portCOPY_DATA_TO_TASK( pxNextMessageLengthBytes, &xTempNextMessageLengthBytes, ( portUnsignedBaseType ) sizeof( xTempNextMessageLengthBytes ) ) )
        {
            xReturn = errINVALID_DATA_RANGE;
            /* MCDC Test Point: STD_IF "xStreamBufferNextMessageLengthBytesKrnl" */
        }
        /* MCDC Test Point: ADD_ELSE "xStreamBufferNextMessageLengthBytesKrnl" */

        /* MCDC Test Point: STD_IF "xStreamBufferNextMessageLengthBytesKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xStreamBufferNextMessageLengthBytesKrnl" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvGetNextMessageLengthFromISR( StreamBufferHandle_t xStreamBuffer,
                                                                    configMESSAGE_BUFFER_LENGTH_TYPE *pxNextMessageLengthBytes )
{
    portUnsignedBaseType uxOriginalTail;
    portUnsignedBaseType uxOriginalBytesStored;
    portUnsignedBaseType uxSavedInterruptStatus;
    portBaseType         xLockStatus;
    portBaseType         xReturn;

    /* The number of bytes available is greater than the number of bytes
     * required to hold the length of the next message, so another message
     * is available. Return its length without removing the length bytes
     * from the buffer. A copy of the tail is stored so the buffer can be
     * returned to its prior state as the message is not actually being
     * removed from the buffer. */
    xLockStatus = prvSetInterruptMaskAndLockSB( xStreamBuffer, &uxSavedInterruptStatus );
    if( pdPASS == xLockStatus )
    {
        uxOriginalTail = xStreamBuffer->uxTail;
        uxOriginalBytesStored = xStreamBuffer->uxBytesStored;

        xReturn = prvReadBytesFromBuffer( xStreamBuffer,
                                          ( portUInt8Type * )( void * ) pxNextMessageLengthBytes,
                                          sbBYTES_TO_STORE_MESSAGE_LENGTH,
                                          xStreamBuffer->uxBytesStored,
                                          NULL,              /* We do not need to know how many bytes we copied */
                                          pdTRUE );          /* We are in an ISR context */

        xStreamBuffer->uxTail = uxOriginalTail;
        xStreamBuffer->uxBytesStored = uxOriginalBytesStored;

        prvClearInterruptMaskAndUnlockSB( xStreamBuffer, uxSavedInterruptStatus );
        /* MCDC Test Point: STD_IF "prvGetNextMessageLengthFromISR" */
    }
    else
    {
        xReturn = errSB_LOCK_UNAVAILABLE;
        /* MCDC Test Point: STD_ELSE "prvGetNextMessageLengthFromISR" */
    }

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvWriteBytesToBuffer( StreamBufferHandle_t xStreamBuffer,
                                                           const portUInt8Type  pucData[],
                                                           portUnsignedBaseType uxCount,
                                                           portBaseType         xIsInInterrupt )
{
    portUnsignedBaseType uxNextHead;
    portUnsignedBaseType uxFirstLength;
    portBaseType         xReturn;
    portUnsignedBaseType uxSavedInterruptMask = 0;

    if( pdTRUE == xIsInInterrupt )
    {
        xReturn = prvSetInterruptMaskAndLockSB( xStreamBuffer, &uxSavedInterruptMask );
        /* MCDC Test Point: STD_IF "prvWriteBytesToBuffer" */
    }
    else
    {
        xReturn = prvEnterCriticalAndLockSB( xStreamBuffer );
        /* MCDC Test Point: STD_ELSE "prvWriteBytesToBuffer" */
    }

    if( pdPASS == xReturn )
    {
        uxNextHead = xStreamBuffer->uxHead;

        /* Calculate the number of bytes that can be added in the first write -
         * which may be less than the total number of bytes that need to be added if
         * the buffer will wrap back to the beginning. */
        uxFirstLength = prvFindMinimumValue( xStreamBuffer->uxLength - uxNextHead, uxCount );

        /* Write as many bytes as can be written in the first write. */
        if( pdTRUE == xIsInInterrupt )
        {
            xReturn = portCOPY_DATA_FROM_ISR( &( xStreamBuffer->pucBuffer[ uxNextHead ] ), ( const void * ) pucData, uxFirstLength );

            /* MCDC Test Point: STD_IF "prvWriteBytesToBuffer" */
        }
        else
        {
            xReturn = portCOPY_DATA_FROM_TASK( &( xStreamBuffer->pucBuffer[ uxNextHead ] ), ( const void * ) pucData, uxFirstLength );

            /* MCDC Test Point: STD_ELSE "prvWriteBytesToBuffer" */
        }

        if( pdPASS == xReturn )
        {
            /* If the number of bytes written was less than the number that could be
             * written in the first write... */
            if( uxCount > uxFirstLength )
            {
                /* ...then write the remaining bytes to the start of the buffer. */
                if( pdTRUE == xIsInInterrupt )
                {
                    xReturn = portCOPY_DATA_FROM_ISR( ( void * )( xStreamBuffer->pucBuffer ),
                                                      ( const void * )( &pucData[ uxFirstLength ] ),
                                                      uxCount - uxFirstLength );

                    /* MCDC Test Point: STD_IF "prvWriteBytesToBuffer" */
                }
                else
                {
                    xReturn = portCOPY_DATA_FROM_TASK( ( void * )( xStreamBuffer->pucBuffer ),
                                                       ( const void * )( &pucData[ uxFirstLength ] ),
                                                       uxCount - uxFirstLength );

                    /* MCDC Test Point: STD_ELSE "prvWriteBytesToBuffer" */
                }

                if( pdPASS != xReturn )
                {
                    xReturn  = errINVALID_DATA_RANGE;
                    /* MCDC Test Point: STD_IF "prvWriteBytesToBuffer" */
                }
                /* MCDC Test Point: ADD_ELSE "prvWriteBytesToBuffer" */

                /* MCDC Test Point: STD_IF "prvWriteBytesToBuffer" */
            }
            /* MCDC Test Point: ADD_ELSE "prvWriteBytesToBuffer" */

            uxNextHead += uxCount;
            xStreamBuffer->uxBytesStored += uxCount;
            if( uxNextHead >= xStreamBuffer->uxLength )
            {
                uxNextHead -= xStreamBuffer->uxLength;
                /* MCDC Test Point: STD_IF "prvWriteBytesToBuffer" */
            }
            /* MCDC Test Point: ADD_ELSE "prvWriteBytesToBuffer" */

            xStreamBuffer->uxHead = uxNextHead;

            /* MCDC Test Point: STD_IF "prvWriteBytesToBuffer" */
        }
        else
        {
            xReturn  = errINVALID_DATA_RANGE;
            /* MCDC Test Point: STD_IF "prvWriteBytesToBuffer" */
        }

        if( pdTRUE == xIsInInterrupt )
        {
            prvClearInterruptMaskAndUnlockSB( xStreamBuffer, uxSavedInterruptMask );
            /* MCDC Test Point: STD_IF "prvWriteBytesToBuffer" */
        }
        else
        {
            prvExitCriticalAndUnlockSB( xStreamBuffer );
            /* MCDC Test Point: STD_ELSE "prvWriteBytesToBuffer" */
        }

        /* MCDC Test Point: STD_IF "prvWriteBytesToBuffer" */
    }
    else
    {
        xReturn = errSB_LOCK_UNAVAILABLE;
    }

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvWriteMessageToBuffer( StreamBufferHandle_t xStreamBuffer,
                                                             portUInt8Type        pucTxData[],
                                                             portUnsignedBaseType uxDataLengthBytes,
                                                             portUnsignedBaseType uxSpace,
                                                             portUnsignedBaseType uxRequiredSpace,
                                                             portUnsignedBaseType *puxBytesWritten,
                                                             portBaseType         xIsInInterrupt )
{
    portBaseType xReturn;

    if( 0U == uxSpace )
    {
        /* Doesn't matter if this is a stream buffer or a message buffer, there
         * is no space to write. */
        xReturn = pdFAIL;

        /* MCDC Test Point: STD_IF "prvWriteMessageToBuffer" */
    }
    else if( sbFLAGS_IS_MESSAGE_BUFFER != ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) )
    {
        /* This is a stream buffer, as opposed to a message buffer, so writing a
         * stream of bytes rather than discrete messages. Write as many bytes as
         * possible. */
        uxDataLengthBytes = prvFindMinimumValue( uxDataLengthBytes, uxSpace );
        xReturn = pdPASS;

        /* MCDC Test Point: STD_ELSE_IF "prvWriteMessageToBuffer" */
    }
    else if( uxSpace >= uxRequiredSpace )
    {
        /* This is a message buffer, as opposed to a stream buffer, and there
         * is enough space to write both the message length and the message itself
         * into the buffer. Start by writing the length of the data, the data
         * itself will be written later in this function (if we successfully write this) */
        xReturn = prvWriteBytesToBuffer( xStreamBuffer,
                                         ( const portUInt8Type * )( void * ) &uxDataLengthBytes,
                                         sbBYTES_TO_STORE_MESSAGE_LENGTH,
                                         xIsInInterrupt );

        /* MCDC Test Point: STD_ELSE_IF "prvWriteMessageToBuffer" */
    }
    else
    {
        /* There is space available, but not enough space. */
        xReturn = pdFAIL;

        /* MCDC Test Point: STD_ELSE "prvWriteMessageToBuffer" */
    }

    if( pdPASS == xReturn )
    {
        /* Writes the data itself. */
        xReturn = prvWriteBytesToBuffer( xStreamBuffer,
                                         ( const portUInt8Type * ) pucTxData,
                                         uxDataLengthBytes,
                                         xIsInInterrupt );

        if( pdPASS == xReturn )
        {
            *puxBytesWritten = uxDataLengthBytes;
            /* MCDC Test Point: STD_IF "prvWriteMessageToBuffer" */
        }
        else
        {
            *puxBytesWritten = 0U;

            /* If we failed to get the lock but we also previously successfully wrote the length of the next message
             * then we have placed the streambuffer in an inconsistant state. */
            if( ( portUInt8Type ) sbFLAGS_IS_MESSAGE_BUFFER == ( xStreamBuffer->uxFlags & sbFLAGS_IS_MESSAGE_BUFFER ) )
            {
                xReturn = errSB_CORRUPT_MESSAGE;
                /* MCDC Test Point: STD_IF "prvWriteMessageToBuffer" */
            }
            /* MCDC Test Point: ADD_ELSE "prvWriteMessageToBuffer" */
            /* MCDC Test Point: STD_ELSE "prvWriteMessageToBuffer" */
        }
        /* MCDC Test Point: STD_IF "prvWriteMessageToBuffer" */
    }
    else
    {
        *puxBytesWritten = 0U;
        /* MCDC Test Point: STD_ELSE "prvWriteMessageToBuffer" */
    }

    return xReturn;
}
/*---------------------------------------------------------------------------*/

/* This function is only ever called if we have the lock on the streambuffer */
KERNEL_FUNCTION static portBaseType prvReadBytesFromBuffer( StreamBufferHandle_t xStreamBuffer,
                                                            portUInt8Type        pucData[],
                                                            portUnsignedBaseType uxMaxCount,
                                                            portUnsignedBaseType uxBytesAvailable,
                                                            portUnsignedBaseType *puxReceivedLength,
                                                            portBaseType         xIsInInterrupt )
{
    portUnsignedBaseType uxCount = 0U;
    portUnsignedBaseType uxFirstLength;
    portUnsignedBaseType uxNextTail;
    portBaseType         xReturn = pdFAIL;

    if( 0U != xStreamBuffer->uxBytesStored )
    {
        /* Use the minimum of the wanted bytes and the available bytes. */
        uxCount = prvFindMinimumValue( uxBytesAvailable, uxMaxCount );

        if( uxCount > 0U )
        {
            uxNextTail = xStreamBuffer->uxTail;

            /* Calculate the number of bytes that can be read - which may be
             * less than the number wanted if the data wraps around to the start of
             * the buffer. */
            uxFirstLength = prvFindMinimumValue( xStreamBuffer->uxLength - uxNextTail, uxCount );

            /* Obtain the number of bytes it is possible to obtain in the first
             * read - before a potential circular buffer wrap */
            if( pdTRUE == xIsInInterrupt )
            {
                xReturn = portCOPY_DATA_TO_ISR( ( void * ) pucData, ( const void * ) &( xStreamBuffer->pucBuffer[ uxNextTail ] ), uxFirstLength );
                /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
            }
            else
            {
                xReturn = portCOPY_DATA_TO_TASK( ( void * ) pucData, ( const void * ) &( xStreamBuffer->pucBuffer[ uxNextTail ] ), uxFirstLength );
                /* MCDC Test Point: STD_ELSE "prvReadBytesFromBuffer" */
            }

            if( pdPASS == xReturn )
            {
                /* If the total number of wanted bytes is greater than the number
                 * that could be read in the first read... */
                if( uxCount > uxFirstLength )
                {
                    /*...then read the remaining bytes from the start of the buffer. */
                    if( pdTRUE == xIsInInterrupt )
                    {
                        xReturn = portCOPY_DATA_TO_ISR( ( void * ) &( pucData[ uxFirstLength ] ), ( void * )( xStreamBuffer->pucBuffer ), uxCount - uxFirstLength );
                        /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
                    }
                    else
                    {
                        xReturn = portCOPY_DATA_TO_TASK( ( void * ) &( pucData[ uxFirstLength ] ), ( void * )( xStreamBuffer->pucBuffer ), uxCount - uxFirstLength );
                        /* MCDC Test Point: STD_ELSE "prvReadBytesFromBuffer" */
                    }

                    if( pdPASS != xReturn )
                    {
                        xReturn = errINVALID_DATA_RANGE;
                        /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
                    }
                    /* MCDC Test Point: ADD_ELSE "prvReadBytesFromBuffer" */

                    /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
                }
                /* MCDC Test Point: ADD_ELSE "prvReadBytesFromBuffer" */

                if( pdPASS == xReturn )
                {
                    /* Move the tail pointer to effectively remove the data read from
                     * the buffer. */
                    uxNextTail += uxCount;
                    xStreamBuffer->uxBytesStored -= uxCount;
                    if( uxNextTail >= xStreamBuffer->uxLength )
                    {
                        uxNextTail -= xStreamBuffer->uxLength;
                        /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
                    }
                    /* MCDC Test Point: ADD_ELSE "prvReadBytesFromBuffer" */

                    xStreamBuffer->uxTail = uxNextTail;

                    /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
                }
                /* MCDC Test Point: ADD_ELSE "prvReadBytesFromBuffer" */

                /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
            }
            else
            {
                xReturn = errINVALID_DATA_RANGE;
                /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
            }
            /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
        }
        /* MCDC Test Point: ADD_ELSE "prvReadBytesFromBuffer" */

        /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
    }

    if( pdPASS != xReturn )
    {
        /* We did not do a copy */
        uxCount = 0U;
        /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
    }
    /* MCDC Test Point: ADD_ELSE "prvReadBytesFromBuffer" */

    if( NULL != puxReceivedLength )
    {
        *puxReceivedLength = uxCount;
        /* MCDC Test Point: STD_IF "prvReadBytesFromBuffer" */
    }
    /* MCDC Test Point: ADD_ELSE "prvReadBytesFromBuffer" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

/* This function is always called with puxReceivedLength already validated */
KERNEL_FUNCTION static portBaseType prvReadMessageFromBuffer( StreamBufferHandle_t xStreamBuffer,
                                                              portUInt8Type        *pucRxData,
                                                              portUnsignedBaseType uxBufferLengthBytes,
                                                              portUnsignedBaseType uxBytesAvailable,
                                                              portUnsignedBaseType uxBytesToStoreMessageLength,
                                                              portUnsignedBaseType *puxReceivedLength,
                                                              portBaseType         xIsInInterrupt )
{
    portUnsignedBaseType             uxOriginalTail;
    portUnsignedBaseType             uxNextMessageLength = 0U;
    portUnsignedBaseType             uxOriginalBytesStored;
    configMESSAGE_BUFFER_LENGTH_TYPE xTempNextMessageLength;
    portBaseType                     xLockStatus = pdPASS;
    portBaseType                     xReturn = pdPASS;
    portUnsignedBaseType             uxSavedInterruptStatus = 0U;

    if( 0U != uxBytesToStoreMessageLength )
    {
        if( pdTRUE == xIsInInterrupt )
        {
            xLockStatus = prvSetInterruptMaskAndLockSB( xStreamBuffer, &uxSavedInterruptStatus );
            /* MCDC Test Point: STD_IF "prvReadMessageFromBuffer" */
        }
        else
        {
            xLockStatus = prvEnterCriticalAndLockSB( xStreamBuffer );
            /* MCDC Test Point: STD_ELSE "prvReadMessageFromBuffer" */
        }

        if( pdPASS == xLockStatus )
        {
            /* A discrete message is being received. First receive the length
             * of the message. A copy of the tail is stored so the buffer can be
             * returned to its prior state if the length of the message is too
             * large for the provided buffer. */
            uxOriginalTail = xStreamBuffer->uxTail;
            uxOriginalBytesStored = xStreamBuffer->uxBytesStored;

            xReturn = prvReadBytesFromBuffer( xStreamBuffer,
                                              ( portUInt8Type * )( void * ) &xTempNextMessageLength,
                                              uxBytesToStoreMessageLength,
                                              uxBytesAvailable,
                                              NULL,
                                              xIsInInterrupt );

            uxNextMessageLength = ( portUnsignedBaseType ) xTempNextMessageLength;

            /* Reduce the number of bytes available by the number of bytes just
             * read out. */
            uxBytesAvailable -= uxBytesToStoreMessageLength;

            /* Check there is enough space in the buffer provided by the user. */
            if( uxNextMessageLength > uxBufferLengthBytes )
            {
                /* The user has provided insufficient space to read the message
                 * so return the buffer to its previous state (so the length of
                 * the message is in the buffer again). */
                xStreamBuffer->uxTail = uxOriginalTail;
                xStreamBuffer->uxBytesStored = uxOriginalBytesStored;
                uxNextMessageLength = 0U;

                /* MCDC Test Point: STD_IF "prvReadMessageFromBuffer" */
            }
            /* MCDC Test Point: ADD_ELSE "prvReadMessageFromBuffer" */

            /* MCDC Test Point: STD_IF "prvReadMessageFromBuffer" */
        }
        else
        {
            xReturn = errSB_LOCK_UNAVAILABLE;
            *puxReceivedLength = 0;
        }

        /* MCDC Test Point: STD_IF "prvReadMessageFromBuffer" */
    }
    else
    {
        /* A stream of bytes is being received (as opposed to a discrete
         * message), so read as many bytes as possible. */
        uxNextMessageLength = uxBufferLengthBytes;

        /* MCDC Test Point: STD_ELSE "prvReadMessageFromBuffer" */
    }

    if( pdPASS == xReturn )
    {
        if( 0U == uxBytesToStoreMessageLength )
        {
            if( pdTRUE == xIsInInterrupt )
            {
                xLockStatus = prvSetInterruptMaskAndLockSB( xStreamBuffer, &uxSavedInterruptStatus );
                /* MCDC Test Point: STD_IF "prvReadMessageFromBuffer" */
            }
            else
            {
                xLockStatus = prvEnterCriticalAndLockSB( xStreamBuffer );
                /* MCDC Test Point: STD_ELSE "prvReadMessageFromBuffer" */
            }
            /* MCDC Test Point: STD_IF "prvReadMessageFromBuffer" */
        }
        /* MCDC Test Point: STD_ELSE "prvReadMessageFromBuffer" */

        if( pdPASS == xLockStatus )
        {
            /* Read the actual data. At this point we have already validated writing to puxReceivedLength but not pucRxData */
            xReturn = prvReadBytesFromBuffer( xStreamBuffer, pucRxData, uxNextMessageLength, uxBytesAvailable, puxReceivedLength, xIsInInterrupt );

            if( pdTRUE == xIsInInterrupt )
            {
                prvClearInterruptMaskAndUnlockSB( xStreamBuffer, uxSavedInterruptStatus );
                /* MCDC Test Point: STD_IF "prvReadMessageFromBuffer" */
            }
            else
            {
                prvExitCriticalAndUnlockSB( xStreamBuffer );
                /* MCDC Test Point: STD_ELSE "prvReadMessageFromBuffer" */
            }
            /* MCDC Test Point: STD_IF "prvReadMessageFromBuffer" */
        }
        /* MCDC Test Point: ADD_ELSE "prvReadMessageFromBuffer" */

        /* MCDC Test Point: STD_IF "prvReadMessageFromBuffer" */
    }
    /* MCDC Test Point: ADD_ELSE "prvReadMessageFromBuffer" */

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static void prvInitialiseNewStreamBuffer( StreamBufferHandle_t xStreamBuffer,
                                                          portUInt8Type *const pucBuffer,
                                                          portUnsignedBaseType uxBufferSizeBytes,
                                                          portUnsignedBaseType uxTriggerLevelBytes,
                                                          portUnsignedBaseType uxFlags )
{
    /* We do not need a critical section here. We can be called from two places:
     * 1. When creating a SB - only upon finishing the last line of code does the
     *    SB become valid so no other code can interact with this SB.
     * 2. When resetting an SB - then we are already in a critical section with a lock. */

    xStreamBuffer->xTaskWaitingToReceive     = NULL;
    xStreamBuffer->xTaskWaitingToSend        = NULL;
    xStreamBuffer->xTaskWaitingToReceiveCore = sbSTREAM_BUFFER_NO_CORE;
    xStreamBuffer->xTaskWaitingToSendCore    = sbSTREAM_BUFFER_NO_CORE;
    xStreamBuffer->uxTriggerLevelBytes       = uxTriggerLevelBytes;
    xStreamBuffer->uxBytesStored             = 0U;
    xStreamBuffer->uxFlags                   = uxFlags;
    xStreamBuffer->pucBuffer                 = pucBuffer;
    xStreamBuffer->uxLength                  = uxBufferSizeBytes;
    xStreamBuffer->uxBufferMirror            = ~( ( portDataAddressType ) pucBuffer );
    xStreamBuffer->uxLengthMirror            = ~uxBufferSizeBytes;

    /* MCDC Test Point: STD "prvInitialiseNewStreamBuffer" */
}
/*---------------------------------------------------------------------------*/

KERNEL_CREATE_FUNCTION static portBaseType prvCheckStreamBufferCreateParameters( portUnsignedBaseType uxBufferSizeBytes,
                                                                                 portUnsignedBaseType uxTriggerLevelBytes,
                                                                                 portUnsignedBaseType uxIsMessageBuffer,
                                                                                 portUInt8Type *const pucStreamBufferStorageArea,
                                                                                 StreamBuffer_t       *pxStreamBuffer,
                                                                                 StreamBufferHandle_t *pxStreamBufferHandle )
{
    portBaseType xReturn = pdPASS;

    /* Check that we have a non-NULL handle pointer with correct MPU perrmissions to pass back with */
    if( NULL == pxStreamBufferHandle )
    {
        xReturn = errNULL_PARAMETER_SUPPLIED;
        /* MCDC Test Point: STD_IF "prvCheckStreamBufferCreateParameters" */
    }
    /* MCDC Test Point: ADD_ELSE "prvCheckStreamBufferCreateParameters" */

    /* A trigger level of 0 would cause a waiting task to unblock even when the buffer was empty. */
    if( 0U == uxTriggerLevelBytes )
    {
        xReturn = errINVALID_PARAMETERS;
        /* MCDC Test Point: STD_IF "prvCheckStreamBufferCreateParameters" */
    }
    /* MCDC Test Point: ADD_ELSE "prvCheckStreamBufferCreateParameters" */

    if( 0U == uxBufferSizeBytes )
    {
        xReturn = errINVALID_BUFFER_SIZE;
        /* MCDC Test Point: STD_IF "prvCheckStreamBufferCreateParameters" */
    }
    /* MCDC Test Point: ADD_ELSE "prvCheckStreamBufferCreateParameters" */

    if( NULL == pucStreamBufferStorageArea )
    {
        xReturn = errNULL_PARAMETER_SUPPLIED;
        /* MCDC Test Point: STD_IF "prvCheckStreamBufferCreateParameters" */
    }
    /* MCDC Test Point: ADD_ELSE "prvCheckStreamBufferCreateParameters" */

    if( uxTriggerLevelBytes > uxBufferSizeBytes )
    {
        xReturn = errINVALID_PARAMETERS;
        /* MCDC Test Point: STD_IF "prvCheckStreamBufferCreateParameters" */
    }
    /* MCDC Test Point: ADD_ELSE "prvCheckStreamBufferCreateParameters" */

    /* uxBufferSizeBytes must be greater than message header if messages are being streamed. */
    /* MCDC Test Point: EXP_IF_AND "prvCheckStreamBufferCreateParameters" "( sbBYTES_TO_STORE_MESSAGE_LENGTH > uxBufferSizeBytes )" "( ( portUnsignedBaseType ) pdTRUE == uxIsMessageBuffer )" */
    if( ( sbBYTES_TO_STORE_MESSAGE_LENGTH > uxBufferSizeBytes ) &&
        ( ( portUnsignedBaseType ) pdTRUE == uxIsMessageBuffer ) )
    {
        xReturn = errSUPPLIED_BUFFER_TOO_SMALL;
        /* MCDC Test Point: STD_IF "prvCheckStreamBufferCreateParameters" */
    }
    /* MCDC Test Point: ADD_ELSE "prvCheckStreamBufferCreateParameters" */

    /* MCDC Test Point: EXP_IF_AND "prvCheckStreamBufferCreateParameters" "( ( portUnsignedBaseType ) pdTRUE != uxIsMessageBuffer )" "( ( portUnsignedBaseType ) pdFALSE != uxIsMessageBuffer )" "Deviate: FF" */
    if( ( ( portUnsignedBaseType ) pdTRUE != uxIsMessageBuffer ) && ( ( portUnsignedBaseType ) pdFALSE != uxIsMessageBuffer ) )
    {
        xReturn = errINVALID_PARAMETERS;
        /* MCDC Test Point: STD_IF "prvCheckStreamBufferCreateParameters" */
    }
    /* MCDC Test Point: ADD_ELSE "prvCheckStreamBufferCreateParameters" */

    if( NULL != pxStreamBuffer )
    {
        /* MCDC Test Point: EXP_IF_OR "prvCheckStreamBufferCreateParameters" "( 0U != pxStreamBuffer->uxLengthMirror )" "( 0U != pxStreamBuffer->uxBufferMirror )" */
        if( ( 0U != pxStreamBuffer->uxLengthMirror ) || ( 0U != pxStreamBuffer->uxBufferMirror ) )
        {
            xReturn = errSB_IN_USE;
            /* MCDC Test Point: STD_IF "prvCheckStreamBufferCreateParameters" */
        }
        /* MCDC Test Point: ADD_ELSE "prvCheckStreamBufferCreateParameters" */

        /* MCDC Test Point: STD_IF "prvCheckStreamBufferCreateParameters" */
    }
    else
    {
        xReturn = errNULL_PARAMETER_SUPPLIED;
        /* MCDC Test Point: STD_ELSE "prvCheckStreamBufferCreateParameters" */
    }

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvIsStreamBufferHandleValid( StreamBufferHandle_t xStreamBuffer )
{
    portBaseType xReturn =  pdTRUE;

    if( NULL == xStreamBuffer )
    {
        xReturn = errNULL_PARAMETER_SUPPLIED;
        /* MCDC Test Point: STD_IF "prvIsStreamBufferHandleValid" */
    }
    else
    {
        /* MCDC Test Point: EXP_IF_AND "prvIsStreamBufferHandleValid" "( ~( xStreamBuffer->uxLengthMirror ) != xStreamBuffer->uxLength )" "( ~( xStreamBuffer->uxBufferMirror ) != ( ( portDataAddressType ) xStreamBuffer->pucBuffer ) )" */
        if( ( ~( xStreamBuffer->uxLengthMirror ) != xStreamBuffer->uxLength ) ||
            ( ~( xStreamBuffer->uxBufferMirror ) != ( ( portDataAddressType ) xStreamBuffer->pucBuffer ) ) )
        {
            xReturn = errSB_INVALID_HANDLE;
            /* MCDC Test Point: STD_IF "prvIsStreamBufferHandleValid" */
        }
        /* MCDC Test Point: ADD_ELSE "prvIsStreamBufferHandleValid" */

        /* MCDC Test Point: STD_ELSE "prvIsStreamBufferHandleValid" */
    }

    return xReturn;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portUnsignedBaseType prvFindMinimumValue( portUnsignedBaseType uxA,
                                                                 portUnsignedBaseType uxB )
{
    portUnsignedBaseType uxReturn;

    if( uxA <= uxB )
    {
        uxReturn = uxA;
        /* MCDC Test Point: STD_IF "prvFindMinimumValue" */
    }
    else
    {
        uxReturn = uxB;
        /* MCDC Test Point: STD_ELSE "prvFindMinimumValue" */
    }

    return uxReturn;
}
/*---------------------------------------------------------------------------*/

/* This function will attempt to get the lock on the SB. It attempts this from within a
 * critical section so that if it does get the lock, it will not be pre-empted and therefore
 * will not hold the lock any longer than required. This is important to prevent the other
 * core from stalling if this streambuffer is being used in a multicore environment. If
 * we fail to get the lock, we do a task delay to allow other tasks to run while the SB is locked.
 * Returns pdPASS if the lock was acquired, returns pdFAIL otherwise.
 * Note: this is never called when the scheduler is suspended. */
KERNEL_FUNCTION static portBaseType prvEnterCriticalAndLockSB( StreamBufferHandle_t xStreamBufferHandle )
{
    portBaseType xLockStatus;
    portUnsignedBaseType uxIterations = 0U;

    do
    {
        portENTER_CRITICAL_WITHIN_API();
        xLockStatus = xStreamBufferAttemptToLock( xStreamBufferHandle );

        if( pdPASS != xLockStatus )
        {
            portEXIT_CRITICAL_WITHIN_API();

            if( configMAX_SB_LOCK_ATTEMPTS != uxIterations )
            {
                ( void ) xTaskDelayKrnl( sbONE_TICK );
                uxIterations++;
                xLockStatus = sbUNLOCKED_LOOP_AGAIN;

                /* MCDC Test Point: STD_IF "prvEnterCriticalAndLockSB" */
            }
            /* MCDC Test Point: ADD_ELSE "prvEnterCriticalAndLockSB" */

            /* MCDC Test Point: STD_IF "prvEnterCriticalAndLockSB" */
        }
        /* MCDC Test Point: ADD_ELSE "prvEnterCriticalAndLockSB" */

        /* MCDC Test Point: WHILE_INTERNAL "prvEnterCriticalAndLockSB" */
    } while( sbUNLOCKED_LOOP_AGAIN == xLockStatus );

    return xLockStatus;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static void prvExitCriticalAndUnlockSB( StreamBufferHandle_t xStreamBufferHandle )
{
    vStreamBufferReleaseLock( xStreamBufferHandle );
    portEXIT_CRITICAL_WITHIN_API();
    /* MCDC Test Point: STD "prvExitCriticalAndUnlockSB" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvSetInterruptMaskAndLockSB( StreamBufferHandle_t xStreamBufferHandle,
                                                                  portUnsignedBaseType *puxSavedInterruptStatus )
{
    portUnsignedBaseType uxSavedInterruptStatus;
    portBaseType xLockStatus;

    uxSavedInterruptStatus = safertosapiSET_INTERRUPT_MASK_FROM_ISR();
    xLockStatus = xStreamBufferAttemptToLock( xStreamBufferHandle );

    if( pdPASS != xLockStatus )
    {
        safertosapiCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );

        /* MCDC Test Point: STD_IF "prvSetInterruptMaskAndLockSB" */
    }
    else
    {
        *puxSavedInterruptStatus = uxSavedInterruptStatus;

        /* MCDC Test Point: STD_ELSE "prvSetInterruptMaskAndLockSB" */
    }

    return xLockStatus;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static void prvClearInterruptMaskAndUnlockSB( StreamBufferHandle_t xStreamBufferHandle,
                                                              portUnsignedBaseType uxSavedInterruptStatus )
{
    vStreamBufferReleaseLock( xStreamBufferHandle );
    safertosapiCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );
    /* MCDC Test Point: STD "prvClearInterruptMaskAndUnlockSB" */
}
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Weak functions                                                            */
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION portBaseType xStreamBufferAttemptToLock( StreamBufferHandle_t xStreamBufferHandle )
{
    ( void ) xStreamBufferHandle;
    /* MCDC Test Point: STD "WEAK_xStreamBufferAttemptToLock" */

    return pdPASS;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION void vStreamBufferReleaseLock( StreamBufferHandle_t  xStreamBufferHandle )
{
    ( void ) xStreamBufferHandle;
    /* MCDC Test Point: STD "WEAK_vStreamBufferReleaseLock" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION void vStreamBufferSendCompletedMulticore( StreamBufferHandle_t xStreamBufferHandle )
{
    ( void ) xStreamBufferHandle;
    /* MCDC Test Point: STD "WEAK_vStreamBufferSendCompletedMulticore" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION void vStreamBufferSendCompletedFromISRMulticore( StreamBufferHandle_t xStreamBufferHandle )
{
    ( void ) xStreamBufferHandle;
    /* MCDC Test Point: STD "WEAK_vStreamBufferSendCompletedFromISRMulticore" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION void vStreamBufferReceiveCompletedMulticore( StreamBufferHandle_t xStreamBufferHandle )
{
    ( void ) xStreamBufferHandle;
    /* MCDC Test Point: STD "WEAK_vStreamBufferReceiveCompletedMulticore" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION void vStreamBufferReceiveCompletedFromISRMulticore( StreamBufferHandle_t xStreamBufferHandle )
{
    ( void ) xStreamBufferHandle;
    /* MCDC Test Point: STD "WEAK_vStreamBufferReceiveCompletedFromISRMulticore" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION void vStreamBufferRegisterMulticoreRxWaiting( StreamBufferHandle_t xStreamBufferHandle )
{
    ( void ) xStreamBufferHandle;
    /* MCDC Test Point: STD "WEAK_vStreamBufferRegisterMulticoreRxWaiting" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION void vStreamBufferRegisterMulticoreRxTimeout( StreamBufferHandle_t xStreamBufferHandle )
{
    ( void ) xStreamBufferHandle;
    /* MCDC Test Point: STD "WEAK_vStreamBufferRegisterMulticoreRxTimeout" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION void vStreamBufferRegisterMulticoreTxWaiting( StreamBufferHandle_t xStreamBufferHandle )
{
    ( void ) xStreamBufferHandle;
    /* MCDC Test Point: STD "WEAK_vStreamBufferRegisterMulticoreTxWaiting" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION void vStreamBufferRegisterMulticoreTxTimeout( StreamBufferHandle_t xStreamBufferHandle )
{
    ( void ) xStreamBufferHandle;
    /* MCDC Test Point: STD "WEAK_vStreamBufferRegisterMulticoreTxTimeout" */
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* SAFERTOSTRACE SETSTREAMBUFFERNUMBERDEF */
/*---------------------------------------------------------------------------*/
/* SAFERTOSTRACE GETSTREAMBUFFERNUMBERDEF */
/*---------------------------------------------------------------------------*/
/* SAFERTOSTRACE GETSTREAMBUFFERTYPEDEF */
/*---------------------------------------------------------------------------*/

#ifdef SAFERTOS_TEST
    #include "SectionLocationCheckList_streambufferc.h"
    #ifdef SAFERTOS_MODULE_TEST
        #include "StreamBufferTestHeaders.h"
        #include "StreamBufferTest.h"
    #endif
#endif
