/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#include "ti/csl/soc.h"
#include <ti/csl/csl_clec.h>
#include "Mmu.h"

/*-----------------------------------------------------------------------------
 * Private function definitions.
 *---------------------------------------------------------------------------*/

static void prvMmuInit( Bool isSecure )
{
    Mmu_MapAttrs    attrs;

    Mmu_initMapAttrs( &attrs );
    attrs.attrIndx = Mmu_AttrIndx_MAIR0;

    if( TRUE == isSecure )
    {
        attrs.ns = 0;
    }
    else
    {
        attrs.ns = 1;
    }

    /* Register region */
    ( void )Mmu_map( 0x00000000U, 0x00000000U, 0x20000000U, &attrs, isSecure );
    ( void )Mmu_map( 0x20000000U, 0x20000000U, 0x20000000U, &attrs, isSecure );
    ( void )Mmu_map( 0x40000000U, 0x40000000U, 0x20000000U, &attrs, isSecure );
    ( void )Mmu_map( 0x60000000U, 0x60000000U, 0x10000000U, &attrs, isSecure );
    ( void )Mmu_map( 0x78000000U, 0x78000000U, 0x08000000U, &attrs, isSecure ); /* CLEC */

    attrs.attrIndx = Mmu_AttrIndx_MAIR7;
    ( void )Mmu_map( 0x80000000U, 0x80000000U, 0x20000000U, &attrs, isSecure ); /* DDR */
    ( void )Mmu_map( 0xA0000000U, 0xA0000000U, 0x20000000U, &attrs, isSecure ); /* DDR */
    ( void )Mmu_map( 0x70000000U, 0x70000000U, 0x00800000U, &attrs, isSecure ); /* MSMC - 8MB */
    ( void )Mmu_map( 0x41C00000U, 0x41C00000U, 0x00080000U, &attrs, isSecure ); /* OCMC - 512KB */

    /*
     * DDR range 0xA0000000 - 0xAA000000 : Used as RAM by multiple
     * remote cores, no need to mmp_map this range.
     * IPC VRing Buffer - uncached
     */
    attrs.attrIndx =  Mmu_AttrIndx_MAIR4;
    ( void )Mmu_map( 0xAA000000U, 0xAA000000U, 0x02000000U, &attrs, isSecure );

    return;
}
/*-------------------------------------------------------------------------*/

void prvCfgClecAccessCtrl ( Bool onlyInSecure )
{
    CSL_ClecEventConfig cfgClec;
    CSL_CLEC_EVTRegs   *clecBaseAddr = ( CSL_CLEC_EVTRegs* ) CSL_COMPUTE_CLUSTER0_CLEC_BASE;
    uint32_t            i, maxInputs = 2048U;

    cfgClec.secureClaimEnable = onlyInSecure;
    cfgClec.evtSendEnable     = FALSE;
    cfgClec.rtMap             = CSL_CLEC_RTMAP_DISABLE;
    cfgClec.extEvtNum         = 0U;
    cfgClec.c7xEvtNum         = 0U;
    for(i = 0U; i < maxInputs; i++)
    {
        CSL_clecConfigEvent( clecBaseAddr, i, &cfgClec );
    }
}
/*-------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * Public function definitions.
 *---------------------------------------------------------------------------*/

void vInitMmu( void )
{
    prvMmuInit( false );
    prvMmuInit( true );

    /* Setup CLEC access/configure in non-secure mode */
    prvCfgClecAccessCtrl( false );
}
/*-------------------------------------------------------------------------*/


