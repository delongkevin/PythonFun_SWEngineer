/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#include <stddef.h>

/* SafeRTOS includes */

#include "SafeRTOS_API.h"
#include "FullDemo.h"
#include "aborts.h"
#include "PortSpecifics.h"

/* Demo application include files. These files are common to all demo
 * applications. */
#include "MathsTest.h"
#include "BlockQ.h"
#include "blocktim.h"
#include "dynamic.h"
#include "PollQ.h"
#include "semtest.h"
#include "countsem.h"
#include "TimerDemo.h"
#include "TaskNotify.h"
#include "TaskMutex.h"
#include "EvtMplxDemo.h"
#include "TaskCreateDeleteDemo.h"
#include "flash.h"
#include "partest.h"

/* Demo application include files specific to this demo. */

#if ( configINCLUDE_CRC_FEATURE == 1 )
    #include "CRCTest.h"
    #include "CRCTestFailure.h"
#endif

/*---------------------------------------------------------------------------*/
/* Local constant definitions                                                */
/*---------------------------------------------------------------------------*/

/* Task priorities.
 * The lowest priority is always Zero (0).
 * The highest priority is (configMAX_PRIORITIES - 1).
 * Any number of tasks can share the same priority.
 * Note, the timer task priority is set in "FullDemo.h". */
#define fulldemoCHECK_TASK_PRIORITY             ( 4U )
#define fulldemoBLOCKING_QUEUE_TASKS_PRIORITY   ( 1U )
#define fulldemoSUICIDAL_TASKS_PRIORITY         ( 1U )
#define fulldemoFLASH_LED_TASKS_PRIORITY        ( 1U )
#define fulldemoPOLLED_QUEUE_TASKS_PRIORITY     ( 0U )
#define fulldemoSEMAPHORE_TASKS_PRIORITY        ( 1U )
#define fulldemoCOM_TEST_TASK_PRIORITY          ( 3U )
#define fulldemoSTREAM_BUFFER_TASKS_PRIORITY    ( 2U )

/*-----------------------------------------------------------------------------
 * Demonstration Task Executable Configuration
 *---------------------------------------------------------------------------*/

/* This block of demo tasks should execute on any SafeRTOS implementation
 * provided sufficient run time and RAM is available. */
/* Set to '1' to Enable or '0' to Disable */
#define fulldemoINCLUDE_FLASH_DEMO              ( 0 )   /* Not currently supported. */
#define fulldemoINCLUDE_POLL_Q_DEMO             ( 1 )
#define fulldemoINCLUDE_BLOCK_Q_DEMO            ( 1 )
#define fulldemoINCLUDE_DYNAMIC_DEMO            ( 1 )
#define fulldemoINCLUDE_SEMA_COUNT_DEMO         ( 1 )
#define fulldemoINCLUDE_SEMA_BINARY_DEMO        ( 1 )
#define fulldemoINCLUDE_TIMER_DEMO              ( 1 )
#define fulldemoINCLUDE_CREATE_DELETE_DEMO      ( 1 )
#define fulldemoINCLUDE_TASK_NOTIFY_DEMO        ( 1 )
#define fulldemoINCLUDE_SC_TEST_DEMO            ( 1 )
#define fulldemoINCLUDE_REC_MUTEX_DEMO          ( 1 )
#define fulldemoINCLUDE_EVT_MPLX_DEMO           ( 1 )
#define fulldemoINCLUDE_STREAM_BUFFER_DEMO      ( 1 )

/* The block time demo is very processor intensive and can be disabled in
 * demo applications that use processors with lower clock speeds. */
#define fulldemoINCLUDE_BLOCK_TIME_DEMO         ( 1 )

/* The Maths task demo is intended for processors that implement a floating
 * point unit (FPU). */
#define fulldemoINCLUDE_MATHS_DEMO              ( 1 )

/* The com test demo requires a serial port driver that implements either an
 * external or internal loopback. */
#define fulldemoINCLUDE_COM_TEST_DEMO           ( 0 )   /* Not currently supported. */

/* Base periods of the timers used in the timer and task notify demo. */
#define fulldemoTIMER_TEST_PERIOD                               ( ( portTickType ) 50U )
#define fulldemoTASK_NOTIFY_PERIOD                              ( ( portTickType ) 50U )

/* Check task operational definitions. */
#define fulldemoCHECK_TASK_STACK_SIZE                           ( configMINIMAL_STACK_SIZE )

/* The rate at which the check task cycles. */
#define fulldemoCHECK_TASK_NORMAL_CYCLE_RATE                    ( ( portTickType ) 5000U / configTICK_RATE_MS  )
#define fulldemoCHECK_TASK_ERROR_CYCLE_RATE                     ( ( portTickType ) 1000U / configTICK_RATE_MS  )

/* Check task error identifiers.
 * Used to keep track of errors that may have been detected. */
#define fulldemoCHECK_TASK_ERROR_MATHS_TASKS                    ( ( portUInt32Type ) 0x00000002UL )
#define fulldemoCHECK_TASK_ERROR_BLOCKING_QUEUES                ( ( portUInt32Type ) 0x00000004UL )
#define fulldemoCHECK_TASK_ERROR_BLOCK_TIME_TEST                ( ( portUInt32Type ) 0x00000008UL )
#define fulldemoCHECK_TASK_ERROR_DYNAMIC_PRIORITIES             ( ( portUInt32Type ) 0x00000010UL )
#define fulldemoCHECK_TASK_ERROR_POLLING_QUEUES                 ( ( portUInt32Type ) 0x00000020UL )
#define fulldemoCHECK_TASK_ERROR_BINARY_SEMAPHORES              ( ( portUInt32Type ) 0x00000040UL )
#define fulldemoCHECK_TASK_ERROR_COUNTING_SEMAPHORES            ( ( portUInt32Type ) 0x00000080UL )
#define fulldemoCHECK_TASK_ERROR_TIMER_TASKS                    ( ( portUInt32Type ) 0x00000100UL )
#define fulldemoCHECK_TASK_ERROR_TASK_NOTIFY                    ( ( portUInt32Type ) 0x00000200UL )
#define fulldemoCHECK_TASK_ERROR_RECURSIVE_MUTEX                ( ( portUInt32Type ) 0x00000400UL )
#define fulldemoCHECK_TASK_ERROR_EVT_MPLX_DEMO                  ( ( portUInt32Type ) 0x00000800UL )
#define fulldemoCHECK_TASK_ERROR_CREATE_TASKS                   ( ( portUInt32Type ) 0x00001000UL )
#define fulldemoCHECK_TASK_ERROR_SC_COUNT                       ( ( portUInt32Type ) 0x00002000UL )
#define fulldemoCHECK_TASK_ERROR_SC_RETURN                      ( ( portUInt32Type ) 0x00004000UL )
#define fulldemoCHECK_TASK_ERROR_TICK_HOOK                      ( ( portUInt32Type ) 0x00008000UL )
#define fulldemoCHECK_TASK_ERROR_TICK_HOOK_COUNT                ( ( portUInt32Type ) 0x00010000UL )
#define fulldemoCHECK_TASK_ERROR_IDLE_TASK                      ( ( portUInt32Type ) 0x00020000UL )
#define fulldemoCHECK_TASK_ERROR_INSUFFICIENT_IDLE              ( ( portUInt32Type ) 0x00040000UL )
#define fulldemoCHECK_TASK_ERROR_EXCESSIVE_IDLE                 ( ( portUInt32Type ) 0x00080000UL )
#define fulldemoCHECK_TASK_ERROR_CRC_TEST_TASKS                 ( ( portUInt32Type ) 0x00100000UL )
#define fulldemoCHECK_TASK_ERROR_CRC_TASK                       ( ( portUInt32Type ) 0x00200000UL )

/* Locate the idle hook data in a known location. */
#define fulldemoIDLE_HOOK_DATA_SECTION                          __attribute__ ( ( section ( "__idle_hook_data__" ) ) )

/* Idle task CPU Usage limits. */
#define fulldemoIDLE_TASK_MINIMUM_CPU_PERCENTAGE        ( 5U )      /* 0.05% */
#define fulldemoIDLE_TASK_MAXIMUM_CPU_PERCENTAGE        ( 200U )    /* 2.00% */

/* LEDs */
#define fulldemoLED_CHECK_TASK      ( partestLED_0 )
#define fulldemoLED_COMTEST_TASK    ( partestLED_NONE )


/*---------------------------------------------------------------------------*/
/* External variable declarations                                            */
/*---------------------------------------------------------------------------*/
#if ( configINCLUDE_CRC_FEATURE == 1 )
    extern portTaskHandleType xCRCFailTestTaskHandle;
#endif


/*---------------------------------------------------------------------------*/
/* Local function declarations                                               */
/*---------------------------------------------------------------------------*/
/* The body of the check task. */
static void prvCheckTask( void *pvParameters );

#if ( fulldemoINCLUDE_SC_TEST_DEMO == 1 )
/* Function to trigger an SC function with no arguments or return value. */
#define prvDemoApplicationScIncrValue() vPortSystemCall( fulldemoSC_INCREMENT_VALUE )

portUInt64Type ulDemoApplicationScAdd64Bit( portUInt64Type uxValue );

portUnsignedBaseType uxDemoApplicationScFourParams( portUInt32Type ulArg1,
                                                     portUInt32Type ulArg2,
                                                     portUInt32Type ulArg3,
                                                     portUInt32Type ulArg4 );

static void prvDemoApplicationScIncrValueFunc( void );

static portUInt64Type prulDemoApplicationScAdd64BitFunc( portUInt64Type ulValue );

static portUnsignedBaseType pruxDemoApplicationScFourParamsFunc( portUInt32Type ulArg1,
                                                                 portUInt32Type ulArg2,
                                                                 portUInt32Type ulArg3,
                                                                 portUInt32Type ulArg4 );
#else
/* Define away functions hidden by the fulldemoINCLUDE_SC_TEST_DEMO macro. */
#define prvDemoApplicationScIncrValueFunc()
#define prulDemoApplicationScAdd64BitFunc( ulValue )                            ( 0ul )
#define pruxDemoApplicationScFourParamsFunc( ulArg1, ulArg2, ulArg3, ulArg4 )   ( 0ul )
#endif /* ( fulldemoINCLUDE_SC_TEST_DEMO ) */


/*---------------------------------------------------------------------------*/
/* Local variable definitions                                                */
/*---------------------------------------------------------------------------*/

/* Incremented in the idle task hook so the check task can ensure the idle task
 * hook function is being called as expected. */
fulldemoIDLE_HOOK_DATA_SECTION static volatile portUInt32Type ulIdleHookCallCount = 0U;

/* Incremented within the tick hook so the check task can ensure the tick hook
 * is being called. */
static volatile portUInt32Type ulTickHookCallCount = 0U;

/* The first time the idle task runs, it stores its task handle, so the check
 * task can query its runtime statistics. */
fulldemoIDLE_HOOK_DATA_SECTION static portTaskHandleType xIdleTaskHandle = NULL;
fulldemoIDLE_HOOK_DATA_SECTION static portBaseType xIdleTaskFirstExecution = pdTRUE;

#if ( fulldemoINCLUDE_SC_TEST_DEMO == 1 )
/* Accumulators and counter to test the SC hook. */
static volatile portUnsignedBaseType uxScCounter = 0U;
static volatile portUnsignedBaseType uxScAccum = 0U;
static volatile portUInt64Type ulSc64bitAccum = 0x1234567812345678ul;
#endif /* ( fulldemoINCLUDE_SC_TEST_DEMO == 1 ) */

/* Declare the TCB of the check task.
 * Due to the use of the MPU background region, by default, all RAM can only
 * be accessed in privileged mode unless a specific MPU region has been setup
 * allowing unprivileged access. */
static xTCB xCheckTaskTCB = { 0 };

/* Declare task stacks :
 * These ARE protected by MPU regions so the alignment must follow the
 * MPU alignment rules, and basically be aligned to the same power of two
 * value as their length in bytes. */
static portInt8Type acCheckTaskStack[ fulldemoCHECK_TASK_STACK_SIZE ] __attribute__ ( ( aligned ( safertosapiSTACK_ALIGNMENT ) ) );



/*---------------------------------------------------------------------------*/
/* Public function definitions                                               */
/*---------------------------------------------------------------------------*/

portBaseType xFullDemoCreate( void )
{
    portBaseType xCreateResult;

    /* The structure passed to xTaskCreate() to create the check task. */
    static const xTaskParameters xCheckTaskParams =
    {
        &prvCheckTask,                  /* The function that implements the task being created. */
        "Check Task",                   /* The name of the task being created. The kernel does not use this itself, its just to assist debugging. */
        &xCheckTaskTCB,                 /* TCB for the check task. */
        acCheckTaskStack,               /* The buffer allocated for use as the task stack. */
        fulldemoCHECK_TASK_STACK_SIZE,  /* The size of the buffer allocated for use as the task stack - note this is in BYTES! */
        NULL,                           /* The task parameter, not used in this case. */
        fulldemoCHECK_TASK_PRIORITY,    /* The priority to assigned to the task being created. */
        NULL                            /* Thread Local Storage not used. */
    };

    /* Create the check task. */
    xCreateResult = xTaskCreate( &xCheckTaskParams, /* The structure containing the task parameters created at the start of this function. */
                                 NULL );            /* This parameter can be used to receive a handle to the created task, but is not used in this case. */

    /**************************************************************************
     * The first block of standard demo tasks are dependent on the hardware
     * capability of either the processor or target hardware and hence
     * inclusion is decided by project level settings.
     *************************************************************************/

#if ( fulldemoINCLUDE_COM_TEST_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xAltStartComTestTasks( fulldemoCOM_TEST_TASK_PRIORITY,
                                               fulldemoLED_COMTEST_TASK );
    }
#endif

    /**************************************************************************
     * The second block of standard demo tasks are not dependent on the
     * hardware capability of either the processor or target hardware and
     * therefore their inclusion is a matter of preference and controlled
     * by settings in this file.
     *************************************************************************/

#if ( fulldemoINCLUDE_FLASH_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartLEDFlashTasks( fulldemoFLASH_LED_TASKS_PRIORITY );
    }
#endif

#if ( fulldemoINCLUDE_MATHS_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartMathsTasks();
    }
#endif

#if ( fulldemoINCLUDE_BLOCK_Q_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartBlockingQueueTasks( fulldemoBLOCKING_QUEUE_TASKS_PRIORITY );
    }
#endif

#if ( fulldemoINCLUDE_BLOCK_TIME_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xCreateBlockTimeTasks();
    }
#endif

#if ( fulldemoINCLUDE_DYNAMIC_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartDynamicPriorityTasks();
    }
#endif

#if ( fulldemoINCLUDE_POLL_Q_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartPolledQueueTasks( fulldemoPOLLED_QUEUE_TASKS_PRIORITY );
    }
#endif

#if ( fulldemoINCLUDE_SEMA_BINARY_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartSemaphoreTasks( fulldemoSEMAPHORE_TASKS_PRIORITY );
    }
#endif

#if ( fulldemoINCLUDE_SEMA_COUNT_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartCountingSemaphoreTasks();
    }
#endif

#if ( fulldemoINCLUDE_TIMER_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartTimerDemoTask( fulldemoTIMER_TEST_PERIOD,
                                             fulldemoTIMER_CMD_QUEUE_LEN,
                                             fulldemoTIMER_TASK_PRIORITY );
    }
#endif

#if ( fulldemoINCLUDE_TASK_NOTIFY_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartTaskNotifyTask( fulldemoTASK_NOTIFY_PERIOD,
                                              fulldemoTIMER_TASK_PRIORITY );
    }
#endif

#if ( fulldemoINCLUDE_REC_MUTEX_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartRecursiveMutexTasks();
    }
#endif

#if ( fulldemoINCLUDE_EVT_MPLX_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartEvtMplxDemoTasks();
    }
#endif

#if ( fulldemoINCLUDE_CREATE_DELETE_DEMO == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartTaskCreateDeleteDemo( fulldemoSUICIDAL_TASKS_PRIORITY );
    }
#endif

#if ( configINCLUDE_CRC_FEATURE == 1 )
    if( pdPASS == xCreateResult )
    {
        xCreateResult = xStartCRCTest();
    }
#endif

    return xCreateResult;
}
/*---------------------------------------------------------------------------*/

void vApplicationIdleHook( void )
{
    /* Is this the first time that the idle task hook has executed? */
    if( pdFALSE != xIdleTaskFirstExecution )
    {
        /* Yes, clear the flag. */
        xIdleTaskFirstExecution = pdFALSE;

        /* Now store a copy of our task handle so that the check task
         * can examine the runtime statistics of the idle task. */
        xIdleTaskHandle = xTaskGetCurrentTaskHandle();
    }

    /* Increment a counter so the check task can see that the idle task is
     * still running. */
    ulIdleHookCallCount++;
}
/*---------------------------------------------------------------------------*/

void vApplicationTickHook( void )
{
    if( pdTRUE == xTaskIsSchedulerStartedFromISR() )
    {
#if ( fulldemoINCLUDE_TIMER_DEMO == 1 )
        /* Call the periodic timer test, which tests the timer API functions that
         * can be called from an ISR. */
        vTimerPeriodicISRTests();
#endif

#if ( fulldemoINCLUDE_TASK_NOTIFY_DEMO == 1 )
    /* Call the periodic notify test, which tests the task notify API functions
     * that can be called from an ISR. */
    vNotifyTaskFromISR();
#endif
    }

    /* Increment a counter so the check task can see that the tick hook is
     * being called. */
    ulTickHookCallCount++;

    /* Context switch if needed. */
    safertosapiYIELD_FROM_ISR();
}
/*---------------------------------------------------------------------------*/

void vApplicationTaskDeleteHook( portTaskHandleType xTaskBeingDeleted )
{
    /* We need to figure out if this task being deleted was one of the self-deleting tasks.
     * If so, we should increment the count used by the check task for the self-deleting demo */
    if( ( &xDummyTaskTCB == (  xTCB * ) xTaskBeingDeleted ) ||
        ( &xDeleterTaskTCB == (  xTCB * ) xTaskBeingDeleted ) )
    {
        uxCreateDeleteDemoDeleteCount++;
    }
}
/*---------------------------------------------------------------------------*/

void vApplicationErrorHook( portTaskHandleType xHandleOfTaskWithError,
                            portBaseType xErrorCode )
{
    /* The parameters are not used, these lines prevent compiler warnings. */
    ( void ) xHandleOfTaskWithError;
    ( void ) xErrorCode;

    /* Will only get here if an internal kernel error occurs. */
    vApplicationAbort();
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Local function definitions                                                */
/*---------------------------------------------------------------------------*/

#if ( fulldemoINCLUDE_SC_TEST_DEMO == 1 )

/* SC hook function*/

portUInt64Type ulDemoApplicationScHook( portUnsignedBaseType uxSCNum,
                                        portUnsignedBaseType uxArg1,
                                        portUnsignedBaseType uxArg2,
                                        portUnsignedBaseType uxArg3,
                                        portUnsignedBaseType uxArg4 )
{
    portUInt64Type ulRetVal = 0ul;
    portUnsignedBaseType ulTemp = 0ul;

    switch( uxSCNum )
    {
        case fulldemoSC_INCREMENT_VALUE:
            prvDemoApplicationScIncrValueFunc();
            ulRetVal = 0ull;
            break;

        case fulldemoSC_ADD_64BIT:
            ulRetVal = prulDemoApplicationScAdd64BitFunc( uxArg1 );
            break;

        case fulldemoSC_FOUR_PARAMS:
            ulTemp = pruxDemoApplicationScFourParamsFunc( uxArg1, uxArg2, uxArg3, uxArg4 );
            ulRetVal = ( portUInt64Type ) ulTemp;
            break;

        default:
            break;
    }

    return ulRetVal;
}
/*---------------------------------------------------------------------------*/

/* Sub-handler called via SC hook for the vDemoApplicationScIncrValue()
 * pseudo-function. Void with no parameters. */
static void prvDemoApplicationScIncrValueFunc( void )
{
    uxScCounter++;
}
/*---------------------------------------------------------------------------*/

/* Sub-handler called via SC hook for the uxDemoApplicationScAdd64Bit()
 * pseudo-function. Returns a 64bit value, one 64bit parameter. */
static portUInt64Type prulDemoApplicationScAdd64BitFunc( portUInt64Type ulValue )
{
    portUInt64Type ulResult;

    /* Add a 64bit arg, and current count, to 64bit accumulator. */
    ulResult = uxScCounter + ulValue;
    ulSc64bitAccum += ulResult;
    uxScCounter++;

    return ulSc64bitAccum;
}
/*---------------------------------------------------------------------------*/

/* Sub-handler called via SC hook for the ulDemoApplicationScFourParams()
 * pseudo-function. Returns a 32bit value. Four 32bit parameters. */
static portUnsignedBaseType pruxDemoApplicationScFourParamsFunc( portUInt32Type ulArg1,
                                                                  portUInt32Type ulArg2,
                                                                  portUInt32Type ulArg3,
                                                                  portUInt32Type ulArg4  )
{
    /* Do some arbitrary stuff with the four arguments. */
    ulArg1 += uxScCounter;
    uxScAccum += ulArg1;
    uxScAccum *= ulArg2;
    uxScAccum &= ulArg3;
    uxScAccum *= ulArg4;
    uxScCounter++;

    return uxScAccum;
}
/*---------------------------------------------------------------------------*/
#endif

static void prvCheckTask( void *pvParameters )
{
    portBaseType xCheckStatus;
    portTickType xLastTime;
    portTickType xCheckTaskCycleRate;
    portUInt32Type ulCheckTaskCycleCount = 0U;
    portUInt32Type ulErrorsDetected = 0U;
    portUInt32Type ulIdleHookLastCount = 0U;
    portUInt32Type ulTickHookLastCount = 0U;

#if ( fulldemoINCLUDE_SC_TEST_DEMO == 1 )
    portUnsignedBaseType uxCachedScCounter = 0U;
    portUInt64Type uxScCheck64BitVal = 0UL;
    portUnsignedBaseType uxScCheck4ArgsVal = 0UL;
#endif

    /* The parameters are not used in this task. This just prevents a compiler
     * warning. */
    ( void ) pvParameters;

    /* No errors have been detected yet. */
    xCheckTaskCycleRate = fulldemoCHECK_TASK_NORMAL_CYCLE_RATE;

    /* Initialise the variable used in calls to xTaskDelayUntil() to control
     * the tasks execution period to the current time. */
    xLastTime = xTaskGetTickCount();

    /* Forever loop... */
    for( ;; )
    {
        /* Delay until the next check time. */
        ( void ) xTaskDelayUntil( &xLastTime, xCheckTaskCycleRate );

        /**********************************************************************
         * Check Demo Test operations.
         **********************************************************************
         * Ask each set of demo tasks to report their status.
         **********************************************************************
         * This set of demo tasks reported an error.
         * Send an error message to the display task and latch that an error
         * has occurred during this loop.
         * Note that only a pointer to the error message is actually queued so
         * this assumes the string is in const, non-stack memory.
         * This assumption is fine for a simple demo, but not for a high
         * integrity application!
         *********************************************************************/

        /**********************************************************************
         * The first block of standard demo tasks are dependent on the hardware
         * capability of either the processor or target hardware and hence
         * inclusion is decided by project level settings.
         *********************************************************************/

#if ( fulldemoINCLUDE_COM_TEST_DEMO == 1 )
        /* Check COM Test tasks. */
        xCheckStatus = xAreComTestTasksStillRunning();
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_COM_TEST;
        }
#endif

#if ( fulldemoINCLUDE_SC_TEST_DEMO == 1 )

        /* SC call with no arguments or return value. */
        prvDemoApplicationScIncrValue();

        if( uxCachedScCounter == uxScCounter )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_SC_COUNT;
        }
        else
        {
            uxCachedScCounter = uxScCounter;
        }

        /* SC call with a 64bit arg and 64bit return. */
        uxScCheck64BitVal = ulDemoApplicationScAdd64Bit( 0x0000432100009876UL );

        if( uxScCheck64BitVal != ulSc64bitAccum )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_SC_RETURN;
        }

        if( uxCachedScCounter == uxScCounter )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_SC_COUNT;
        }
        else
        {
            uxCachedScCounter = uxScCounter;
        }

        /* SC with four 64bit args and a 64bit return value. */
        uxScCheck4ArgsVal = uxDemoApplicationScFourParams( 123UL,
                                                             99UL,
                                                             0x5555AAAAUL,
                                                             78UL );

        if( uxScCheck4ArgsVal != uxScAccum )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_SC_RETURN;
        }

        if( uxCachedScCounter == uxScCounter )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_SC_COUNT;
        }
        else
        {
            uxCachedScCounter = uxScCounter;
        }

#endif
#if ( configINCLUDE_CRC_FEATURE == 1 )
        /* NOTE that this test leads to the creation and deletion of a CRC task.
         * Since the deletion of the CRC task calls the task delete hook, the
         * hook function must be written in such a way as not to interfere with
         * the create delete task test. */
        xCheckStatus = xTestCRCFailureReporting();
        if( pdPASS != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_CRC_TEST_TASKS;
        }

        xCheckStatus = xMonitorCRCTest();
        if( pdPASS != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_CRC_TASK;
        }
#endif

        /**********************************************************************
         * The second block of standard demo tasks are not dependent on the
         * hardware capability of either the processor or target hardware and
         * therefore their inclusion is a matter of preference and controlled
         * by settings in this file.
         *********************************************************************/

#if ( fulldemoINCLUDE_MATHS_DEMO == 1 )
        /* Check Math Test tasks. */
        xCheckStatus = xAreMathsTasksStillRunning();
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_MATHS_TASKS;
        }
#endif

#if ( fulldemoINCLUDE_BLOCK_Q_DEMO == 1 )
        /* Check Blocking Queue tasks. */
        xCheckStatus = xAreBlockingQueuesStillRunning();
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_BLOCKING_QUEUES;
        }
#endif

#if ( fulldemoINCLUDE_BLOCK_TIME_DEMO == 1 )
        /* Check Blocking Time tasks. */
        xCheckStatus = xAreBlockTimeTestTasksStillRunning();
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_BLOCK_TIME_TEST;
        }
#endif

#if ( fulldemoINCLUDE_DYNAMIC_DEMO == 1 )
        /* Check Dynamic tasks. */
        xCheckStatus = xAreDynamicPriorityTasksStillRunning();
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_DYNAMIC_PRIORITIES;
        }
#endif

#if ( fulldemoINCLUDE_POLL_Q_DEMO == 1 )
        /* Check Polled Queue tasks. */
        xCheckStatus = xArePollingQueuesStillRunning();
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_POLLING_QUEUES;
        }
#endif

#if ( fulldemoINCLUDE_SEMA_BINARY_DEMO == 1 )
        /* Check Binary Semaphore tasks. */
        xCheckStatus = xAreSemaphoreTasksStillRunning();
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_BINARY_SEMAPHORES;
        }
#endif

#if ( fulldemoINCLUDE_SEMA_COUNT_DEMO == 1 )
        /* Check Counting Semaphore tasks. */
        xCheckStatus = xAreCountingSemaphoreTasksStillRunning();
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_COUNTING_SEMAPHORES;
        }
#endif

#if ( fulldemoINCLUDE_TIMER_DEMO == 1 )
        xCheckStatus = xAreTimerDemoTasksStillRunning( xCheckTaskCycleRate,
                                                       fulldemoTIMER_CMD_QUEUE_LEN );
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_TIMER_TASKS;
        }
#endif

#if ( fulldemoINCLUDE_TASK_NOTIFY_DEMO == 1 )
        /* Check Task Notify demo. */
        xCheckStatus = xAreTaskNotificationTasksStillRunning();

        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_TASK_NOTIFY;
        }
#endif

#if ( fulldemoINCLUDE_CREATE_DELETE_DEMO == 1 )
        /* Check Suicide tasks. */
        xCheckStatus = xIsCreateTaskStillRunning();
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_CREATE_TASKS;
        }
#endif

#if ( fulldemoINCLUDE_EVT_MPLX_DEMO )
        /* Check the Event Multiplex demo tasks. */
        xCheckStatus = xAreEvtMplxDemoTasksStillRunning();
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_EVT_MPLX_DEMO;
        }
#endif

#if ( fulldemoINCLUDE_REC_MUTEX_DEMO == 1 )
        xCheckStatus = xAreRecursiveMutexTasksStillRunning();
        if( pdTRUE != xCheckStatus )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_RECURSIVE_MUTEX;
        }
#endif

        /**********************************************************************
         * Check SafeRTOS operating parameters.
         *********************************************************************/

        /* Check that the Tick Hook is being called. */
        if( ulTickHookCallCount == ulTickHookLastCount )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_TICK_HOOK;
        }
        ulTickHookLastCount = ulTickHookCallCount;

        /* Check that the Idle hook is being called. */
        if( ulIdleHookCallCount == ulIdleHookLastCount )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_IDLE_TASK;
        }
        ulIdleHookLastCount = ulIdleHookCallCount;

        /* Check that the tick hook has been called at every tick. */
        if( xTaskGetTickCount() != ulTickHookCallCount )
        {
            ulErrorsDetected |= fulldemoCHECK_TASK_ERROR_TICK_HOOK_COUNT;
        }
        /* If an error has been detected... toggle check LED faster
         * to give a visible indication of the error detection. */
        if( 0UL != ulErrorsDetected )
        {
            xCheckTaskCycleRate = fulldemoCHECK_TASK_ERROR_CYCLE_RATE;
        }
        ulCheckTaskCycleCount++;

        /* Toggle the check task LED. */
        vParTestToggleLED( fulldemoLED_CHECK_TASK );
    }
}
/*---------------------------------------------------------------------------*/
