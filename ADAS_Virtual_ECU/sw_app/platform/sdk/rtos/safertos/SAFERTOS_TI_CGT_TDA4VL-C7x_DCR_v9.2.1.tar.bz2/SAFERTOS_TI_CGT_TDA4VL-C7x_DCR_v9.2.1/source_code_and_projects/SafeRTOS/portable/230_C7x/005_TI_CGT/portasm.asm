;    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.
;
;    This file is part of the SafeRTOS product, see projdefs.h for version number
;    information.
;
;    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
;    and is subject to the terms of the License granted to your organization,
;    including its warranties and limitations on use and distribution. It cannot be
;    copied or reproduced in any way except as permitted by the License.
;
;    Licenses authorise use by processor, compiler, business unit, and product.
;
;    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
;    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
;    Tel: +44 1275 395 600
;    Email: info@highintegritysystems.com
;    www.highintegritysystems.com
;

;
; ======== portasm.asm ========
;
        .cdecls C,NOLIST,"SafeRTOS_API.h"

        .global vPortStartFirstTask
        .global vPortSystemCall
        .global xPortDisableInterrupts
        .global xPortEnableInterrupts
        .global vPortRestoreInterrupts

;-------------------------------------------------------------------------------------------------

; Declare references for 'C' functions called by this module.
        .ref vTaskStackCheckFailed
        .ref vTaskSelectNextTask
        .ref pvSystemCallHookFunction
        .ref vPortSystemCallHookCheckFailed
        .ref xApplicationInterruptHandlerHook
        .ref vApplicationExceptionHandlerHook

;-------------------------------------------------------------------------------------------------

; Declare references for global data accessed by this module.
        .global ulCriticalNesting
        .global pxCurrentTCB
        .global uxSCHookMirror
        .global xPortYieldRequired
        .global SysCall_syscallHandler
        .global uxPortYieldInterruptNum

pxCurrentTCB .tag xPortTaskControlBlock


;
; The following are double word offsets (offset must be < 32 for A-reg access)
;
portasmREGISTER_A0              .set    1
portasmREGISTER_A1              .set    2
portasmREGISTER_A2              .set    3
portasmREGISTER_A3              .set    4
portasmREGISTER_A4              .set    5
portasmREGISTER_A5              .set    6
portasmREGISTER_A6              .set    7
portasmREGISTER_A7              .set    8
portasmREGISTER_AL0             .set    9
portasmREGISTER_AL1             .set    10
portasmREGISTER_AL2             .set    11
portasmREGISTER_AL3             .set    12
portasmREGISTER_AL4             .set    13
portasmREGISTER_AL5             .set    14
portasmREGISTER_AL6             .set    15
portasmREGISTER_AL7             .set    16
portasmREGISTER_AM0             .set    17
portasmREGISTER_AM1             .set    18
portasmREGISTER_AM2             .set    19
portasmREGISTER_AM3             .set    20
portasmREGISTER_AM4             .set    21
portasmREGISTER_AM5             .set    22
portasmREGISTER_AM6             .set    23
portasmREGISTER_AM7             .set    24
portasmREGISTER_D0              .set    25
portasmREGISTER_D1              .set    26
portasmREGISTER_D2              .set    27
portasmREGISTER_D3              .set    28
portasmREGISTER_D4              .set    29
portasmREGISTER_D5              .set    30
portasmREGISTER_D6              .set    31
portasmREGISTER_D7              .set    32
portasmREGISTER_D8              .set    33
portasmREGISTER_D9              .set    34
portasmREGISTER_D10             .set    35
portasmREGISTER_D11             .set    36
portasmREGISTER_D12             .set    37
portasmREGISTER_D13             .set    38
portasmREGISTER_D14             .set    39

portasmREGISTER_RP              .set    40
portasmREGISTER_FPCR            .set    41
portasmREGISTER_FSR             .set    42
portasmREGISTER_GFPGFR          .set    43
portasmREGISTER_GPLY            .set    44
portasmREGISTER_P0              .set    45
portasmREGISTER_P1              .set    46
portasmREGISTER_P2              .set    47
portasmREGISTER_P3              .set    48
portasmREGISTER_P4              .set    49
portasmREGISTER_P5              .set    50
portasmREGISTER_P6              .set    51
portasmREGISTER_P7              .set    52
portasmREGISTER_RXMR            .set    53


; 512 bit (64 byte) offsets
portasmREGISTER_VB0             .set    54
portasmREGISTER_VB1             .set    portasmREGISTER_VB0 + ( 8*1 )
portasmREGISTER_VB2             .set    portasmREGISTER_VB0 + ( 8*2 )
portasmREGISTER_VB3             .set    portasmREGISTER_VB0 + ( 8*3 )
portasmREGISTER_VB4             .set    portasmREGISTER_VB0 + ( 8*4 )
portasmREGISTER_VB5             .set    portasmREGISTER_VB0 + ( 8*5 )
portasmREGISTER_VB6             .set    portasmREGISTER_VB0 + ( 8*6 )
portasmREGISTER_VB7             .set    portasmREGISTER_VB0 + ( 8*7 )
portasmREGISTER_VB8             .set    portasmREGISTER_VB0 + ( 8*8 )
portasmREGISTER_VB9             .set    portasmREGISTER_VB0 + ( 8*9 )
portasmREGISTER_VB10            .set    portasmREGISTER_VB0 + ( 8*10 )
portasmREGISTER_VB11            .set    portasmREGISTER_VB0 + ( 8*11 )
portasmREGISTER_VB12            .set    portasmREGISTER_VB0 + ( 8*12 )
portasmREGISTER_VB13            .set    portasmREGISTER_VB0 + ( 8*13 )
portasmREGISTER_VB14            .set    portasmREGISTER_VB0 + ( 8*14 )
portasmREGISTER_VB15            .set    portasmREGISTER_VB0 + ( 8*15 )
portasmREGISTER_VBL0            .set    portasmREGISTER_VB0 + ( 8*16 )
portasmREGISTER_VBL1            .set    portasmREGISTER_VB0 + ( 8*17 )
portasmREGISTER_VBL2            .set    portasmREGISTER_VB0 + ( 8*18 )
portasmREGISTER_VBL3            .set    portasmREGISTER_VB0 + ( 8*19 )
portasmREGISTER_VBL4            .set    portasmREGISTER_VB0 + ( 8*20 )
portasmREGISTER_VBL5            .set    portasmREGISTER_VB0 + ( 8*21 )
portasmREGISTER_VBL6            .set    portasmREGISTER_VB0 + ( 8*22 )
portasmREGISTER_VBL7            .set    portasmREGISTER_VB0 + ( 8*23 )
portasmREGISTER_VBM0            .set    portasmREGISTER_VB0 + ( 8*24 )
portasmREGISTER_VBM1            .set    portasmREGISTER_VB0 + ( 8*25 )
portasmREGISTER_VBM2            .set    portasmREGISTER_VB0 + ( 8*26 )
portasmREGISTER_VBM3            .set    portasmREGISTER_VB0 + ( 8*27 )
portasmREGISTER_VBM4            .set    portasmREGISTER_VB0 + ( 8*28 )
portasmREGISTER_VBM5            .set    portasmREGISTER_VB0 + ( 8*29 )
portasmREGISTER_VBM6            .set    portasmREGISTER_VB0 + ( 8*30 )
portasmREGISTER_VBM7            .set    portasmREGISTER_VB0 + ( 8*31 )
portasmREGISTER_CUCR0           .set    portasmREGISTER_VB0 + ( 8*32 )
portasmREGISTER_CUCR1           .set    portasmREGISTER_VB0 + ( 8*33 )
portasmREGISTER_CUCR2           .set    portasmREGISTER_VB0 + ( 8*34 )
portasmREGISTER_CUCR3           .set    portasmREGISTER_VB0 + ( 8*35 )
portasmREGISTER_STRACNTR0       .set    portasmREGISTER_VB0 + ( 8*36 )
portasmREGISTER_STRACNTR1       .set    portasmREGISTER_VB0 + ( 8*37 )
portasmREGISTER_STRACNTR2       .set    portasmREGISTER_VB0 + ( 8*38 )
portasmREGISTER_STRACNTR3       .set    portasmREGISTER_VB0 + ( 8*39 )
portasmREGISTER_STRACR0         .set    portasmREGISTER_VB0 + ( 8*40 )
portasmREGISTER_STRACR1         .set    portasmREGISTER_VB0 + ( 8*41 )
portasmREGISTER_STRACR2         .set    portasmREGISTER_VB0 + ( 8*42 )
portasmREGISTER_STRACR3         .set    portasmREGISTER_VB0 + ( 8*43 )
portasmREGISTER_SE0_0           .set    portasmREGISTER_VB0 + ( 8*44 )
portasmREGISTER_SE0_1           .set    portasmREGISTER_VB0 + ( 8*45 )
portasmREGISTER_SE0_2           .set    portasmREGISTER_VB0 + ( 8*46 )
portasmREGISTER_SE0_3           .set    portasmREGISTER_VB0 + ( 8*47 )
portasmREGISTER_SE1_0           .set    portasmREGISTER_VB0 + ( 8*48 )
portasmREGISTER_SE1_1           .set    portasmREGISTER_VB0 + ( 8*49 )
portasmREGISTER_SE1_2           .set    portasmREGISTER_VB0 + ( 8*50 )
portasmREGISTER_SE1_3           .set    portasmREGISTER_VB0 + ( 8*51 )

portasmREGISTER_STACKFRAMESIZE  .set    portasmREGISTER_SE1_3 + 8      ; DW (8 byte) size

SP                              .set    d15

;
; dword offsets - never use 1 since 16 bytes need to remain free @SP
;

portasmCONTEXT_SWITCH_FRAMESIZE                 .set    15
portasmCONTEXT_SWITCH_REGISTER_OLD_RP           .set    15        ; OK for c7x, 16-byte space @SP
portasmCONTEXT_SWITCH_CRITICAL_NESTING_COUNT    .set    14
portasmCONTEXT_SWITCH_REGISTER_TSR              .set    13
portasmCONTEXT_SWITCH_REGISTER_TCSP             .set    12
portasmCONTEXT_SWITCH_REGISTER_B15              .set    11
portasmCONTEXT_SWITCH_REGISTER_B14              .set    10
portasmCONTEXT_SWITCH_REGISTER_A15              .set    9
portasmCONTEXT_SWITCH_REGISTER_A14              .set    8
portasmCONTEXT_SWITCH_REGISTER_A13              .set    7
portasmCONTEXT_SWITCH_REGISTER_A12              .set    6
portasmCONTEXT_SWITCH_REGISTER_A11              .set    5
portasmCONTEXT_SWITCH_REGISTER_A10              .set    4
portasmCONTEXT_SWITCH_REGISTER_A9               .set    3
portasmCONTEXT_SWITCH_REGISTER_A8               .set    2

portasmTSR_GEE_BIT                              .set    0x02000000

portasmSYSCALL_START_FIRST_NUMBER               .set    0
portasmSYSCALL_HANDLER_NUMBER                   .set    1

;------------------------------------------------------------------------------
; portSAVE_REGS macro definition
;------------------------------------------------------------------------------

portSAVE_REGS    .macro

            addd.d1     SP, -portasmREGISTER_STACKFRAMESIZE*8, SP     ; alloc stack frame

            std.d1      a0, *SP[ portasmREGISTER_A0 ]
||          std.d2x     a1, *SP[ portasmREGISTER_A1 ]
            std.d1      a2, *SP[ portasmREGISTER_A2 ]
||          std.d2x     a3, *SP[ portasmREGISTER_A3 ]
            std.d1      a4, *SP[ portasmREGISTER_A4 ]
||          std.d2x     a5, *SP[ portasmREGISTER_A5 ]
            std.d1      a6, *SP[ portasmREGISTER_A6 ]
||          std.d2x     a7, *SP[ portasmREGISTER_A7 ]
||          mv.l1       al0, a0
||          mv.s1       al1, a1
            std.d1      a0, *SP[ portasmREGISTER_AL0 ]
||          std.d2x     a1, *SP[ portasmREGISTER_AL1 ]
||          mv.l1       al2, a0
||          mv.s1       al3, a1
            std.d1      a0, *SP[ portasmREGISTER_AL2 ]
||          std.d2x     a1, *SP[ portasmREGISTER_AL3 ]
||          mv.l1       al4, a0
||          mv.s1       al5, a1
            std.d1      a0, *SP[ portasmREGISTER_AL4 ]
||          std.d2x     a1, *SP[ portasmREGISTER_AL5 ]
||          mv.l1       al6, a0
||          mv.s1       al7, a1
            std.d1      a0, *SP[ portasmREGISTER_AL6 ]
||          std.d2x     a1, *SP[ portasmREGISTER_AL7 ]
||          mv.m1       am0, a0
            std.d1      a0, *SP[ portasmREGISTER_AM0 ]
||          mv.m1       am1, a0
            std.d1      a0, *SP[ portasmREGISTER_AM1 ]
||          mv.m1       am2, a0
            std.d1      a0, *SP[ portasmREGISTER_AM2 ]
||          mv.m1       am3, a0
            std.d1      a0, *SP[ portasmREGISTER_AM3 ]
||          mv.m1       am4, a0
            std.d1      a0, *SP[ portasmREGISTER_AM4 ]
||          mv.m1       am5, a0
            std.d1      a0, *SP[ portasmREGISTER_AM5 ]
||          mv.m1       am6, a0
            std.d1      a0, *SP[ portasmREGISTER_AM6 ]
||          mv.m1       am7, a0
            std.d1      a0, *SP[ portasmREGISTER_AM7 ]
            std.d1      d0, *SP[ portasmREGISTER_D0 ]
            std.d1      d1, *SP[ portasmREGISTER_D1 ]
            std.d1      d2, *SP[ portasmREGISTER_D2 ]
            std.d1      d3, *SP[ portasmREGISTER_D3 ]
            std.d1      d4, *SP[ portasmREGISTER_D4 ]
            std.d1      d5, *SP[ portasmREGISTER_D5 ]
            std.d1      d6, *SP[ portasmREGISTER_D6 ]
            std.d1      d7, *SP[ portasmREGISTER_D7 ]
            std.d1      d8, *SP[ portasmREGISTER_D8 ]
            std.d1      d9, *SP[ portasmREGISTER_D9 ]
            std.d1      d10, *SP[ portasmREGISTER_D10 ]
            std.d1      d11, *SP[ portasmREGISTER_D11 ]
            std.d1      d12, *SP[ portasmREGISTER_D12 ]
            std.d1      d13, *SP[ portasmREGISTER_D13 ]
            std.d1      d14, *SP[ portasmREGISTER_D14 ]

            vst8d.d2    vb0, *SP[ portasmREGISTER_VB0 ]
            vst8d.d2    vb1, *SP[ portasmREGISTER_VB1 ]
            vst8d.d2    vb2, *SP[ portasmREGISTER_VB2 ]
            vst8d.d2    vb3, *SP[ portasmREGISTER_VB3 ]
            vst8d.d2    vb4, *SP[ portasmREGISTER_VB4 ]
            vst8d.d2    vb5, *SP[ portasmREGISTER_VB5 ]
            vst8d.d2    vb6, *SP[ portasmREGISTER_VB6 ]
            vst8d.d2    vb7, *SP[ portasmREGISTER_VB7 ]
            vst8d.d2    vb8, *SP[ portasmREGISTER_VB8 ]
            vst8d.d2    vb9, *SP[ portasmREGISTER_VB9 ]
            vst8d.d2    vb10, *SP[ portasmREGISTER_VB10 ]
            vst8d.d2    vb11, *SP[ portasmREGISTER_VB11 ]
            vst8d.d2    vb12, *SP[ portasmREGISTER_VB12 ]
            vst8d.d2    vb13, *SP[ portasmREGISTER_VB13 ]
            vst8d.d2    vb14, *SP[ portasmREGISTER_VB14 ]
            vst8d.d2    vb15, *SP[ portasmREGISTER_VB15 ]
||          vmv.s2      vbl0, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBL0 ]
||          vmv.s2      vbl1, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBL1 ]
||          vmv.s2      vbl2, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBL2 ]
||          vmv.s2      vbl3, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBL3 ]
||          vmv.s2      vbl4, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBL4 ]
||          vmv.s2      vbl5, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBL5 ]
||          vmv.s2      vbl6, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBL6 ]
||          vmv.s2      vbl7, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBL7 ]
||          vmv.m2      vbm0, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBM0 ]
||          vmv.m2      vbm1, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBM1 ]
||          vmv.m2      vbm2, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBM2 ]
||          vmv.m2      vbm3, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBM3 ]
||          vmv.m2      vbm4, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBM4 ]
||          vmv.m2      vbm5, vb0
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBM5 ]
||          vmv.m2      vbm6, vb0
||          mvc.c2      cucr0, vb1                  ; 2 cycle latency for CUCR regs
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBM6 ]
||          vmv.m2      vbm7, vb0
||          mvc.c2      cucr1, vb2
            vst8d.d2    vb0, *SP[ portasmREGISTER_VBM7 ]
||          mvc.s1      rp, a0
||          mvc.c2      cucr2, vb3
            std.d1      a0, *SP[ portasmREGISTER_RP ]
||          vst8d.d2    vb1, *SP[ portasmREGISTER_CUCR0 ]
||          mvc.s1      fpcr, a0
||          mvc.c2      cucr3, vb4
            std.d1      a0, *SP[ portasmREGISTER_FPCR ]
||          vst8d.d2    vb2, *SP[ portasmREGISTER_CUCR1 ]
||          mvc.s1      fsr, a0
            std.d1      a0, *SP[ portasmREGISTER_FSR ]
||          vst8d.d2    vb3, *SP[ portasmREGISTER_CUCR2 ]
||          mvc.s1      gfpgfr, a0
            std.d1      a0, *SP[ portasmREGISTER_GFPGFR ]
||          vst8d.d2    vb4, *SP[ portasmREGISTER_CUCR3 ]
||          mvc.s1      gply, a0
            std.d1      a0, *SP[ portasmREGISTER_GPLY ]
||          mvpb.l2     p0, b0
||          mvpb.s2     p1, b1
            std.d1x     b0, *SP[ portasmREGISTER_P0 ]
||          std.d2      b1, *SP[ portasmREGISTER_P1 ]
||          mvpb.l2     p2, b2
||          mvpb.s2     p3, b3
            std.d1x     b2, *SP[ portasmREGISTER_P2 ]
||          std.d2      b3, *SP[ portasmREGISTER_P3 ]
||          mvpb.l2     p4, b4
||          mvpb.s2     p5, b5
            std.d1x     b4, *SP[ portasmREGISTER_P4 ]
||          std.d2      b5, *SP[ portasmREGISTER_P5 ]
||          mvpb.l2     p6, b6
||          mvpb.s2     p7, b7
            std.d1x     b6, *SP[ portasmREGISTER_P6 ]
||          std.d2      b7, *SP[ portasmREGISTER_P7 ]
||          mvc.s1      rxmr_s, a0
            std.d1      a0, *SP[ portasmREGISTER_RXMR ]
||          mvc.c2      sa0cntr0, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_STRACNTR0 ]
||          mvc.c2      sa1cntr0, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_STRACNTR1 ]
||          mvc.c2      sa2cntr0, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_STRACNTR2 ]
||          mvc.c2      sa3cntr0, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_STRACNTR3 ]
||          mvc.c2      sa0cr, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_STRACR0 ]
||          mvc.c2      sa1cr, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_STRACR1 ]
||          mvc.c2      sa2cr, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_STRACR2 ]
||          mvc.c2      sa3cr, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_STRACR3 ]
||          sesave.l2   3, 1, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_SE1_3 ]
||          sesave.l2   2, 1, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_SE1_2 ]
||          sesave.l2   1, 1, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_SE1_1 ]
||          sesave.l2   0, 1, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_SE1_0 ]
||          sesave.l2   3, 0, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_SE0_3 ]
||          sesave.l2   2, 0, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_SE0_2 ]
||          sesave.l2   1, 0, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_SE0_1 ]
||          sesave.l2   0, 0, vb15
            vst8d.d2    vb15, *SP[ portasmREGISTER_SE0_0 ]
    .endm

;------------------------------------------------------------------------------
; portRESTORE_REGS macro definition
;------------------------------------------------------------------------------

portRESTORE_REGS    .macro

            seclose.d2  0
            seclose.d2  1

            vld8d.d1    *SP[ portasmREGISTER_SE0_3 ], vb15
            serstr.d2   3, 0, vb15
||          vld8d.d1    *SP[ portasmREGISTER_SE0_2 ], vb15
            serstr.d2   2, 0, vb15
||          vld8d.d1    *SP[ portasmREGISTER_SE0_1 ], vb15
            serstr.d2   1, 0, vb15
||          vld8d.d1    *SP[ portasmREGISTER_SE0_0 ], vb15
            serstr.d2   0, 0, vb15
||          vld8d.d1    *SP[ portasmREGISTER_SE1_3 ], vb15
            serstr.d2   3, 1, vb15
||          vld8d.d1    *SP[ portasmREGISTER_SE1_2 ], vb15
            serstr.d2   2, 1, vb15
||          vld8d.d1    *SP[ portasmREGISTER_SE1_1 ], vb15
            serstr.d2   1, 1, vb15
||          vld8d.d1    *SP[ portasmREGISTER_SE1_0 ], vb15
            serstr.d2   0, 1, vb15

            saclose.c2  0
            saclose.c2  1
            saclose.c2  2
            saclose.c2  3

            vld8d.d1    *SP[ portasmREGISTER_STRACNTR0 ], vb15
            mvc.c2      vb15, sa0cntr0
||          vld8d.d1   * SP[ portasmREGISTER_STRACNTR1 ], vb15
            mvc.c2      vb15, sa1cntr0
||          vld8d.d1   * SP[ portasmREGISTER_STRACNTR2 ], vb15
            mvc.c2      vb15, sa2cntr0
||          vld8d.d1    *SP[ portasmREGISTER_STRACNTR3 ], vb15
            mvc.c2      vb15, sa3cntr0
||          vld8d.d1    *SP[ portasmREGISTER_STRACR0 ], vb15
            mvc.c2      vb15, sa0cr
||          vld8d.d1    *SP[ portasmREGISTER_STRACR1 ], vb15
            mvc.c2      vb15, sa1cr
||          vld8d.d1    *SP[ portasmREGISTER_STRACR2 ], vb15
            mvc.c2      vb15, sa2cr
||          vld8d.d1    *SP[ portasmREGISTER_STRACR3 ], vb15
            mvc.c2      vb15, sa3cr

            ldd.d1      *SP[ portasmREGISTER_RXMR ], a0
            ldd.d1      *SP[ portasmREGISTER_P7 ], b7
||          mvc.s1      a0, rxmr_s
            ldd.d1      *SP[ portasmREGISTER_P6 ], b6
||          mv.l2       b7, p7
            ldd.d1      *SP[ portasmREGISTER_P5 ], b5
||          mv.l2       b6, p6
            ldd.d1      *SP[ portasmREGISTER_P4 ], b4
||          mv.l2       b5, p5
            ldd.d1      *SP[ portasmREGISTER_P3 ], b3
||          mv.l2       b4, p4
            ldd.d1      *SP[ portasmREGISTER_P2 ], b2
||          mv.l2       b3, p3
            ldd.d1      *SP[ portasmREGISTER_P1 ], b1
||          mv.l2       b2, p2
            ldd.d1      *SP[ portasmREGISTER_P0 ], b0
||          mv.l2       b1, p1
            vld8d.d1    *SP[ portasmREGISTER_CUCR3 ], vb0
||          mv.l2       b0, p0
            vld8d.d1    *SP[ portasmREGISTER_CUCR2 ], vb0
||          mvc.c2      vb0, cucr3
            vld8d.d1    *SP[ portasmREGISTER_CUCR1 ], vb0
||          mvc.c2      vb0, cucr2
            vld8d.d1    *SP[ portasmREGISTER_CUCR0 ], vb0
||          mvc.c2      vb0, cucr1
            ldd.d1      *SP[ portasmREGISTER_GPLY ], a0
||          mvc.c2      vb0, cucr0
            ldd.d1      *SP[ portasmREGISTER_GFPGFR ], a0
||          mvc.s1      a0, gply
            ldd.d1      *SP[ portasmREGISTER_RP ], a0
||          mvc.s1      a0, gfpgfr
            ldd.d1      *SP[ portasmREGISTER_FPCR ], a0
||          mvc.s1      a0, rp
            ldd.d1      *SP[ portasmREGISTER_FSR ], a0
||          mvc.s1      a0, fpcr
            mvc.s1      a0, fsr

            vld8d.d1    *SP[ portasmREGISTER_VBM7 ], vb0
            vmv.m2      vb0, vbm7
||          vld8d.d1    *SP[ portasmREGISTER_VBM6 ], vb0
            vmv.m2      vb0, vbm6
||          vld8d.d1    *SP[ portasmREGISTER_VBM5 ], vb0
            vmv.m2      vb0, vbm5
||          vld8d.d1    *SP[ portasmREGISTER_VBM4 ], vb0
            vmv.m2      vb0, vbm4
||          vld8d.d1    *SP[ portasmREGISTER_VBM3 ], vb0
            vmv.m2      vb0, vbm3
||          vld8d.d1    *SP[ portasmREGISTER_VBM2 ], vb0
            vmv.m2      vb0, vbm2
||          vld8d.d1    *SP[ portasmREGISTER_VBM1 ], vb0
            vmv.m2      vb0, vbm1
||          vld8d.d1    *SP[ portasmREGISTER_VBM0 ], vb0
            vmv.m2      vb0, vbm0
||          vld8d.d1    *SP[ portasmREGISTER_VBL7 ], vb0
            vmv.m2      vb0, vbl7
||          vld8d.d1    *SP[ portasmREGISTER_VBL6 ], vb0
            vmv.m2      vb0, vbl6
||          vld8d.d1    *SP[ portasmREGISTER_VBL5 ], vb0
            vmv.m2      vb0, vbl5
||          vld8d.d1    *SP[ portasmREGISTER_VBL4 ], vb0
            vmv.m2      vb0, vbl4
||          vld8d.d1    *SP[ portasmREGISTER_VBL3 ], vb0
            vmv.m2      vb0, vbl3
||          vld8d.d1    *SP[ portasmREGISTER_VBL2 ], vb0
            vmv.m2      vb0, vbl2
||          vld8d.d1    *SP[ portasmREGISTER_VBL1 ], vb0
            vmv.m2      vb0, vbl1
||          vld8d.d1    *SP[ portasmREGISTER_VBL0 ], vb0
            vmv.m2      vb0, vbl0
||          vld8d.d1    *SP[ portasmREGISTER_VB15 ], vb15
            vld8d.d1    *SP[ portasmREGISTER_VB14 ], vb14
            vld8d.d1    *SP[ portasmREGISTER_VB13 ], vb13
            vld8d.d1    *SP[ portasmREGISTER_VB12 ], vb12
            vld8d.d1    *SP[ portasmREGISTER_VB11 ], vb11
            vld8d.d1    *SP[ portasmREGISTER_VB10 ], vb10
            vld8d.d1    *SP[ portasmREGISTER_VB9 ], vb9
            vld8d.d1    *SP[ portasmREGISTER_VB8 ], vb8
            vld8d.d1    *SP[ portasmREGISTER_VB7 ], vb7
            vld8d.d1    *SP[ portasmREGISTER_VB6 ], vb6
            vld8d.d1    *SP[ portasmREGISTER_VB5 ], vb5
            vld8d.d1    *SP[ portasmREGISTER_VB4 ], vb4
            vld8d.d1    *SP[ portasmREGISTER_VB3 ], vb3
            vld8d.d1    *SP[ portasmREGISTER_VB2 ], vb2
            vld8d.d1    *SP[ portasmREGISTER_VB1 ], vb1
            vld8d.d1    *SP[ portasmREGISTER_VB0 ], vb0

            ldd.d1      *SP[ portasmREGISTER_D14 ], d14
            ldd.d1      *SP[ portasmREGISTER_D13 ], d13
            ldd.d1      *SP[ portasmREGISTER_D12 ], d12
            ldd.d1      *SP[ portasmREGISTER_D11 ], d11
            ldd.d1      *SP[ portasmREGISTER_D10 ], d10
            ldd.d1      *SP[ portasmREGISTER_D9 ], d9
            ldd.d1      *SP[ portasmREGISTER_D8 ], d8
            ldd.d1      *SP[ portasmREGISTER_D7 ], d7
            ldd.d1      *SP[ portasmREGISTER_D6 ], d6
            ldd.d1      *SP[ portasmREGISTER_D5 ], d5
            ldd.d1      *SP[ portasmREGISTER_D4 ], d4
            ldd.d1      *SP[ portasmREGISTER_D3 ], d3
            ldd.d1      *SP[ portasmREGISTER_D2 ], d2
            ldd.d1      *SP[ portasmREGISTER_D1 ], d1
            ldd.d1      *SP[ portasmREGISTER_D0 ], d0
            ldd.d1      *SP[ portasmREGISTER_AM7 ], a0
            mv.m1       a0, am7
||          ldd.d1      *SP[ portasmREGISTER_AM6 ], a0
            mv.m1       a0, am6
||          ldd.d1      *SP[ portasmREGISTER_AM5 ], a0
            mv.m1       a0, am5
||          ldd.d1      *SP[ portasmREGISTER_AM4 ], a0
            mv.m1       a0, am4
||          ldd.d1      *SP[ portasmREGISTER_AM3 ], a0
            mv.m1       a0, am3
||          ldd.d1      *SP[ portasmREGISTER_AM2 ], a0
            mv.m1       a0, am2
||          ldd.d1      *SP[ portasmREGISTER_AM1 ], a0
            mv.m1       a0, am1
||          ldd.d1      *SP[ portasmREGISTER_AM0 ], a0
            mv.m1       a0, am0
||          ldd.d1      *SP[ portasmREGISTER_AL7 ], a0
            mv.m1       a0, al7
||          ldd.d1      *SP[ portasmREGISTER_AL6 ], a0
            mv.m1       a0, al6
||          ldd.d1      *SP[ portasmREGISTER_AL5 ], a0
            mv.m1       a0, al5
||          ldd.d1      *SP[ portasmREGISTER_AL4 ], a0
            mv.m1       a0, al4
||          ldd.d1      *SP[ portasmREGISTER_AL3 ], a0
            mv.m1       a0, al3
||          ldd.d1      *SP[ portasmREGISTER_AL2 ], a0
            mv.m1       a0, al2
||          ldd.d1      *SP[ portasmREGISTER_AL1 ], a0
            mv.m1       a0, al1
||          ldd.d1      *SP[ portasmREGISTER_AL0 ], a0
            mv.m1       a0, al0

            ldd.d1      *SP[ portasmREGISTER_A7 ], a7
            ldd.d1      *SP[ portasmREGISTER_A6 ], a6
            ldd.d1      *SP[ portasmREGISTER_A5 ], a5
            ldd.d1      *SP[ portasmREGISTER_A4 ], a4
            ldd.d1      *SP[ portasmREGISTER_A3 ], a3
            ldd.d1      *SP[ portasmREGISTER_A2 ], a2
            ldd.d1      *SP[ portasmREGISTER_A1 ], a1
            ldd.d1      *SP[ portasmREGISTER_A0 ], a0

            addd.d1     SP, portasmREGISTER_STACKFRAMESIZE*8, SP     ; free stack frame
    .endm
;-------------------------------------------------------------------------------------------------

;-------------------------------------------------------------------------------------------------
; Interrupt vector table
;-------------------------------------------------------------------------------------------------
    .sect .vecs
    .global portVectorTable

portVectorTable:    ; For external code to reference the start of the vector table.
portasmSoftReset:
            b.b1      $PCR_OFFSET( portasmSoftReset )

    .align 0x200
portasmInternalException:
            std.d2x   a0, *SP++[ -1 ]
            std.d1    a1, *SP++[ -1 ]
            mvk64.l1  0x0, a1
            b.b1      $PCR_OFFSET( vApplicationExceptionHandlerHook )

    .align 0x200
portasmPageFault:
            std.d2x   a0, *SP++[ -1 ]
            std.d1    a1, *SP++[ -1 ]
            mvk64.l1  0x1, a1
            b.b1      $PCR_OFFSET( vApplicationExceptionHandlerHook )

    .align 0x200
portasmNonMaskableException:
            b.b1      $PCR_OFFSET( portasmNonMaskableException )

    .align 0x200
portasmEvent:
            b.b1      $PCR_OFFSET( vPortIsrHandler )

    .align 0x1000
portasmSyscall:
            b.b1      $PCR_OFFSET( portasmStartFirstTask )

    .align 0x40
            b.b1      $PCR_OFFSET( portasmSyscallHandler )

;-------------------------------------------------------------------------------------------------

    .sect .secure_vecs
    .global portSecureVectorTable

portSecureVectorTable:    ; For external code to reference the start of the secure vector table.
portasmSecureSoftReset:
            b.b1      $PCR_OFFSET( portasmSecureSoftReset )

    .align 0x200
portasmSecureInternalException:
            std.d2x   a0, *SP++[ -1 ]
            std.d1    a1, *SP++[ -1 ]
            mvk64.l1  0x0, a1
            b.b1      $PCR_OFFSET( vApplicationExceptionHandlerHook )

    .align 0x200
portasmSecurePageFault:
            std.d2x   a0, *SP++[ -1 ]
            std.d1    a1, *SP++[ -1 ]
            mvk64.l1  0x1, a1
            b.b1      $PCR_OFFSET( vApplicationExceptionHandlerHook )

    .align 0x200
portasmSecureNonMaskableException:
            b.b1      $PCR_OFFSET( portasmSecureNonMaskableException )

    .align 0x200
portasmSecureEvent:
            b.b1      $PCR_OFFSET( vPortIsrHandler )


;-------------------------------------------------------------------------------------------------

    .sect ".KERNEL_FUNCTION:vPortIsrHandler"
    .clink
vPortIsrHandler:
    .asmfunc

            std.d1      a0, *SP++[ -1 ]             ; push regs to use
||          devt.s1     a0      ; disable interrupts, ignore previous state - use critical nesting count

            std.d1      a1, *SP++[ -1 ]
||          ldd.d2      *ECSP[ 0 ], a0              ; swap return pointers
||          mvc.s1      rp, a1

            std.d1      a1, *ECSP[ 0 ]
||          mvc.s1      a0, rp

            ldd.d1      *SP[ 1 ], a1                ; pop regs used
||          ldd.d2      *SP[ 2 ], a0
            addd.d2     SP, 2 * 8, SP

            portSAVE_REGS

            mvc.s1      AHPEE, a4                   ; get the interrupt number
||          addkpc.d1   $PCR_OFFSET( uxPortYieldInterruptNum ), a1

            ldd.d1      *a1, a1
||          mvk64.l1    0x1, a3

            cmpeqd.s1   a4, a1, a1                  ; test if yield interrupt
||          shld.l1     a3, a4, a3                  ; set the interrupt mask
||          addkpc.d1   $PCR_OFFSET( xApplicationInterruptHandlerHook ), a0

    [ a1 ]  b.b1        $PCR_OFFSET( vPortIsrHandler_contextSwitch )    ; do not call interrupt hook for yield
||  [ a1 ]  mvc.s1      a3, EFCLR                   ; clear yield interrupt

            addd.d2     SP, -2 * 8, SP
||          calla.s1    a0                          ; handle all other interrupts externally

            ; return from handling the interrupt with ok to yield in a4
            addd.d2     SP, 2 * 8, SP
||          addkpc.d1   $PCR_OFFSET( xPortYieldRequired ), a0

            ldd.d1      *a0, a3
||  [ !a4 ] b.b1        $PCR_OFFSET( vPortIsrHandler_exit ) ; restore regs if not ok to yield

            mvk64.l1    0x0, a1
||  [ !a3 ] b.b1        $PCR_OFFSET( vPortIsrHandler_exit ) ; restore regs if yield not required

            std.d1      a1, *a0                             ; reset _xPortYieldRequired variable

vPortIsrHandler_contextSwitch:
            addkpc.d1   $PCR_OFFSET( portasmSaveContext ), a0
||          ldd.d2      *ECSP[ 0 ], a4              ; get RP stored on entry

            calla.s1    a0
||          ldd.d2      *ECSP[ 1 ], a5              ; get TSR stored on entry

            addkpc.d1   $PCR_OFFSET( vTaskSelectNextTask ), a0
            calla.s1    a0

            addkpc.d1   $PCR_OFFSET( portasmRestoreContext ), a0
            calla.s1    a0

            std.d1      a4, *ECSP[ 0 ]              ; store RP & TSR from new task
||          std.d2x     a2, *ECSP[ 1 ]

vPortIsrHandler_exit:
            portRESTORE_REGS

            std.d1      a0, *SP++[ -1 ]                         ; push
            std.d1      a1, *SP++[ -1 ]
            std.d1      a2, *SP++[ -1 ]
||          addkpc.d2   $PCR_OFFSET( ulCriticalNesting ), a0    ; Load critical nesting count

            ldd.d1      *a0, a0
||          ldd.d2      *ECSP[ 1 ], a1              ; get TSR stored on entry
||          mvku32.l1   portasmTSR_GEE_BIT, a2

            addd.d2     SP, 3 * 8, SP
||  [ !a0 ] ord.s1      a2, a1, a1                  ; set interrupts

            ldd.d1      *ECSP[ 0 ], a2
||  [ a0 ]  andnd.s1    a2, a1, a1                  ; clear interrupts

            mvc.s1      rp, a0                      ; swap RP stored on entry

            mvc.s1      a2, rp
||          ldd.d2      *SP[ -2 ], a2

            rete.s1     a0, a1
||          ldd.d1      *SP[ -1 ], a1
||          ldd.d2      *SP[ 0 ], a0

    .endasmfunc
;-------------------------------------------------------------------------------------------------

    .sect ".KERNEL_FUNCTION:portasmStartFirstTask"
portasmStartFirstTask:
    .asmfunc
            addkpc.d1   $PCR_OFFSET( portasmRestoreContext ), a0
            calla.s1    a0

            portRESTORE_REGS

            std.d1      a0, *SP++[ -1 ]                             ; push register value
            addkpc.d1   $PCR_OFFSET( ulCriticalNesting ), a0        ; Load critical nesting count
            ldd.d1      *a0, a0
            cmpeqd.s1   a0, 0, a0                                   ; is ulCriticalNesting zero?

            revt.s1     a0      ; Enable/disable interrupts depending if critical nesting count zero or not
||          ldd.d1      *SP( 8-portasmREGISTER_STACKFRAMESIZE*8 ), a0   ; reload stored return pointer from stack

            rets.b1
||          mvc.s1      a0, rp                                      ; replace original return pointer
||          ldd.d1      *SP[ 1 ], a0                                ; pop register value
||          addd.d2     SP, 8, SP

    .endasmfunc
;-------------------------------------------------------------------------------------------------

;-------------------------------------------------------------------------------------------------
;
; Some registers are considered user saved registers.
; Save them here along with the critical nesting count.
; Store the stack mirror in the TCB.
; Select the next task to switch to.
; RP is passed in a4 & TSR is in a5
;-------------------------------------------------------------------------------------------------
    .sect ".KERNEL_FUNCTION:portasmSaveContext"
portasmSaveContext:
    .asmfunc

            ; Get current TCB structure
            addd.d1     SP, -portasmCONTEXT_SWITCH_FRAMESIZE*8, SP      ; alloc context stack frame
||          addkpc.d2   $PCR_OFFSET( pxCurrentTCB ), a3    ; Address of pointer to TCB

            addkpc.d1   $PCR_OFFSET( ulCriticalNesting ), a1    ; Get critical nesting count
||          ldd.d2      *a3, a3                             ; Address of TCB structure

            mv.d1       SP, a0                              ; copy stack pointer
||          ldd.d2      *a1, a1

            nord.l1     a0, 0x0, a2                         ; calculate the top of stack mirror
||          std.d1      SP, *a3( xPortTaskControlBlock.pxTopOfStack )   ; save the top of stack to TCB

            ; save the top of stack mirror to TCB
            std.d1      a2, *a3( xPortTaskControlBlock.uxTopOfStackMirror )
||          ldd.d2      *a3( xPortTaskControlBlock.pxStackLimit ), a2   ; get the stack limit address from TCB

            ; check for stack limit overflow
            cmpgeud.s1  a0, a2, a2
    [ !a2 ] b.b1        $PCR_OFFSET( vTaskStackCheckFailed )

            mvc.s1      tcsp, a3
||          std.d1      a1, *a0[ portasmCONTEXT_SWITCH_CRITICAL_NESTING_COUNT ]
            std.d1      a3, *a0[ portasmCONTEXT_SWITCH_REGISTER_TCSP ]
            std.d1      a5, *a0[ portasmCONTEXT_SWITCH_REGISTER_TSR ]
            std.d1      a4, *a0[ portasmCONTEXT_SWITCH_REGISTER_OLD_RP ]

            std.d1      a8, *a0[ portasmCONTEXT_SWITCH_REGISTER_A8 ]
            std.d1      a9, *a0[ portasmCONTEXT_SWITCH_REGISTER_A9 ]
            std.d1      a10, *a0[ portasmCONTEXT_SWITCH_REGISTER_A10 ]
            std.d1      a11, *a0[ portasmCONTEXT_SWITCH_REGISTER_A11 ]
            std.d1      a12, *a0[ portasmCONTEXT_SWITCH_REGISTER_A12 ]
            std.d1      a13, *a0[ portasmCONTEXT_SWITCH_REGISTER_A13 ]
            std.d1      a14, *a0[ portasmCONTEXT_SWITCH_REGISTER_A14 ]
            std.d1      a15, *a0[ portasmCONTEXT_SWITCH_REGISTER_A15 ]
            std.d1x     b14, *a0[ portasmCONTEXT_SWITCH_REGISTER_B14 ]
            std.d1x     b15, *a0[ portasmCONTEXT_SWITCH_REGISTER_B15 ]

            ret.b1

    .endasmfunc
;-------------------------------------------------------------------------------------------------

;-------------------------------------------------------------------------------------------------
;
; Switch to the next task's stack and check with the stack mirror from the TCB.
; Restore the user saved registers and the critical nesting count.
;-------------------------------------------------------------------------------------------------
    .sect ".KERNEL_FUNCTION:portasmRestoreContext"
portasmRestoreContext:
    .asmfunc

            ; Get current TCB structure
            addkpc.d1   $PCR_OFFSET( pxCurrentTCB ), a0     ; Address of pointer to TCB
            ldd.d1      *a0, a0                             ; Address of TCB structure

            ; change to the new SP in the current TCB
            ldd.d1      *a0( xPortTaskControlBlock.pxTopOfStack ), SP

            ldd.d1      *SP[ portasmCONTEXT_SWITCH_CRITICAL_NESTING_COUNT ], a1
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_TSR ], a2
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_TCSP ], a3
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_OLD_RP ], a4

            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_A8 ], a8
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_A9 ], a9
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_A10 ], a10
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_A11 ], a11
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_A12 ], a12
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_A13 ], a13
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_A14 ], a14
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_A15 ], a15
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_B14 ], b14
            ldd.d1      *SP[ portasmCONTEXT_SWITCH_REGISTER_B15 ], b15

            addd.d1     SP, portasmCONTEXT_SWITCH_FRAMESIZE*8, SP   ; free context stack frame
||          addkpc.d2   $PCR_OFFSET( ulCriticalNesting ), a0        ; Store critical nesting count

            std.d1      a1, *a0
||          mvc.s1      a3, tcsp
||          andw.m1     a2, 0x8, a0
    [ !a0 ] b.b1        portasmRestoreContext_thread_mode           ; branch to exit if in thread mode

            ehdl                        ; enable handler mode
            ret.b1

portasmRestoreContext_thread_mode:
            dhdl                        ; enable thread mode
            ret.b1

    .endasmfunc
;-------------------------------------------------------------------------------------------------

    .sect ".KERNEL_FUNCTION:portasmSyscallHandler"
portasmSyscallHandler
    .asmfunc

            mvc.s1      rp, a0                  ; a0 still saved on stack
            std.d1      a0, *SP++[ -1 ]         ; push return pointer
||          addkpc.d2   $PCR_OFFSET( pvSystemCallHookFunction ), a0

            std.d1      a1, *SP++[ -1 ]         ; push register
||          addkpc.d2   $PCR_OFFSET( uxSCHookMirror ), a1

            ldd.d1      *a0, a0                 ; load function address
||          ldd.d2      *a1, a1                 ; load mirror value

    [ a0 ]  andd.s1     a1, a0, a1              ; and with a mirror gives zero
    [ !a0 ] mvk64.l1    0x0, a1                 ; hook function NULL - no need for mirror

            ldd.d1      *SP[ 1 ], a1            ; pop register
||  [ a1 ]  b.b1        $PCR_OFFSET( vPortSystemCallHookCheckFailed )    ; function not NULL but bad mirror

    [ a0 ]  calla.s1    a0                      ; call hook function

            ldd.d1      *SP[ 2 ], a0            ; pop return pointer
||          addd.d2     SP, 2 * 8, SP

            mvc.s1      a0, rp

            rets.b1

    .endasmfunc

;-------------------------------------------------------------------------------------------------
; void vPortStartFirstTask( void )
;
; entry and exit point for software exceptions
;-------------------------------------------------------------------------------------------------
    .sect ".text:vPortStartFirstTask"
    .clink
vPortStartFirstTask:
    .asmfunc

            syscall.b1  portasmSYSCALL_START_FIRST_NUMBER
            ret.b1

    .endasmfunc
;-------------------------------------------------------------------------------------------------

;-------------------------------------------------------------------------------------------------
; void vPortSystemCall( portUnsignedBaseType uxSyscallNumber )
;
; entry and exit point for software exceptions
;-------------------------------------------------------------------------------------------------
    .sect ".text:vPortSystemCall"
    .clink
vPortSystemCall:
    .asmfunc

            std.d1      a0, *SP++[ -1 ]                             ; push register value
||          mvc.s1      rp, a0
            std.d1      a0, *SP++[ -1 ]                             ; push return pointer

            syscall.b1  portasmSYSCALL_HANDLER_NUMBER

            ldd.d1      *SP[ 1 ], a0                                ; pop return pointer
            mvc.s1      a0, rp

            ret.b1
||          ldd.d1      *SP[ 2 ], a0                                ; pop register value
||          addd.d2     SP, 2 * 8, SP

    .endasmfunc
;-------------------------------------------------------------------------------------------------

;-------------------------------------------------------------------------------------------------
; portUnsignedBaseType xPortDisableInterrupts( void )
;
; Function to disable interrupts to enter a critical region
;-------------------------------------------------------------------------------------------------
    .sect ".text:xPortDisableInterrupts"
    .clink
xPortDisableInterrupts:
    .asmfunc

            devt.s1  a4    ; returns old TSR.GEE >> 25
||          ret.b1

    .endasmfunc
;-------------------------------------------------------------------------------------------------

;-------------------------------------------------------------------------------------------------
; portUnsignedBaseType xPortEnableInterrupts( void )
;
; Function to enable global interrupts
;-------------------------------------------------------------------------------------------------
    .sect ".text:xPortEnableInterrupts"
    .clink
xPortEnableInterrupts:
    .asmfunc

            mvc.s1   TSR, a5
||          mvk32.l1 1, a4
            revt.s1  a4
||          shruw.l1 a5, 25, a6
            andw.m1  a6, 1, a4    ; return old TSR.GEE >> 25
||          ret.b1

    .endasmfunc
;-------------------------------------------------------------------------------------------------

;-------------------------------------------------------------------------------------------------
; void vPortRestoreInterrupts( portUnsignedBaseType )
;
; Function to restore interrupts to exit a critical region
;-------------------------------------------------------------------------------------------------
    .sect ".text:vPortRestoreInterrupts"
    .clink
vPortRestoreInterrupts:
    .asmfunc

            revt.s1 a4
||          ret.b1

    .endasmfunc
;-------------------------------------------------------------------------------------------------

