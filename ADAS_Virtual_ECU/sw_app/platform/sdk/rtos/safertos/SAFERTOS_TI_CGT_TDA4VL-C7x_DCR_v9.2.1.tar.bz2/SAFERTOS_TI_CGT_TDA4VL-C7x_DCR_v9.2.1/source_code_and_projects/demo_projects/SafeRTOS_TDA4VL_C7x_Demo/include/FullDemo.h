/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#ifndef FULL_DEMO_H
#define FULL_DEMO_H

/* SafeRTOS Includes */
#include "SafeRTOS_API.h"


/*-----------------------------------------------------------------------------
 * Public Constants
 *---------------------------------------------------------------------------*/

#define fulldemoTIMER_TASK_PRIORITY     ( 2U )
#define fulldemoTIMER_CMD_QUEUE_LEN     ( 50U )

/* SC numbers for demo. */
#define fulldemoSC_INCREMENT_VALUE     ( 0U )
#define fulldemoSC_ADD_64BIT           ( 1U )
#define fulldemoSC_FOUR_PARAMS         ( 2U )


/*-----------------------------------------------------------------------------
 * Public Prototypes
 *---------------------------------------------------------------------------*/

/* Prototype for the function that creates the demo application tasks. */
portBaseType xFullDemoCreate( void );

/* Following four prototypes are the SafeRTOS hook (or callback) functions.
 * These are passed to the kernel during initialisation. */
void vDemoApplicationIdleHook( void );
void vDemoApplicationTickHook( void );

void vDemoApplicationTaskDeleteHook( portTaskHandleType xTaskBeingDeleted );

void vDemoApplicationErrorHook( portTaskHandleType xHandleOfTaskWithError,
                                const portCharType *pcErrorString,
                                portBaseType xErrorCode );

portUInt64Type ulDemoApplicationScHook( portUnsignedBaseType uxSCNum,
                                        portUnsignedBaseType uxArg1,
                                        portUnsignedBaseType uxArg2,
                                        portUnsignedBaseType uxArg3,
                                        portUnsignedBaseType uxArg4 );

/*---------------------------------------------------------------------------*/

#endif /* FULL_DEMO_H */
