/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court, Long Ashton
    Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/


#ifndef TIMERS_H
#define TIMERS_H

#ifdef __cplusplus
extern "C" {
#endif

#include "timersAPI.h"

/*-----------------------------------------------------------------------------
 * Private API
 *---------------------------------------------------------------------------*/
/* Functions beyond this part are not part of the public API and are intended
for use by the kernel only. */

KERNEL_INIT_FUNCTION portBaseType xTimerInitialiseFeature( timerInstanceParametersType *pxTimerInstance,
                                                           portUnsignedBaseType uxTimerTaskPriority,
                                                           portUnsignedBaseType uxTimerTaskStackSize,
                                                           portInt8Type *pcTimerTaskStackBuffer,
                                                           portUnsignedBaseType uxTimerCommandQueueLength,
                                                           portUnsignedBaseType uxTimerCommandQueueBufferSize,
                                                           portInt8Type *pcTimerCommandQueueBuffer );

/* Used by the checkpoint module to start a checkpoint timer. */
KERNEL_FUNCTION portBaseType xTimerStartImmediate( timerHandleType xTimer,
                                                   portTickType xRefTime,
                                                   portTickType xTimeNow,
                                                   portTickType xCommandTime );

/* Check the validity of the timer handle. */
KERNEL_FUNCTION portBaseType xTimerIsHandleValid( timerHandleType xTimer );

/* Verify that the timer instance structure is still valid. */
KERNEL_FUNCTION portBaseType xTimerCheckInstance( const timerInstanceParametersType *const pxTimerInstance );

/* Function to allow an instance specific message handler to be registered with
 * a timer task. */
KERNEL_FUNCTION portBaseType xTimerRegisterMsgHandler(
    timerInstanceParametersType *pxTimerInstance,
    timerMessageHandlerFunctionPtrType pxInstanceMessageHandler );

/* Functions that sends a message to the timer task queue requesting that the
 * xEventGroupSetBits() or the xEventGroupSetBits() function be executed from
 * the timer task context. */
KERNEL_FUNCTION portBaseType xTimerPendEventGroupSetBitsFromISR( void *pvEventGroup,
                                                                 portTickType xBitsToManipulate );

KERNEL_FUNCTION portBaseType xTimerPendEventGroupClearBitsFromISR( void *pvEventGroup,
                                                                   portTickType xBitsToManipulate );


#ifdef __cplusplus
}
#endif
#endif /* TIMERS_H */



