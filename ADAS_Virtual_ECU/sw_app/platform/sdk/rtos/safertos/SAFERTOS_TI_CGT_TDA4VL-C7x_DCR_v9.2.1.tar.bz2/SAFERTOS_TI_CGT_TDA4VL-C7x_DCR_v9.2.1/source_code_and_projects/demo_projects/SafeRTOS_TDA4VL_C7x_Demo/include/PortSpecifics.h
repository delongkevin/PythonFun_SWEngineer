/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#ifndef PORT_SPECIFICS_H
#define PORT_SPECIFICS_H

/* SafeRTOS Includes */
#include "SafeRTOS_API.h"


/*-----------------------------------------------------------------------------
 * Constants common to all demo tasks
 *---------------------------------------------------------------------------*/

/* This constant is used where it is desirable to locate all task TCBs in a
 * specified area of memory.
 * Not required for this product variant. */
#define portspecTCB_DATA_SECTION

/* This constant is used where it is desirable to locate all common privileged
 * demo data in a specified area of memory.
 * Not required for this product variant. */
#define portspecCOMMON_PRIV_DATA_SECTION

/* The Flash tasks and the ComTest tasks need access to the GPIO peripheral
 * register address region in order to toggle the LED indicators. */


/*-----------------------------------------------------------------------------
 * Maths Test task parameters
 *---------------------------------------------------------------------------*/

/* Constants */
#define portspecMATHS_TEST_STACK_SIZE   ( configMINIMAL_STACK_SIZE )

/* Task stacks */
extern portInt8Type acUnprivilegedTask1Stack[ portspecMATHS_TEST_STACK_SIZE ];
extern portInt8Type acUnprivilegedTask2Stack[ portspecMATHS_TEST_STACK_SIZE ];
extern portInt8Type acUnprivilegedTask3Stack[ portspecMATHS_TEST_STACK_SIZE ];
extern portInt8Type acUnprivilegedTask4Stack[ portspecMATHS_TEST_STACK_SIZE ];

extern portInt8Type acPrivilegedTask1Stack[ portspecMATHS_TEST_STACK_SIZE ];
extern portInt8Type acPrivilegedTask2Stack[ portspecMATHS_TEST_STACK_SIZE ];
extern portInt8Type acPrivilegedTask3Stack[ portspecMATHS_TEST_STACK_SIZE ];
extern portInt8Type acPrivilegedTask4Stack[ portspecMATHS_TEST_STACK_SIZE ];

/* Define portspecMATHS_TEST_DATA_SECTION
 * so that all Maths Test static data is in the same section. */
#define portspecMATHS_TEST_DATA_SECTION     __attribute__ ( ( section ( "__maths_test_data__" ) ) )

#ifdef MATHS_TEST_C

/* API parameters */
/* A linker defined symbol that gives the start address of the Maths Test
 * data section. */
extern portUInt32Type lnkMathsTestDataStartAddr[];

/* The base address of the Maths Test data section. */
#define portspecMATHS_TEST_DATA_ADDR        ( ( void * ) lnkMathsTestDataStartAddr )

/* The size of the Maths Test data section. */
#define portspecMATHS_TEST_DATA_SIZE        ( ( portUInt32Type ) 0x20U )

#define portspecMATHS_PRIV_NO_REGION_PARMS
#define portspecMATHS_UNPRIV_REGION_PARMS

#define xMathsPrivTask1PortParameters       portspecMATHS_PRIV_NO_REGION_PARMS
#define xMathsPrivTask2PortParameters       portspecMATHS_PRIV_NO_REGION_PARMS
#define xMathsPrivTask3PortParameters       portspecMATHS_PRIV_NO_REGION_PARMS
#define xMathsPrivTask4PortParameters       portspecMATHS_PRIV_NO_REGION_PARMS

#define xMathsUnprivTask1PortParameters     portspecMATHS_UNPRIV_REGION_PARMS
#define xMathsUnprivTask2PortParameters     portspecMATHS_UNPRIV_REGION_PARMS
#define xMathsUnprivTask3PortParameters     portspecMATHS_UNPRIV_REGION_PARMS
#define xMathsUnprivTask4PortParameters     portspecMATHS_UNPRIV_REGION_PARMS

#endif /* MATHS_TEST_C */


/*-----------------------------------------------------------------------------
 * Queue Blocking task parameters
 *---------------------------------------------------------------------------*/

/* Task constants */
#define portspecBLOCK_Q_STACK_SIZE          ( configMINIMAL_STACK_SIZE )
#define portspecBLOCK_Q_QUEUE_LENGTH_1      ( 1U )
#define portspecBLOCK_Q_QUEUE_LENGTH_5      ( 5U )
#define portspecBLOCK_Q_QUEUE_ITEM_SIZE     ( sizeof( portUInt16Type ) )
#define portspecBLOCK_Q_BUFFER_LENGTH_1     ( ( portspecBLOCK_Q_QUEUE_LENGTH_1 * portspecBLOCK_Q_QUEUE_ITEM_SIZE ) + safertosapiQUEUE_OVERHEAD_BYTES )
#define portspecBLOCK_Q_BUFFER_LENGTH_5     ( ( portspecBLOCK_Q_QUEUE_LENGTH_5 * portspecBLOCK_Q_QUEUE_ITEM_SIZE ) + safertosapiQUEUE_OVERHEAD_BYTES )

/* Task stacks */
extern portInt8Type acQueueTestTask1Stack[ portspecBLOCK_Q_STACK_SIZE ];
extern portInt8Type acQueueTestTask2Stack[ portspecBLOCK_Q_STACK_SIZE ];
extern portInt8Type acQueueTestTask3Stack[ portspecBLOCK_Q_STACK_SIZE ];
extern portInt8Type acQueueTestTask4Stack[ portspecBLOCK_Q_STACK_SIZE ];
extern portInt8Type acQueueTestTask5Stack[ portspecBLOCK_Q_STACK_SIZE ];
extern portInt8Type acQueueTestTask6Stack[ portspecBLOCK_Q_STACK_SIZE ];

/* Queue buffers */
extern portInt8Type acQueue1Buffer[ portspecBLOCK_Q_BUFFER_LENGTH_1 ];
extern portInt8Type acQueue2Buffer[ portspecBLOCK_Q_BUFFER_LENGTH_1 ];
extern portInt8Type acQueue3Buffer[ portspecBLOCK_Q_BUFFER_LENGTH_5 ];

/* Define portspecBLOCK_Q_DATA_SECTION
 * so that all Blocking Queue static data is in the same section. */
#define portspecBLOCK_Q_DATA_SECTION    __attribute__ ( ( section ( "__block_q_data__" ) ) )

/* API parameters */
#ifdef BLOCK_Q_C

/* A linker defined symbol that gives the start address of the Blocking Queue
 * data section. */
extern portUInt32Type lnkBlockQueueTestDataStartAddr[];

/* The base address of the Blocking Queue data section. */
#define portspecBLOCK_Q_DATA_ADDR       ( ( void * ) lnkBlockQueueTestDataStartAddr )

/* The size of the Blocking Queue data section. */
#define portspecBLOCK_Q_DATA_SIZE       ( ( portUInt32Type ) 0x80U )

#define portspecBLOCK_Q_TASK_PARAMETERS

#define xBlockingQueueConsumerTask1PortParameters   portspecBLOCK_Q_TASK_PARAMETERS
#define xBlockingQueueProducerTask1PortParameters   portspecBLOCK_Q_TASK_PARAMETERS
#define xBlockingQueueConsumerTask2PortParameters   portspecBLOCK_Q_TASK_PARAMETERS
#define xBlockingQueueProducerTask2PortParameters   portspecBLOCK_Q_TASK_PARAMETERS
#define xBlockingQueueProducerTask3PortParameters   portspecBLOCK_Q_TASK_PARAMETERS
#define xBlockingQueueConsumerTask3PortParameters   portspecBLOCK_Q_TASK_PARAMETERS

#endif /* BLOCK_Q_C */


/*-----------------------------------------------------------------------------
 * Block Time Test task parameters
 *---------------------------------------------------------------------------*/

/* Task constants */
#define portspecBLOCK_TIME_STACK_SIZE       ( configMINIMAL_STACK_SIZE )
#define portspecBLOCK_TIME_QUEUE_LENGTH     ( 5U )
#define portspecBLOCK_TIME_QUEUE_ITEM_SIZE  ( sizeof( portBaseType ) )
#define portspecBLOCK_TIME_BUFFER_LENGTH    ( ( portspecBLOCK_TIME_QUEUE_LENGTH * portspecBLOCK_TIME_QUEUE_ITEM_SIZE ) + safertosapiQUEUE_OVERHEAD_BYTES )

/* Task stacks */
extern portInt8Type acBlockTimeTestTask1Stack[ portspecBLOCK_TIME_STACK_SIZE ];
extern portInt8Type acBlockTimeTestTask2Stack[ portspecBLOCK_TIME_STACK_SIZE ];

/* Queue buffers */
extern portInt8Type acQueueBuffer[ portspecBLOCK_TIME_BUFFER_LENGTH ];

/* Define portspecBLOCK_TIME_TEST_DATA_SECTION
 * so that all Block Time Test static data is in the same section. */
#define portspecBLOCK_TIME_TEST_DATA_SECTION    __attribute__ ( ( section ( "__block_tim_data__" ) ) )

/* API parameters */
#ifdef BLOCK_TIME_TEST_C

/* A linker defined symbol that gives the start address of the Block Time Test
 * data section. */
extern const portUInt32Type lnkBlockTimeTestDataStartAddr[];

/* The base address of the Block Time Test data section. */
#define portspecBLOCK_TIME_TEST_DATA_ADDR       ( ( void * ) lnkBlockTimeTestDataStartAddr )

/* The size of the Block Time Test data section. */
#define portspecBLOCK_TIME_TEST_DATA_SIZE   ( ( portUInt32Type ) 0x20U )

#define portspecBLOCK_TIME_TEST_PARAMETERS

#define xPrimaryBlockTimeTestTaskPortParameters     portspecBLOCK_TIME_TEST_PARAMETERS
#define xSecondaryBlockTimeTestTaskPortParameters   portspecBLOCK_TIME_TEST_PARAMETERS

#endif /* BLOCK_TIME_TEST_C */


/*-----------------------------------------------------------------------------
 * Counting Semaphore Test task parameters
 *---------------------------------------------------------------------------*/

/* Task constants */
#define portspecCOUNTSEM_TASK_STACK_SIZE    ( configMINIMAL_STACK_SIZE )
#define portspecCOUNTSEM_TASK3_STACK_SIZE   ( configMINIMAL_STACK_SIZE )

/* Task stacks */
extern portInt8Type acCountSemTestTask1Stack[ portspecCOUNTSEM_TASK_STACK_SIZE ];
extern portInt8Type acCountSemTestTask2Stack[ portspecCOUNTSEM_TASK_STACK_SIZE ];
extern portInt8Type acCountSemTestTask3Stack[ portspecCOUNTSEM_TASK3_STACK_SIZE ];

/* Counting Semaphore Test Semaphore buffers.
 * No actual data is stored into these buffers so the buffer
 * need only to be large enough to hold the queue structure itself. */
extern portInt8Type acCountSem1[ safertosapiQUEUE_OVERHEAD_BYTES ];
extern portInt8Type acCountSem2[ safertosapiQUEUE_OVERHEAD_BYTES ];
extern portInt8Type acCountSem3[ safertosapiQUEUE_OVERHEAD_BYTES ];

/* Define portspecCOUNT_SEM_TASK_DATA_SECTION and portspecCOUNTSEM_TASK_ZERO_DATA_SECTION
 * so that all Counting Semaphore static data is in the same section. */
#define portspecCOUNTSEM_TASK_DATA_SECTION      __attribute__ ( ( section ( "__counting_semaphore_task_data__" ) ) )
#define portspecCOUNTSEM_TASK_ZERO_DATA_SECTION portspecCOUNTSEM_TASK_DATA_SECTION

/* API parameters */
#ifdef COUNTING_SEMAPHORE_TEST_C

/* The Interrupt Task will run unprivileged. */
#define portspecCOUNTSEM_INTERRUPT_TASK_RUNS_UNPRIVILEGED   0

/* A linker defined symbol that gives the start address of the Counting
 * Semaphore Test data section. */
extern const portUInt32Type lnkCountSemTestDataStartAddr[];

/* The base address of the Counting Semaphore Test data section. */
#define portspecCOUNTSEM_TASK_DATA_ADDR         ( ( void * ) lnkCountSemTestDataStartAddr )

/* The size of the Counting Semaphore Test data section. */
#define portspecCOUNTSEM_TASK_DATA_SIZE     ( ( portUInt32Type ) 0x40U )

#define portspecCOUNTING_SEMAPHORE_PARAMETERS
#define portspecINTERRUPT_SEMAPHORE_PARAMETERS
#define portspecINTERRUPT_API_UPDATE_PARAMETERS

#define xCountSemaphoreTestTask1PortParameters      portspecCOUNTING_SEMAPHORE_PARAMETERS
#define xCountSemaphoreTestTask2PortParameters      portspecCOUNTING_SEMAPHORE_PARAMETERS
#define xCountSemaphoreTestTask3PortParameters      portspecINTERRUPT_SEMAPHORE_PARAMETERS
#define xCountSemaphoreTestTask3ApiUpdParameters    portspecINTERRUPT_API_UPDATE_PARAMETERS

#endif /* COUNTING_SEMAPHORE_TEST_C */


/*-----------------------------------------------------------------------------
 * Create Delete Test task parameters
 *---------------------------------------------------------------------------*/

/* Task constants */
#define portspecCREATE_TASK_STACK_SIZE      ( configMINIMAL_STACK_SIZE )
#define portspecCREATED_TASKS_STACK_SIZE    ( configMINIMAL_STACK_SIZE )

/* Task stacks */
extern portInt8Type acCreateTaskStack[ portspecCREATE_TASK_STACK_SIZE ];
extern portInt8Type acCreatedDummyTaskStack[ portspecCREATED_TASKS_STACK_SIZE ];
extern portInt8Type acDeleterTaskStack[ portspecCREATED_TASKS_STACK_SIZE ];

/* Define portspecCREATE_DELETE_DATA_SECTION
 * so that all Create Delete Test static data is in the same section. */
#define portspecCREATE_DELETE_DATA_SECTION  __attribute__ ( ( section ( "__create_delete_data__") ) )

/* API parameters */
#ifdef CREATE_DELETE_TASK_C

/* A linker defined symbol that gives the start address of the Create Delete
 * Test data section. */
extern const portUInt32Type lnkDeathTestDataStartAddr[];

/* The base address of the Create Delete Test data section. */
#define portspecCREATE_DELETE_DATA_ADDR     ( ( void * ) lnkDeathTestDataStartAddr )

/* The size of the Create Delete Test data section. */
#define portspecCREATE_DELETE_DATA_SIZE     ( ( portUInt32Type ) 0x20U )

#define portspecCREATE_DELETE_TASK_PARAMETERS

#define xCreateTaskPortParameters       portspecCREATE_DELETE_TASK_PARAMETERS
#define xCreatedDummyTaskPortParameters portspecCREATE_DELETE_TASK_PARAMETERS
#define xDeleterTaskPortParameters      portspecCREATE_DELETE_TASK_PARAMETERS

#endif /* CREATE_DELETE_TASK_C */


/*-----------------------------------------------------------------------------
 * Dynamic task parameters
 *---------------------------------------------------------------------------*/

/* Task constants */
#define portspecDYNAMIC_TASK_STACK_SIZE                     ( configMINIMAL_STACK_SIZE )
#define portspecDYNAMIC_TASK_SUSPENDED_QUEUE_LENGTH         ( 1U )
#define portspecDYNAMIC_TASK_QUEUE_ITEM_SIZE                ( sizeof( portUInt32Type ) )
#define portspecDYNAMIC_TASK_SUSPEND_QUEUE_BUFFER_LENGTH    ( ( portspecDYNAMIC_TASK_SUSPENDED_QUEUE_LENGTH * portspecDYNAMIC_TASK_QUEUE_ITEM_SIZE ) + safertosapiQUEUE_OVERHEAD_BYTES )

/* Task stacks */
extern portInt8Type acContinuousIncrementTaskStack[ portspecDYNAMIC_TASK_STACK_SIZE ];
extern portInt8Type acLimitedIncrementTaskStack[ portspecDYNAMIC_TASK_STACK_SIZE ];
extern portInt8Type acCounterControlTaskStack[ portspecDYNAMIC_TASK_STACK_SIZE ];
extern portInt8Type acQueueSendWhenSuspendedTaskStack[ portspecDYNAMIC_TASK_STACK_SIZE ];
extern portInt8Type acQueueReceiveWhenSuspendedTaskStack[ portspecDYNAMIC_TASK_STACK_SIZE ];

/* Queue buffers */
extern portInt8Type acSuspendTestQueueBuffer[ portspecDYNAMIC_TASK_SUSPEND_QUEUE_BUFFER_LENGTH ];

/* Define portspecDYNAMIC_TASK_DATA_SECTION
 * so that all Dynamic Task static data is in the same section. */
#define portspecDYNAMIC_TASK_DATA_SECTION   __attribute__ ( ( section ( "__dynamic_task_data__") ) )

/* API parameters */
#ifdef DYNAMIC_MANIPULATION_C

/* A linker defined symbol that gives the start address of the Dynamic Task
 * data section. */
extern const portUInt32Type lnkDynamicTestDataStartAddr[];

/* The base address of the Dynamic Task data section. */
#define portspecDYNAMIC_TASK_DATA_ADDR      ( ( void * ) lnkDynamicTestDataStartAddr )

/* The size of the Dynamic Task data section. */
#define portspecDYNAMIC_TASK_DATA_SIZE      ( ( portUInt32Type ) 0x40U )

#define portspecDYNAMIC_TASK_PARAMETERS

#define xContinuousIncrementTaskPortParameters          portspecDYNAMIC_TASK_PARAMETERS
#define xLimitedIncrementTaskPortParameters             portspecDYNAMIC_TASK_PARAMETERS
#define xCounterControlTaskPortParameters               portspecDYNAMIC_TASK_PARAMETERS
#define xQueueSendWhenSuspendedTaskPortParameters       portspecDYNAMIC_TASK_PARAMETERS
#define xQueueReceiveWhenSuspendedTaskPortParameters    portspecDYNAMIC_TASK_PARAMETERS

#endif /* DYNAMIC_MANIPULATION_C */


/*-----------------------------------------------------------------------------
 * LED Flash task parameters
 *---------------------------------------------------------------------------*/

/* Task constants */
#define portspecNUMBER_OF_LEDS          ( 1U )
#define portspecLED_TASK_STACK_SIZE     ( configMINIMAL_STACK_SIZE )

/* Structure used to pass parameters to the LED Flash tasks. */
typedef struct LED_FLASH_TASK_PARAMETERS
{
    portUnsignedBaseType uxLEDNumber;   /* The LED to be flashed. */
    portTickType xFlashRate_ms;         /* The flash rate in milliseconds. */
} xLedFlashTaskParameters;

/* LED Flash Task input parameters */
extern const xLedFlashTaskParameters xLedTaskParameters[ portspecNUMBER_OF_LEDS ];

/* Task stacks */
extern portInt8Type acLedTaskStack[ portspecNUMBER_OF_LEDS ][ portspecLED_TASK_STACK_SIZE ];

/* Define portspecLED_TASK_DATA_SECTION
 * so that all LED Task static data is in the same section. */
#define portspecLED_TASK_DATA_SECTION   __attribute__ ( ( section ( "__led_task_data__") ) )

/* API parameters */
#ifdef FLASH_LED_C

/* A linker defined symbol that gives the start address of the LED Task
 * data section. */
extern const portUInt32Type lnkLEDFlashTestDataStartAddr[];

/* The base address of the Poll Queue data section. */
#define portspecLED_TASK_DATA_ADDR      ( ( void * ) lnkLEDFlashTestDataStartAddr )

/* The size of the LED Task data section. */
#define portspecLED_TASK_DATA_SIZE      ( ( portUInt32Type ) 0x20U )

#define portspecLED_FLASH_PARAMETERS

#define xLEDFlashTaskPortParameters     portspecLED_FLASH_PARAMETERS

#endif /* FLASH_LED_C */


/*-----------------------------------------------------------------------------
 * Poll Queue task parameters
 *---------------------------------------------------------------------------*/

/* Task constants */
#define portspecPOLL_Q_STACK_SIZE       ( configMINIMAL_STACK_SIZE )
#define portspecPOLL_Q_QUEUE_LENGTH     ( 10U )
#define portspecPOLL_Q_QUEUE_ITEM_SIZE  ( sizeof( portUInt16Type ) )
#define portspecPOLL_Q_BUFFER_LENGTH    ( ( portspecPOLL_Q_QUEUE_LENGTH * portspecPOLL_Q_QUEUE_ITEM_SIZE ) + safertosapiQUEUE_OVERHEAD_BYTES )

/* Task stacks */
extern portInt8Type acPollQueueTestTask1Stack[ portspecPOLL_Q_STACK_SIZE ];
extern portInt8Type acPollQueueTestTask2Stack[ portspecPOLL_Q_STACK_SIZE ];
extern portInt8Type acPollQueueTestTask3Stack[ portspecPOLL_Q_STACK_SIZE ];

/* Queue buffers */
extern portInt8Type acPollQueue1Buffer[ portspecPOLL_Q_BUFFER_LENGTH ];
extern portInt8Type acPollQueue2Buffer[ portspecPOLL_Q_BUFFER_LENGTH ];

/* Define portspecPOLL_Q_DATA_SECTION
 * so that all Poll Queue static data is in the same section. */
#define portspecPOLL_Q_DATA_SECTION     __attribute__ ( ( section ( "__poll_q_data__") ) )

/* API parameters */
#ifdef POLLED_Q_C

/* A linker defined symbol that gives the start address of the Poll Queue data
 * section. */
extern const portUInt32Type lnkPollQTestDataStartAddr[];

/* The base address of the Poll Queue data section. */
#define portspecPOLL_Q_DATA_ADDR        ( ( void * ) lnkPollQTestDataStartAddr )

/* The size of the Poll Queue data section. */
#define portspecPOLL_Q_DATA_SIZE        ( ( portUInt32Type ) 0x20U )

#define portspecPOLL_Q_PARAMETERS

#define xPolledQueueConsumerTaskPortParameters      portspecPOLL_Q_PARAMETERS
#define xPolledQueueProducerTaskPortParameters      portspecPOLL_Q_PARAMETERS
#define xPolledQueueSendFrontTaskPortParameters     portspecPOLL_Q_PARAMETERS

#endif /* POLLED_Q_C */


/*-----------------------------------------------------------------------------
 * Binary Semaphore Test task parameters
 *---------------------------------------------------------------------------*/

/* Task constants */
#define portspecSEMAPHORE_TASK_STACK_SIZE       ( configMINIMAL_STACK_SIZE )

/* Task stacks */
extern portInt8Type acSemaphoreTestTask1Stack[ portspecSEMAPHORE_TASK_STACK_SIZE ];
extern portInt8Type acSemaphoreTestTask2Stack[ portspecSEMAPHORE_TASK_STACK_SIZE ];
extern portInt8Type acSemaphoreTestTask3Stack[ portspecSEMAPHORE_TASK_STACK_SIZE ];
extern portInt8Type acSemaphoreTestTask4Stack[ portspecSEMAPHORE_TASK_STACK_SIZE ];

/* Semaphore buffers.
 * No actual data is stored into these buffers so the buffer need only be large
 * enough to hold the queue structure itself. */
extern portInt8Type acSemaphore1[ safertosapiQUEUE_OVERHEAD_BYTES ];
extern portInt8Type acSemaphore2[ safertosapiQUEUE_OVERHEAD_BYTES ];

/* Define portspecSEMAPHORE_TASK_DATA_SECTION
 * so that all Binary Semaphore static data is in the same section. */
#define portspecSEMAPHORE_TASK_DATA_SECTION         __attribute__ ( ( section ( "__binary_semaphore_task_data__") ) )

/* API parameters */
#ifdef SEMAPHORE_TEST_C

/* A linker defined symbol that gives the start address of the Binary Semaphore
 * Task data section. */
extern const portUInt32Type lnkSemaphoreTestDataStartAddr[];

/* The base address of the Timer demo data section. */
#define portspecBINARY_SEMAPHORE_TASK_DATA_ADDR     ( ( void * ) lnkSemaphoreTestDataStartAddr )

/* The size of the Binary Semaphore Task data section. */
#define portspecBINARY_SEMAPHORE_TASK_DATA_SIZE     ( ( portUInt32Type ) 0x40U )

#define portspecBINARY_SEMAPHORE_PARAMETERS

#define xSemaphoreTestTask1PortParameters   portspecBINARY_SEMAPHORE_PARAMETERS
#define xSemaphoreTestTask2PortParameters   portspecBINARY_SEMAPHORE_PARAMETERS
#define xSemaphoreTestTask3PortParameters   portspecBINARY_SEMAPHORE_PARAMETERS
#define xSemaphoreTestTask4PortParameters   portspecBINARY_SEMAPHORE_PARAMETERS

#endif /* SEMAPHORE_TEST_C */


/*-----------------------------------------------------------------------------
 * Timer demo task parameters
 *---------------------------------------------------------------------------*/

/* Task constants */
#define portspecTIMER_TASK_STACK_SIZE       ( configMINIMAL_STACK_SIZE )

/* Task stacks */
extern portInt8Type acTimerTestTaskStack[ portspecTIMER_TASK_STACK_SIZE ];

/* Define portspecTIMER_TEST_DATA_SECTION and
 * portspecTIMER_TEST_ZERO_DATA_SECTION to nothing as this port cannot
 * use this syntax method to assign variables to sections. */
#define portspecTIMER_TEST_DATA_SECTION         __attribute__( ( section( "__timer_demo_task_data__" ) ) )
#define portspecTIMER_TEST_ZERO_DATA_SECTION    portspecTIMER_TEST_DATA_SECTION

/* API parameters */
#ifdef TIMERTEST_C

/* A linker defined symbol that gives the start address of the Timer demo data
 * section. */
extern const portUInt32Type lnkStartTimerTestData[];

/* The base address of the Timer demo data section. */
#define portspecTIMER_TEST_DATA_ADDR    ( ( void * ) lnkStartTimerTestData )

/* The size of the Timer Test data section. */
#define portspecTIMER_TEST_DATA_SIZE    ( ( portUInt32Type ) 0x800U )

#define portspecTIMER_TEST_TASK_PARAMETERS

#define xTimerTestTaskPortParameters    portspecTIMER_TEST_TASK_PARAMETERS

#endif /* TIMERTEST_C */


/*-----------------------------------------------------------------------------
 * Notify demo task parameters
 *---------------------------------------------------------------------------*/

/* Task constants */
#define portspecNOTIFIED_TASK_STACK_SIZE    ( configMINIMAL_STACK_SIZE )

/* Task stacks */
extern portInt8Type acNotifiedTaskStack[ portspecNOTIFIED_TASK_STACK_SIZE ];

/* Define portspecTASK_NOTIFY_DATA_SECTION and portspecTASK_NOTIFY_ZERO_DATA_SECTION
 * so that all task notify demo static data is in the same section. */
#define portspecTASK_NOTIFY_DATA_SECTION        __attribute__ ( ( section( "__notified_task_data__" ) ) )
#define portspecTASK_NOTIFY_ZERO_DATA_SECTION   portspecTASK_NOTIFY_DATA_SECTION

/* API parameters */
#ifdef TASKNOTIFYDEMO_C

/* A linker defined symbol that gives the start address of the Notify demo data
 * section. */
extern const portUInt32Type lnkTaskNotifyDataStartAddr[];

/* The base address of the Task Notify data section. */
#define portspecTASK_NOTIFY_DATA_ADDR   ( ( void * ) lnkTaskNotifyDataStartAddr )

/* The size of the Notify demo data section. */
#define portspecTASK_NOTIFY_DATA_SIZE   ( ( portUInt32Type ) 0x20U )

#define portspecNOTIFIED_TASK_PARAMETERS

#define xNotifiedTaskPortParameters     portspecNOTIFIED_TASK_PARAMETERS

#endif /* TASKNOTIFYDEMO_C */

/*-----------------------------------------------------------------------------
 * Recursive mutex task parameters
 *---------------------------------------------------------------------------*/

/* Task constants */
#define portspecMUTEX_STACK_SIZE        ( configMINIMAL_STACK_SIZE )

/* Mutex demo task stacks */
extern portInt8Type acRecursiveMutexControllingTaskStack[ portspecMUTEX_STACK_SIZE ];
extern portInt8Type acRecursiveMutexBlockingTaskStack[ portspecMUTEX_STACK_SIZE ];
extern portInt8Type acRecursiveMutexPollingTaskStack[ portspecMUTEX_STACK_SIZE ];

/* Queue buffers */
extern portInt8Type acMutexBuffer[ safertosapiQUEUE_OVERHEAD_BYTES ];

/* API parameters */
/* Define portspecMUTEX_TASK_DATA_SECTION
 * so that all static data is in the same section. */
#define portspecMUTEX_TASK_DATA_SECTION     __attribute__ ( ( section ( "__rec_mutex_data__") ) )

#ifdef TASK_MUTEX_C

/* A linker defined symbol that gives the start address of the Mutex demo
 * data section. */
extern const portUInt32Type lnkRecMutexDataStartAddr[];

/* The base address of the Task Notify data section. */
#define portspecREC_MUTEX_DATA_ADDR     ( ( void * ) lnkRecMutexDataStartAddr )

/* The size of the Notify demo data section. */
#define portspecREC_MUTEX_DATA_SIZE     ( ( portUInt32Type ) 0x40U )

#define portspecREC_MUTEX_PARAMETERS

#define xRecursiveMutexControllingTaskPortParameters    portspecREC_MUTEX_PARAMETERS
#define xRecursiveMutexBlockingTaskPortParameters       portspecREC_MUTEX_PARAMETERS
#define xRecursiveMutexPollingTaskPortParameters        portspecREC_MUTEX_PARAMETERS

#endif /* TASK_MUTEX_C */

/*---------------------------------------------------------------------------*/
/* Event Multiplex Demo Task Parameters                                      */
/*---------------------------------------------------------------------------*/

/* Event Multiplex Demo Task Constants */
#define portspecEVT_MPLX_BLOCK_TASK_STACK_SIZE          ( configMINIMAL_STACK_SIZE )
#define portspecEVT_MPLX_CONTROL_TASK_STACK_SIZE        ( configMINIMAL_STACK_SIZE )
#define portspecEVT_MPLX_Q_QUEUE_LENGTH                 ( 2U )
#define portspecEVT_MPLX_Q_QUEUE_ITEM_SIZE              ( sizeof( portUnsignedBaseType ) )
#define portspecEVT_MPLX_Q_BUFFER_LENGTH                ( ( portspecEVT_MPLX_Q_QUEUE_LENGTH * portspecEVT_MPLX_Q_QUEUE_ITEM_SIZE ) + safertosapiQUEUE_OVERHEAD_BYTES )
#define portspecMAXIMUM_NUMBER_OF_OBJECT_EVENTS         ( 6U )
#define portspecEVT_MPLX_BUFFER_LENGTH                  evtmplxGET_REQUIRED_CREATE_BUFFER_SIZE( portspecMAXIMUM_NUMBER_OF_OBJECT_EVENTS )

/* Event Multiplex Demo Task Stacks */
extern portInt8Type acEvtMplxBlockTaskStack[ portspecEVT_MPLX_BLOCK_TASK_STACK_SIZE ];
extern portInt8Type acEvtMplxControlTaskStack[ portspecEVT_MPLX_CONTROL_TASK_STACK_SIZE ];

/* Queue buffers. */
extern portInt8Type acEvtMplxQueue1Buffer[ portspecEVT_MPLX_Q_BUFFER_LENGTH ];
extern portInt8Type acEvtMplxQueue2Buffer[ portspecEVT_MPLX_Q_BUFFER_LENGTH ];

/* Event Multiplex Semaphore Buffer. */
extern portInt8Type acEvtMplxSemaphoreBuffer[ safertosapiQUEUE_OVERHEAD_BYTES ];

/* Event Multiplex Mutex Buffer. */
extern portInt8Type acEvtMplxMutexBuffer[ safertosapiQUEUE_OVERHEAD_BYTES ];

/* Event Multiplex Buffer. */
extern portInt8Type acEvtMplxBuffer[ portspecEVT_MPLX_BUFFER_LENGTH ];

/* Definitions that ensure all Event Multiplex demo static data is in the same
 * section. */
#define portspecEVT_MPLX_DEMO_DATA_SECTION              __attribute__ ( ( section ( "__evt_mplx_data__" ) ) )
#define portspecEVT_MPLX_DEMO_ZERO_DATA_SECTION         portspecEVT_MPLX_DEMO_DATA_SECTION

/* API parameters */
#ifdef EVT_MPLX_DEMO_C

/* A linker defined symbol that gives the start address of the Event Multiplex demo
 * data section. */
extern const portUInt32Type lnkMplxDataStartAddr[];

/* Two linker-defined symbols that give the start address and the size of the
 * Evt Mplx data section. */
#define portspecEVT_MPLX_DATA_ADDR  ( ( void * ) lnkMplxDataStartAddr )
#define portspecEVT_MPLX_DATA_SIZE  ( ( portUInt32Type ) 0x40U )

#define portspecEVT_MPLX_DEMO_PARAMETERS

#define xEvtMplxBlockTaskPortParameters     portspecEVT_MPLX_DEMO_PARAMETERS
#define xEvtMplxControlTaskPortParameters   portspecEVT_MPLX_DEMO_PARAMETERS

#endif  /* EVT_MPLX_DEMO_C */


/*---------------------------------------------------------------------------*/
/* Stream Buffer Demo Task Parameters                                        */
/*---------------------------------------------------------------------------*/

#define portspecSTREAM_BUFFER_TASK_STACK_SIZE ( configMINIMAL_STACK_SIZE )
#define portspecNUMBER_OF_STREAM_BUFFER_TASKS ( 3U )

/* Task stacks. */
extern portInt8Type acStreamBufferTaskStack[ portspecNUMBER_OF_STREAM_BUFFER_TASKS ][ portspecSTREAM_BUFFER_TASK_STACK_SIZE ];
extern portInt8Type acStreamBufferTaskWakeCheckTxStack[ portspecSTREAM_BUFFER_TASK_STACK_SIZE ];
extern portInt8Type acStreamBufferTaskWakeCheckRxStack[ portspecSTREAM_BUFFER_TASK_STACK_SIZE ];

/* Used to dimension the array used to hold the streams. */
#define portspecSTORAGE_SIZE_BYTES              ( 10U )
#define portspecSTREAM_BUFFER_MESSAGE_LENGTH    ( 4U )
#define portspecSTREAM_BUFFER_RX_LENGTH         ( portspecSTORAGE_SIZE_BYTES )
#define portspecSB_BLOCK_TIME_FOREVER           ( safertosapiMAX_DELAY )

/* A second set of linker symbols are needed for these tasks as each task has a common data area to exchange information in addition to a cloned area to allow the task to be created */
#define portspecSTREAM_BUFFER_DATA_ADDRESS_COMMON   ( ( void * ) &lnkStreamBufferDataCommonStartAddr )
#define portspecSTREAM_BUFFER_TEST_DATA_SIZE_COMMON ( ( portUInt32Type ) 0x100U )

/* Linker-defined symbols that give the start and end addresses of the
 * stream buffer Test data section. */
extern const portUInt32Type lnkStreamBufferDataStartAddr[];
extern const portUInt32Type lnkStreamBufferDataCommonStartAddr[];

/* portspecMULTICORE_STREAM_BUFFER_DEMO Controls whether the stream buffer
 * demo is run all from the same core or across separate cores
 * portspecSTREAM_BUFFER_GET_CPU_ID must retrieve the core number if multicore is to be used*/
#define portspecMULTICORE_STREAM_BUFFER_DEMO    0

#if ( portspecMULTICORE_STREAM_BUFFER_DEMO == 1 )
    #error "multicore not supported on this platform"
#else
    #define portspecSTREAM_BUFFER_DATA_SECTION          __attribute__( ( section( "__streambuffer_data__" ) ) )
    #define portspecSTREAM_BUFFER_DATA_SECTION_COMMON   __attribute__( ( section( "__streambuffer_data_common__" ) ) )

    #define portspecSTREAM_BUFFER_GET_CPU_ID        ( 0U )
    #define portspecSB_BLOCK_TIME                   ( 0U )

    /* Core ID for the task to be created on */
    #define portspecSTREAM_BUFFER_CREATION_CORE     ( 0U )
    #define portspecSTREAM_BUFFER_FIRST_TASK        ( 0U )
    #define portspecSTREAM_BUFFER_SECOND_TASK       ( 0U )
    #define portspecSTREAM_BUFFER_THIRD_TASK        ( 0U )
#endif

/* API parameters */
#ifdef STREAM_BUFFER_C

/* These constants are used to give the stream buffer tasks access
 * to the file scope check variables. */
#define portspecSTREAM_BUFFER_DATA_ADDRESS      ( ( void * ) lnkStreamBufferDataStartAddr )
#define portspecSTREAM_BUFFER_TEST_DATA_SIZE    ( ( portUInt32Type ) 0x100U )

#define portspecSTREAM_BUFFER_TASK_PARAMS

#define xStreamBufferTaskPortParameters     portspecSTREAM_BUFFER_TASK_PARAMS

#endif /* STREAM_BUFFER_C */


/*-----------------------------------------------------------------------------
 * Com Test task parameters
 *---------------------------------------------------------------------------*/

 /* Task constants */
#define portspecCOM_TEST_TASK_STACK_SIZE    ( configMINIMAL_STACK_SIZE )

/* Task stacks */
extern portInt8Type acRxStack[ portspecCOM_TEST_TASK_STACK_SIZE ];
extern portInt8Type acTxStack[ portspecCOM_TEST_TASK_STACK_SIZE ];

/* Define portspecCOM_TEST_DATA_SECTION and portspecCOM_TEST_ZERO_DATA_SECTION
 * so that all Com Test static data is in the same section. */
#define portspecCOM_TEST_DATA_SECTION       __attribute__ ( ( section ( "__com_test_data__" ) ) )
#define portspecCOM_TEST_ZERO_DATA_SECTION  portspecCOM_TEST_DATA_SECTION

/* API parameters */
#ifdef COMTEST_C

/* A linker defined symbol that gives the start address of the Com Test
 * data section. */
extern const portUInt32Type lnkComTestDataStartAddr[];

/* The base address of the Com Test data section. */
#define portspecCOM_TEST_DATA_ADDR          ( ( void * ) lnkComTestDataStartAddr )

/* The size of the ComTest data section. */
#define portspecCOM_TEST_DATA_SIZE          ( ( portUInt32Type ) 0x20U )

#define portspecCOM_TEST_TASK_PARAMETERS

#define xComTxTaskPortParameters    portspecCOM_TEST_TASK_PARAMETERS
#define xComRxTaskPortParameters    portspecCOM_TEST_TASK_PARAMETERS

#endif /* COMTEST_C */


/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/

#endif /* PORT_SPECIFICS_H */
