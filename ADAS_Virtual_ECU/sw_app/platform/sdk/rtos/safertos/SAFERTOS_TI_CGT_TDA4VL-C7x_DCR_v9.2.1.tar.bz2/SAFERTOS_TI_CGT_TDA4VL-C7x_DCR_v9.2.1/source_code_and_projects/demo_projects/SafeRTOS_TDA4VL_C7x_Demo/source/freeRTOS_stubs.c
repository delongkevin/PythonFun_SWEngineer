/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#include <stdio.h>
#include <stdint.h>

struct QueueDefinition; /* Using old naming convention so as not to break kernel aware debuggers. */
typedef struct QueueDefinition   * QueueHandle_t;
typedef long             BaseType_t;
typedef unsigned long    UBaseType_t;
typedef uint32_t         TickType_t;

struct xSTATIC_MINI_LIST_ITEM
{
    TickType_t xDummy2;
    void * pvDummy3[ 2 ];
};
typedef struct xSTATIC_MINI_LIST_ITEM StaticMiniListItem_t;

/* See the comments above the struct xSTATIC_LIST_ITEM definition. */
typedef struct xSTATIC_LIST
{
    UBaseType_t uxDummy2;
    void * pvDummy3;
    StaticMiniListItem_t xDummy4;
} StaticList_t;

typedef struct xSTATIC_QUEUE
{
    void * pvDummy1[ 3 ];

    union
    {
        void * pvDummy2;
        UBaseType_t uxDummy2;
    } u;

    StaticList_t xDummy3[ 2 ];
    UBaseType_t uxDummy4[ 3 ];
    uint8_t ucDummy5[ 2 ];

    uint8_t ucDummy6;

    UBaseType_t uxDummy8;
    uint8_t ucDummy9;
} StaticQueue_t;
typedef StaticQueue_t StaticSemaphore_t;

void vPortYeildFromISR( uint32_t xSwitchRequired )
{
    ( void ) xSwitchRequired;
}
/*---------------------------------------------------------------------------*/

void vQueueAddToRegistry( QueueHandle_t xQueue,
                          const char * pcName )
{
    ( void ) xQueue;
    ( void ) pcName;
}
/*---------------------------------------------------------------------------*/

void vTaskDelay( const TickType_t xTicksToDelay )
{
    ( void ) xTicksToDelay;
}
/*---------------------------------------------------------------------------*/

QueueHandle_t xQueueCreateCountingSemaphoreStatic( const UBaseType_t uxMaxCount,
                                                   const UBaseType_t uxInitialCount,
                                                   StaticQueue_t * pxStaticQueue )
{
    ( void ) uxMaxCount;
    ( void ) uxInitialCount;
    ( void ) pxStaticQueue;
    return ( QueueHandle_t ) NULL;
}
/*---------------------------------------------------------------------------*/

QueueHandle_t xQueueGenericCreateStatic( const UBaseType_t uxQueueLength,
                                         const UBaseType_t uxItemSize,
                                         uint8_t * pucQueueStorage,
                                         StaticQueue_t * pxStaticQueue,
                                         const uint8_t ucQueueType )
{
    ( void ) uxQueueLength;
    ( void ) uxItemSize;
    ( void ) pucQueueStorage;
    ( void ) pxStaticQueue;
    ( void ) ucQueueType;
    return ( QueueHandle_t ) NULL;
}
/*---------------------------------------------------------------------------*/

BaseType_t xQueueGenericSend( QueueHandle_t xQueue,
                              const void * const pvItemToQueue,
                              TickType_t xTicksToWait,
                              const BaseType_t xCopyPosition )
{
    ( void ) xQueue;
    ( void ) pvItemToQueue;
    ( void ) xTicksToWait;
    ( void ) xCopyPosition;
    return 0;
}
/*---------------------------------------------------------------------------*/

BaseType_t xQueueGiveFromISR( QueueHandle_t xQueue,
                              BaseType_t * const pxHigherPriorityTaskWoken )
{
    ( void ) xQueue;
    ( void ) pxHigherPriorityTaskWoken;
    return 0;
}
/*---------------------------------------------------------------------------*/

BaseType_t xQueueReceiveFromISR( QueueHandle_t xQueue,
                                 void * const pvBuffer,
                                 BaseType_t * const pxHigherPriorityTaskWoken )
{
    ( void ) xQueue;
    ( void ) pvBuffer;
    ( void ) pxHigherPriorityTaskWoken;
    return 0;
}
/*---------------------------------------------------------------------------*/

BaseType_t xQueueSemaphoreTake( QueueHandle_t xQueue,
                                TickType_t xTicksToWait )
{
    ( void ) xQueue;
    ( void ) xTicksToWait;
    return 0;
}
/*---------------------------------------------------------------------------*/

BaseType_t xTaskGetSchedulerState( void )
{
    return 0;
}
