/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

/* SafeRTOS Includes */
#include "SafeRTOS_API.h"
#include "aborts.h"

#include "ti/osal/TimerP.h"
#include "ti/csl/csl_clec.h"
#include "ti/drv/sciclient/sciclient.h"
#include "ti/osal/src/nonos/Nonos_config.h"
#include "Hwi.h"
#include "Exception.h"

/* Hook function handlers targeting the TI PDK libraries. */

/*-----------------------------------------------------------------------------
 * Function type and structure type definitions.
 *---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * Private constant definitions.
 *---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * Private function definitions.
 *---------------------------------------------------------------------------*/

/* Tick timer interrupt handler corresponding to TI PDK library prototype. */
static void prvTimerTickIsr( uintptr_t arg )
{
    ( void ) arg;
    vTaskProcessSystemTickFromISR();
}
/*---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * Public function definitions.
 *---------------------------------------------------------------------------*/

void vPortInitTimerCLECCfg( portUInt32Type ulTimerId, portUInt32Type ulTimerIntNum )
{
    CSL_ClecEventConfig xCfgClec;
    CSL_CLEC_EVTRegs    *pxClecBaseAddr = ( CSL_CLEC_EVTRegs* )CSL_COMPUTE_CLUSTER0_CLEC_BASE;
    portUInt32Type      ulInput         = gDmTimerPInfoTbl[ ulTimerId ].eventId;

    /* Configure CLEC */
    xCfgClec.secureClaimEnable = FALSE;
    xCfgClec.evtSendEnable     = TRUE;
    xCfgClec.rtMap             = CSL_CLEC_RTMAP_CPU_ALL;
    xCfgClec.extEvtNum         = 0;
    xCfgClec.c7xEvtNum         = ulTimerIntNum;

    CSL_clecClearEvent( pxClecBaseAddr, ulInput );
    CSL_clecConfigEventLevel( pxClecBaseAddr, ulInput, 0 ); /* configure interrupt as pulse */
    CSL_clecConfigEvent( pxClecBaseAddr, ulInput, &xCfgClec );
}
/*---------------------------------------------------------------------------*/

/* Dispatch handler for TI PDK style exceptions. */
void vApplicationExceptionHandlerHook( portBaseType xAbortFlag, portBaseType xVectorType )
{
   Exception_handler( xAbortFlag, xVectorType );
}
/*---------------------------------------------------------------------------*/

/* Dispatch handler for TI PDK style interrupts. */
portBaseType xApplicationInterruptHandlerHook( portUInt32Type ulInterruptVectorNum )
{
   return Hwi_dispatchC( ulInterruptVectorNum );
}
/*---------------------------------------------------------------------------*/

/* Tick timer setup using TI PDK timers and interrupts. */
void vApplicationSetupTickInterruptHook( portUInt32Type ulTimerClockHz,
                                         portUInt32Type ulTickRateHz )
{
    TimerP_Handle pxTickTimerHandle = NULL;
    TimerP_Params xTimerParams;
    TimerP_Status xStatus;

    ( void ) ulTimerClockHz;

    vPortInitTimerCLECCfg( configTICK_TIMER_ID,
                           configTICK_TIMER_INT_NUM );

    TimerP_Params_init( &xTimerParams );
    xTimerParams.runMode    = TimerP_RunMode_CONTINUOUS;
    xTimerParams.startMode  = TimerP_StartMode_USER;
    xTimerParams.periodType = TimerP_PeriodType_MICROSECS;
    xTimerParams.period     = ( 1000000UL / ulTickRateHz );
    xTimerParams.intNum     = configTICK_TIMER_INT_NUM;

    pxTickTimerHandle = TimerP_create( configTICK_TIMER_ID,
                                       &prvTimerTickIsr,
                                       &xTimerParams );

    /* don't expect the handle to be null */
    if( NULL == pxTickTimerHandle )
    {
        vApplicationAbort();
    }

    xStatus = TimerP_start( pxTickTimerHandle );

    /* expect the timer to start OK */
    if( TimerP_OK != xStatus )
    {
        vApplicationAbort();
    }
}
/*---------------------------------------------------------------------------*/

/* Hardware setup using the TI PDK libraries. */
portBaseType vSetupTimerHardware( void )
{
    portBaseType xStatus = pdFAIL;
    Sciclient_ConfigPrms_t xConfig;

    Sciclient_configPrmsInit( &xConfig );

    if( CSL_PASS == Sciclient_init( &xConfig ) )
    {
        xStatus = pdPASS;
    }
    return xStatus;
}
/*-------------------------------------------------------------------------*/


