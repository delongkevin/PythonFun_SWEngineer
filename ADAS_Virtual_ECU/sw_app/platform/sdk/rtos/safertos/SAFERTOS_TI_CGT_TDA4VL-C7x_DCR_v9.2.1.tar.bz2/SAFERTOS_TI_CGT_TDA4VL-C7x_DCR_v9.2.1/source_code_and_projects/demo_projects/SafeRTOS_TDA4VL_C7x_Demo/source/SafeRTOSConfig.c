/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/


#include "SafeRTOS_API.h"
#include "SafeRTOSConfig.h"
#include "FullDemo.h"

#include "ti/csl/csl_tsc.h"
#include "ti/osal/src/nonos/Nonos_config.h"

/*-----------------------------------------------------------------------------
 * Local Constants
 *---------------------------------------------------------------------------*/

/* The user configuration for the timer module. */
#define configTIMER_TASK_STACK_SIZE         ( configMINIMAL_STACK_SIZE )
#define configTIMER_TASK_PRIORITY           ( fulldemoTIMER_TASK_PRIORITY )
#define configTIMER_QUEUE_LENGTH            ( fulldemoTIMER_CMD_QUEUE_LEN )
#define configTIMER_CMD_QUEUE_BUFFER_SIZE   ( ( configTIMER_QUEUE_LENGTH * sizeof( timerQueueMessageType ) ) + safertosapiQUEUE_OVERHEAD_BYTES )

/* The user configuration for the idle task. */
#define configIDLE_TASK_STACK_SIZE          ( configMINIMAL_STACK_SIZE )
#define configIDLE_HOOK_DATA_ADDR           ( ( void * ) &lnkIdleHookDataStartAddr )
#define configIDLE_HOOK_DATA_SIZE           ( ( portUInt32Type ) 0x20U )

/* Scheduler Initialisation Definitions */

#define configSTACK_CHECK_MARGIN            ( 0U )

/*-----------------------------------------------------------------------------
 * Function Prototypes
 *---------------------------------------------------------------------------*/

/* The call to xTaskInitializeScheduler is included within a wrapper
 * initialisation function. */
portBaseType xInitializeScheduler( void );


/*-----------------------------------------------------------------------------
 * Local Variables
 *---------------------------------------------------------------------------*/

static portInt8Type acIdleTaskStack[ configIDLE_TASK_STACK_SIZE ] __attribute__( ( aligned( safertosapiSTACK_ALIGNMENT ) ) ) = { 0 };

/* Declare the stack for the timer task, it cannot be done in the timer
 * module as the syntax for alignment is port specific. Also the callback
 * functions are executed in the timer task and their complexity/stack
 * requirements are application specific. */
static portInt8Type acTimerTaskStack[ configTIMER_TASK_STACK_SIZE ] __attribute__( ( aligned( safertosapiSTACK_ALIGNMENT ) ) ) = { 0 };
/* The buffer for the timer command queue. */
static portInt8Type acTimerCommandQueueBuffer[ configTIMER_CMD_QUEUE_BUFFER_SIZE ] __attribute__( ( aligned( 32 ) ) ) = { 0 };

/* A linker defined symbol that gives the start address of the Idle hook
 * data section. */
extern portUInt32Type lnkIdleHookDataStartAddr;

/*-----------------------------------------------------------------------------
 * Public functions
 *---------------------------------------------------------------------------*/

portBaseType xInitializeScheduler( void )
{
    portBaseType xInitSchedResult;

    /* The structure passed to xTaskInitializeScheduler() to configure the kernel
     * with the application defined constants and call back functions. */
    const xPORT_INIT_PARAMETERS xPortInit =
    {
        configSYSTICK_CLOCK_HZ,                 /* ulTimerClockHz */
        configTICK_RATE_HZ,                     /* ulTickRateHz */

        /* Interrupt number for yield. */
        configYIELD_INT_NUM,                    /* uxYieldInterruptNumber */

        /* Hook Functions */
        ( void * ) &ulDemoApplicationScHook,    /* pvSystemCallHookFunction */

        /* System Stack parameters */
        configSTACK_CHECK_MARGIN,               /* uxAdditionalStackCheckMarginBytes */

        /* Idle Task parameters */
        acIdleTaskStack,                        /* pcIdleTaskStackBuffer */
        configIDLE_TASK_STACK_SIZE,             /* uxIdleTaskStackSizeBytes */
        NULL,                                   /* pvIdleTaskTLSObject */

        /* Timer feature initialisation parameters */
        configTIMER_TASK_PRIORITY,              /* uxTimerTaskPriority */
        configTIMER_TASK_STACK_SIZE,            /* uxTimerTaskStackSize */
        acTimerTaskStack,                       /* pcTimerTaskStackBuffer */
        configTIMER_QUEUE_LENGTH,               /* uxTimerCommandQueueLength */
        configTIMER_CMD_QUEUE_BUFFER_SIZE,      /* uxTimerCommandQueueBufferSize */
        acTimerCommandQueueBuffer,              /* pcTimerCommandQueueBuffer */
    };

    /* Initialise the kernel by passing in a pointer to the xPortInit structure
     * and return the resulting error code. */
    xInitSchedResult = xTaskInitializeScheduler( &xPortInit );

    return xInitSchedResult;
}
/*--------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * Override functions for TI PDK library startup code.
 *---------------------------------------------------------------------------*/

/* Override the startup code mpu initialisation - not used in this demo. */
/*
void __mpu_init( void )
{
}
*/
/*-------------------------------------------------------------------------*/

/*****************************************************************************/
/* _SYSTEM_PRE_INIT() - _system_pre_init() is called in the C/C++ startup    */
/* routine (_c_int00()) and provides a mechanism for the user to             */
/* insert application specific low level initialization instructions prior   */
/* to calling main().  The return value of _system_pre_init() is used to     */
/* determine whether or not C/C++ global data initialization will be         */
/* performed (return value of 0 to bypass C/C++ auto-initialization).        */
/*                                                                           */
/* PLEASE NOTE THAT BYPASSING THE C/C++ AUTO-INITIALIZATION ROUTINE MAY      */
/* RESULT IN PROGRAM FAILURE.                                                */
/*                                                                           */
/* The version of _system_pre_init() below is skeletal and is provided to    */
/* illustrate the interface and provide default behavior.  To replace this   */
/* version rewrite the routine and include it as part of the current project.*/
/* The linker will include the updated version if it is linked in prior to   */
/* linking with the C/C++ runtime library.                                   */
/*****************************************************************************/
portBaseType _system_pre_init( void )
{
    return 1;
}
/*---------------------------------------------------------------------------*/

/*****************************************************************************/
/* _SYSTEM_POST_CINIT() - _system_post_cinit() is a hook function called in  */
/* the C/C++ auto-initialization function after cinit() and before pinit().  */
/*                                                                           */
/* The version of _system_post_cinit() below is skeletal and is provided to  */
/* illustrate the interface and provide default behavior.  To replace this   */
/* version rewrite the routine and include it as part of the current project.*/
/* The linker will include the updated version if it is linked in prior to   */
/* linking with the C/C++ runtime library.                                   */
/*****************************************************************************/
void _system_post_cinit( void )
{
    extern void c7x_startup_init(void);
    c7x_startup_init();
}
/*---------------------------------------------------------------------------*/
