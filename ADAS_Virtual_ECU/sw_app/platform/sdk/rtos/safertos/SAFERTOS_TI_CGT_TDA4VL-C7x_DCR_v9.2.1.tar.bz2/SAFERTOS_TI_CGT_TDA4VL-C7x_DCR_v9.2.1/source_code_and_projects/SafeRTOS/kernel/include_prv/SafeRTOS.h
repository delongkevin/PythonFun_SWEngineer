/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court, Long Ashton
    Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/


#ifndef INC_SAFERTOS_H
#define INC_SAFERTOS_H

#ifdef __cplusplus
extern "C" {
#endif

/* Basic SafeRTOS API definitions. */
#include "SafeRTOS_API.h"

/* Basic SafeRTOS definitions. */
#include "projdefs.h"

/* Application specific configuration options. */
#include "SafeRTOSConfig.h"

/* Definitions specific to the port being used. */
#include "portable.h"

#ifdef __cplusplus
}
#endif

#endif /* INC_SAFERTOS_H */
