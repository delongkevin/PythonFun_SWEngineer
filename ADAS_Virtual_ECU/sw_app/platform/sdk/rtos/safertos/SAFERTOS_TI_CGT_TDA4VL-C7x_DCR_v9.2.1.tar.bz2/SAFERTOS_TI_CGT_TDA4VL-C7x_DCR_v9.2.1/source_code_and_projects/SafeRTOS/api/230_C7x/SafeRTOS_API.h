/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#ifndef SAFERTOS_API_H
#define SAFERTOS_API_H

#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------
 * Port-specific API version number
 *---------------------------------------------------------------------------*/

#define safertosAPI_PORT_MAJOR_VERSION  ( 0 )
#define safertosAPI_PORT_MINOR_VERSION  ( 0 )
#define safertosAPI_PORT_RC_VERSION     ( 4 )

/*---------------------------------------------------------------------------*/

/* Application specific configuration options. */
#include "SafeRTOSConfig.h"

/*---------------------------------------------------------------------------*/

/* Define kernel function area definitions. */
#define KERNEL_FUNCTION           configKERNEL_FUNC_DEF
#define KERNEL_UNPRIV_FUNCTION    configKERNEL_UNPRIV_FUNC_DEF
#define KERNEL_INIT_FUNCTION      configKERNEL_INIT_FUNC_DEF
#define KERNEL_CREATE_FUNCTION    configKERNEL_CREATE_FUNC_DEF
#define KERNEL_DELETE_FUNCTION    configKERNEL_DELETE_FUNC_DEF
#define KERNEL_DATA               configKERNEL_DATA_DEF
#define KERNEL_DATA_MIRROR        configKERNEL_DATA_MIRROR_DEF

#define API_FUNCTION              configKERNEL_UNPRIV_FUNC_DEF
#define API_INIT_FUNCTION         configKERNEL_UNPRIV_FUNC_DEF
#define API_CREATE_FUNCTION       configKERNEL_UNPRIV_FUNC_DEF
#define API_DELETE_FUNCTION       configKERNEL_UNPRIV_FUNC_DEF

/* SafeRTOS includes. */
#include "apiBaseTypes.h"
#include "projdefs.h"
#include "apiComplexTypes.h"
#include "portAPI.h"

#include "listAPI.h"
#include "queueAPI.h"
#include "semaphoreAPI.h"
#include "timersAPI.h"
#include "eventGroupsAPI.h"
#include "mutexAPI.h"
#include "evtmplxAPI.h"
#include "taskAPI.h"
#include "streambufferAPI.h"

#include "apiWrapper.h"

#include "apiEventGroupsWrapper.h"
#include "apiEvtMplxWrapper.h"
#include "apiMutexWrapper.h"
#include "apiSemaphoreWrapper.h"
#include "apiStreamBufferWrapper.h"
#include "apiTimersWrapper.h"

/* configINCLUDE_CRC_FEATURE should be defined in SafeRTOSConfig.h */
#if ( configINCLUDE_CRC_FEATURE == 1 )
    #include "Reassurance.h"
    #include "CRCVerification.h"
#endif

/* MCDC Test Point: PROTOTYPE */


/* SAFERTOSTRACE PORTQUEUEOVERHEADBYTES */
#define safertosapiQUEUE_OVERHEAD_BYTES             ( 280U )
/* SAFERTOSTRACE PORTQUEUEOVERHEADBYTESENDIF */

#define safertosapiMAX_DELAY                        ( ( portTickType ) 0xFFFFFFFFFFFFFFFFU )

#define safertosapiWORD_ALIGNMENT                   ( 8U )

#define safertosapiSTACK_ALIGNMENT                  ( 0x80U )

/*-----------------------------------------------------------------------------
 * Interrupt mask API
 *---------------------------------------------------------------------------*/

/* Define these away for this port as we do not support interrupt nesting. */
#define safertosapiSET_INTERRUPT_MASK_FROM_ISR      portapiSET_INTERRUPT_MASK_FROM_ISR
#define safertosapiCLEAR_INTERRUPT_MASK_FROM_ISR    portapiCLEAR_INTERRUPT_MASK_FROM_ISR

#define safertosapiENTER_CRITICAL                   portapiENTER_CRITICAL
#define safertosapiEXIT_CRITICAL                    portapiEXIT_CRITICAL

/*-----------------------------------------------------------------------------
 * Scheduler utilities
 *---------------------------------------------------------------------------*/

#define safertosapiYIELD                            portapiYIELD

#define safertosapiYIELD_FROM_ISR                   portapiYIELD_FROM_ISR

/*---------------------------------------------------------------------------*/
/* Prototypes for application provided hook functions                        */
/*---------------------------------------------------------------------------*/

/* The application must instantiate an error hook function. */
void vApplicationErrorHook( portTaskHandleType xHandleOfTaskWithError,
                            portBaseType xErrorCode );

/* The application must instantiate an exception handler hook function. */
void vApplicationExceptionHandlerHook( portBaseType xAbortFlag, portBaseType xVectorType );

/* The application must instantiate an interrupt handler hook function. */
portBaseType xApplicationInterruptHandlerHook( portUInt32Type ulInterruptVectorNum );

/* The application must define vApplicationSetupTickInterruptHook()
 * to define a timer to generate the system tick. */
void vApplicationSetupTickInterruptHook( portUInt32Type ulTimerClockHz,
                                         portUInt32Type ulTickRateHz );

/* The application may define vApplicationTaskDeleteHook() when it
 * is desired to perform additional processing when a task is deleted. A
 * weak function is provided if the application does not want to implement
 * this hook function. */
void vApplicationTaskDeleteHook( portTaskHandleType xTaskBeingDeleted );

/* The application may define vApplicationTickHook() when it
 * is desired to perform additional processing on each tick interrupt. A
 * weak function is provided if the application does not want to implement
 * this hook function. */
void vApplicationTickHook( void );

/* The application may define vApplicationIdleHook() when it
 * is desired to perform background processing. A
 * weak function is provided if the application does not want to implement
 * this hook function. */
void vApplicationIdleHook( void );


#ifdef __cplusplus
}
#endif

#endif /* SAFERTOS_API_H */

