/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court, Long Ashton
    Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

/*
    API documentation is included in the user manual.  Do not refer to this
    file for documentation.
*/

#ifndef QUEUE_H
#define QUEUE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "queueAPI.h"

#define queueQUEUE_IS_MUTEX     ( ( portUnsignedBaseType ) 1U )
#define queueQUEUE_IS_QUEUE     ( ( portUnsignedBaseType ) 2U )

#define queueSEND_TO_BACK       ( ( portBaseType ) 0 )
#define queueSEND_TO_FRONT      ( ( portBaseType ) 1 )

/*-----------------------------------------------------------------------------
 * Private API
 *---------------------------------------------------------------------------*/
/* Functions beyond this part are not part of the public API and are intended
for use by the kernel only. */

/*
 * Since xQueueReceiveKrnl, xQueuePeekKrnl and xMutexTakeKrnl require essentially the
 * same functionality, the API functions are redirected to xQueueReceiveDataFromQueue.
 */
KERNEL_FUNCTION portBaseType xQueueReceiveDataFromQueue( xQUEUE *pxQueue, void *const pvBuffer, portTickType xTicksToWait, portBaseType xRemoveDataFromQueue );

/*
 * Since xQueueSendKrnl and xMutexGiveKrnl require essentially the same
 * functionality, the API functions are redirected to xQueueSendDataToQueue.
 */
KERNEL_FUNCTION portBaseType xQueueSendDataToQueue( xQUEUE *const pxQueue, const void *const pvItemToQueue, portTickType xTicksToWait, const portBaseType xPosition );

KERNEL_FUNCTION void vQueueRemoveListItemAndCheckInheritance( xListItem *pxListItem );

/* Tests the validity of the queue, returning pdTRUE if the queue is valid,
 * pdFALSE otherwise. */
KERNEL_FUNCTION portBaseType xQueueIsQueueValid( const xQUEUE *pxQueue );

#ifdef __cplusplus
}
#endif

#endif /* QUEUE_H */

