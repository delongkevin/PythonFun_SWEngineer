/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#ifndef PARTEST_H
#define PARTEST_H


/*--------------------------------------------------------------------------*/
/* Public constant definitions                                              */
/*--------------------------------------------------------------------------*/
#define partestLED_ON                   ( ( portInt32Type ) 1 )
#define partestLED_OFF                  ( ( portInt32Type ) 0 )

/* The LEDs that are supported by partest.c */
#define partestLED_0                   ( ( portUnsignedBaseType ) 0 )
#define partestLED_NONE                ( ( portUnsignedBaseType ) 1 )


/*--------------------------------------------------------------------------*/
/* Public function declarations                                             */
/*--------------------------------------------------------------------------*/
void vParTestInitialise( void );
void vParTestSetLED( portUnsignedBaseType uxLED, portBaseType xValue );
void vParTestToggleLED( portUnsignedBaseType uxLED );


/*--------------------------------------------------------------------------*/

#endif
