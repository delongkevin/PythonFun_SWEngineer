/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court, Long Ashton
    Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

/* Scheduler includes. */
#include "SafeRTOS.h"
#include "list.h"
#include "queue.h"
#include "evtmplx.h"
#include "task.h"

/* MCDC Test Point: PROTOTYPE */

/*-----------------------------------------------------------------------------
 * Private Type Definitions
 *---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
 * Private Constant Definitions
 *---------------------------------------------------------------------------*/
/* The set of all valid queue events. */
#define evtmplxALL_QUEUE_EVENTS               ( evtmplxQUEUE_MESSAGE_WAITING | evtmplxQUEUE_SPACE_AVAILABLE )

/* A non-zero constant used to indicate an invalid object-event index. */
#define evtmplxINVALID_OBJECT_EVENT_INDEX     ( portMAX_LIST_ITEM_VALUE )


/*-----------------------------------------------------------------------------
 * Private Function Declarations
 *---------------------------------------------------------------------------*/
/* prvCheckEvtMplxCreateParameters() checks the input parameters of a call to
 * xEvtMplxCreateKrnl().
 * If the parameters are all valid, prvCheckEvtMplxCreateParameters() returns
 * pdPASS; otherwise an appropriate error code is returned. */
KERNEL_CREATE_FUNCTION static portBaseType prvCheckEvtMplxCreateParameters( portInt8Type *pcEvtMplxMemoryBuffer,
                                                                            portUnsignedBaseType uxBufferLengthInBytes,
                                                                            portUnsignedBaseType uxMaximumRegisteredObjectEvents,
                                                                            portTaskHandleType xOwnerTaskHandle,
                                                                            const evtMplxHandleType *pxEvtMplxHandle );

/* prvCheckEvtMplxConfigureParameters() checks the input parameters to the
 * functions that configure an event multiplex object - xEvtMplxAddObjectEventsKrnl(),
 * xEvtMplxModifyObjectEventsKrnl() and xEvtMplxRemoveObjectEventsKrnl().
 * If the parameters are valid, prvCheckEvtMplxConfigureParameters() returns
 * pdPASS; otherwise an appropriate error code is returned. */
KERNEL_FUNCTION static portBaseType prvCheckEvtMplxConfigureParameters( const evtMplxType *pxEvtMplxObject,
                                                                        const void *pvTargetObjectHandle,
                                                                        portUnsignedBaseType uxEvents );

/* prvGetObjectEventIndex() inspects the array of object-events belonging to the
 * event multiplex object in order to retrieve either the index of the object-events
 * structure that relates to the specified object handle or the index of the
 * next free location in the object-events array.
 * If the index is successfully retrieved, the memory location referenced by
 * puxObjectEventIndex is set to the retrieved index and
 * prvGetObjectEventIndex() returns pdPASS.
 * If the index cannot be found, the memory location referenced by
 * puxObjectEventIndex is set to either the first free location in the
 * object-events array or evtmplxINVALID_OBJECT_EVENT_INDEX if there are no
 * free elements remaining - either way, pdFAIL is returned to the calling
 * function. */
KERNEL_FUNCTION static portBaseType prvGetObjectEventIndex( const evtMplxType *pxEvtMplxObject,
                                                            const void *pvTargetObjectHandle,
                                                            portUnsignedBaseType *puxObjectEventIndex );

KERNEL_FUNCTION static portBaseType prvUpdateObjectList( const xList *pxRegisteredEvtMplxObjects,
                                                         portUnsignedBaseType uxUpdatedStatus );

KERNEL_FUNCTION static portBaseType prvUpdateTargetObjectStatus( const xListItem *pxObjectEventListItem,
                                                                 portUnsignedBaseType uxCurrentEvents );

/* If the supplied events are valid, prvRegisterEvtMplxObject() calls the
 * appropriate function to add the event multiplex object to the target object's list
 * of registered event multiplex objects. */
KERNEL_FUNCTION static portBaseType prvRegisterEvtMplxObject( void *pvTargetObjectHandle,
                                                              portUnsignedBaseType uxEvents,
                                                              xListItem *pxEvtMplxObjectEventListItem );

/* If any of the object-events associated with the event multiplex object have
 * occurred, they are copied into the supplied axObjectEvents array. */
KERNEL_FUNCTION static portBaseType prvGetOccurredObjectEvents( evtMplxType *pxEvtMplxObject,
                                                                evtMplxObjectEventsType axObjectEvents[],
                                                                portUnsignedBaseType uxObjectEventsArraySize,
                                                                portUnsignedBaseType *puxNumberOfObjectEvents );

/* Free the specified element of the object-events array. */
KERNEL_FUNCTION static void prvFreeObjectEvent( evtMplxType *pxEvtMplxObject,
                                                evtMplxObjectEventControlType *pxObjectEventControl );

KERNEL_FUNCTION static portBaseType prvQueueAddEvtMplxListItem( xQueueHandle xQueue,
                                                                xListItem *pxEvtMplxObjectEventListItem );

/* Add the specified event multiplex object list item to the list of event multiplex
 * objects owned by this task. */
KERNEL_FUNCTION static portBaseType prvTaskAddEvtMplxListItem( xTCB *pxTCB,
                                                               xListItem *pxEvtMplxListItem );

/* Add the specified event multiplex object to the event group's list of event multiplex
 * objects to be updated whenever bits are set in the event group. */
KERNEL_FUNCTION static portBaseType prvEventGroupAddEvtMplxListItem( eventGroupHandleType xEventGroupHandle,
                                                                     xListItem *pxEvtMplxObjectEventListItem );

/* Retrieves the current notification status of the specified task for the
 * purpose of updating the associated event multiplex object-events. */
KERNEL_FUNCTION static portBaseType prvQueryTaskNotificationStatus( portTaskHandleType xTask,
                                                                    portUnsignedBaseType *puxCurrentEvents );

KERNEL_FUNCTION static portUnsignedBaseType prvGetEvtMplxQueueStatus( const xQUEUE *const pxQueue );

KERNEL_FUNCTION static portUnsignedBaseType prvAreAnyEventGroupBitsSet( const eventGroupType *pxEventGroup );

KERNEL_FUNCTION static portBaseType prvEventGroupDeleted( xListItem *pxObjectEventListItem );

/*-----------------------------------------------------------------------------
 * Private Variable Declarations
 *---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
 * Public Function Definitions
 *---------------------------------------------------------------------------*/

KERNEL_CREATE_FUNCTION portBaseType xEvtMplxCreateKrnl( portInt8Type *pcEvtMplxMemoryBuffer,
                                                        portUnsignedBaseType uxBufferLengthInBytes,
                                                        portUnsignedBaseType uxMaximumRegisteredObjectEvents,
                                                        portTaskHandleType xOwnerTaskHandle,
                                                        evtMplxHandleType *pxEvtMplxHandle )
{
    portBaseType xResult;
    evtMplxType *pxEvtMplxObject;
    evtMplxObjectEventControlType *pxObjectEventControl;
    xTCB *pxOwnerTCB;
    portUnsignedBaseType uxAddress;
    portUnsignedBaseType uxIndex;

    /* Check the input parameters. */
    xResult = prvCheckEvtMplxCreateParameters( pcEvtMplxMemoryBuffer,
                                               uxBufferLengthInBytes,
                                               uxMaximumRegisteredObjectEvents,
                                               xOwnerTaskHandle,
                                               pxEvtMplxHandle );
    if( pdPASS == xResult )
    {
        /* Obtain access to the event multiplex object. */
        pxEvtMplxObject = ( evtMplxType * ) ( void * ) pcEvtMplxMemoryBuffer;

        portENTER_CRITICAL_WITHIN_API();
        {
            /* Is this event multiplex object already in use? */
            if( ( portDataAddressType )( pxEvtMplxObject->pxOwnerTCB ) == ( portDataAddressType ) ( ~( pxEvtMplxObject->uxOwnerTCBMirror ) ) )
            {
                /* If the provided event multiplex object is valid, then it must be
                 * in use already and cannot be reused. */
                xResult = errEVT_MPLX_OBJECT_ALREADY_IN_USE;

                /* MCDC Test Point: STD_IF "xEvtMplxCreateKrnl" */
            }
            /* Pre-initialise the handle to make sure the destination address is
             * valid. */
            else if( pdPASS != portCOPY_DATA_TO_TASK( pxEvtMplxHandle, &pxEvtMplxObject, ( portUnsignedBaseType ) sizeof( evtMplxHandleType ) ) )
            {
                xResult = errINVALID_DATA_RANGE;

                /* MCDC Test Point: STD_ELSE_IF "xEvtMplxCreateKrnl" */
            }
            else
            {
                /* Determine the owner of this event multiplex object. */
                taskGET_TCB_FROM_HANDLE( xOwnerTaskHandle, pxOwnerTCB );

                /* Initialise the list item used to associate this event multiplex
                 * object with a task.
                 * Note: The xItemValue member of the event multiplex list item is
                 * used to locate the object-event that is configured for a task
                 * notification event. */
                vListInitialiseItem( &( pxEvtMplxObject->xEvtMplxListItem ) );
                listSET_LIST_ITEM_OWNER( &( pxEvtMplxObject->xEvtMplxListItem ),
                                         pxEvtMplxObject );
                listSET_LIST_ITEM_VALUE( &( pxEvtMplxObject->xEvtMplxListItem ),
                                         evtmplxINVALID_OBJECT_EVENT_INDEX );

                /* Register the event multiplex object with the owner task. */
                xResult = prvTaskAddEvtMplxListItem( pxOwnerTCB,
                                                     &( pxEvtMplxObject->xEvtMplxListItem ) );
                if( pdPASS == xResult )
                {
                    /* Set the owner of this event multiplex object. */
                    pxEvtMplxObject->pxOwnerTCB = pxOwnerTCB;

                    /* The task is not currently blocked. */
                    pxEvtMplxObject->xTaskIsBlocked = pdFALSE;

                    /* Initialise the number of registered object-events and
                     * store the maximum number of object-events that can be
                     * registered with this event multiplex object. */
                    pxEvtMplxObject->uxNumberOfRegisteredObjectEvents = ( portUnsignedBaseType ) 0;
                    pxEvtMplxObject->uxMaximumRegisteredObjectEvents = uxMaximumRegisteredObjectEvents;

                    /* Store the location of the array of
                     * evtMplxObjectEventControlType for this event multiplex
                     * object. */
                    uxAddress = ( portUnsignedBaseType ) ( pcEvtMplxMemoryBuffer );
                    uxAddress += ( portUnsignedBaseType ) sizeof( evtMplxType );
                    pxEvtMplxObject->paxRegisteredObjectEvents = ( evtMplxObjectEventControlType * ) uxAddress;

                    /* Initialise this event multiplex object's register of
                     * object-events. */
                    for( uxIndex = 0U; uxIndex < uxMaximumRegisteredObjectEvents; uxIndex++ )
                    {
                        pxObjectEventControl = &( pxEvtMplxObject->paxRegisteredObjectEvents[ uxIndex ] );

                        pxObjectEventControl->xObjectEvent.pvObjectHandle = NULL;
                        pxObjectEventControl->xObjectEvent.uxEvents = evtmplxNO_EVENTS;
                        pxObjectEventControl->uxCurrentEvents = evtmplxNO_EVENTS;

                        vListInitialiseItem( &( pxObjectEventControl->xObjectEventListItem ) );
                        listSET_LIST_ITEM_OWNER( &( pxObjectEventControl->xObjectEventListItem ),
                                                 pxEvtMplxObject );
                        listSET_LIST_ITEM_VALUE( &( pxObjectEventControl->xObjectEventListItem ),
                                                 ( ( portTickType ) uxIndex ) );

                        /* MCDC Test Point: STD "xEvtMplxCreateKrnl" */
                    }

                    /* Set the mirror variable. */
                    pxEvtMplxObject->uxOwnerTCBMirror = ~( ( portUnsignedBaseType ) pxEvtMplxObject->pxOwnerTCB );

                    /* MCDC Test Point: STD_IF "xEvtMplxCreateKrnl" */
                }
                /* MCDC Test Point: ADD_ELSE "xEvtMplxCreateKrnl" */

                /* MCDC Test Point: STD_ELSE "xEvtMplxCreateKrnl" */
            }
        }
        portEXIT_CRITICAL_WITHIN_API();

        /* MCDC Test Point: STD_IF "xEvtMplxCreateKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xEvtMplxCreateKrnl" */

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xEvtMplxAddObjectEventsKrnl( evtMplxHandleType xEvtMplxHandle,
                                                          void *pvTargetObjectHandle,
                                                          portUnsignedBaseType uxEvents )
{
    portBaseType xResult;
    evtMplxType *pxEvtMplxObject;
    portUnsignedBaseType uxObjectEventIndex = 0U;
    evtMplxObjectEventControlType *pxObjectEvent;

    /* Obtain access to the event multiplex object. */
    pxEvtMplxObject = ( evtMplxType * ) xEvtMplxHandle;

    /* Check the input parameters. */
    xResult = prvCheckEvtMplxConfigureParameters( pxEvtMplxObject,
                                                  pvTargetObjectHandle,
                                                  uxEvents );
    if( pdPASS == xResult )
    {
        portENTER_CRITICAL_WITHIN_API();
        {
            /* Is the specified object handle already registered with this event
             * multiplex object? */
            if( pdPASS == prvGetObjectEventIndex( pxEvtMplxObject,
                                                  pvTargetObjectHandle,
                                                  &uxObjectEventIndex ) )
            {
                /* The specified target object is already registered with this
                 * event multiplex object, so can't be added again. */
                xResult = errINVALID_EVT_MPLX_OPERATION;

                /* MCDC Test Point: STD_IF "xEvtMplxAddObjectEventsKrnl" */
            }
            else
            {
                /* If there are no free elements in the array of object-events
                 * belonging to this event multiplex object, uxObjectEventIndex will
                 * have been set to evtmplxINVALID_OBJECT_EVENT_INDEX. */
                if( ( portUnsignedBaseType ) evtmplxINVALID_OBJECT_EVENT_INDEX != uxObjectEventIndex )
                {
                    /* Register the event multiplex object with the specified target
                     * object. */
                    pxObjectEvent = &( pxEvtMplxObject->paxRegisteredObjectEvents[ uxObjectEventIndex ] );
                    xResult = prvRegisterEvtMplxObject( pvTargetObjectHandle,
                                                        uxEvents,
                                                        &( pxObjectEvent->xObjectEventListItem ) );
                    if( pdPASS == xResult )
                    {
                        /* Increment the number of registered object-events. */
                        pxEvtMplxObject->uxNumberOfRegisteredObjectEvents++;

                        /* Register this object handle and associated events
                         * with the event multiplex object. */
                        pxObjectEvent->xObjectEvent.pvObjectHandle = pvTargetObjectHandle;
                        pxObjectEvent->xObjectEvent.uxEvents = uxEvents;

                        if( evtmplxTASK_NOTIFICATION_RECEIVED == uxEvents )
                        {
                            /* In the case of task notification events, store
                             * the object-event index in the event multiplex object
                             * list item in order to make updating/removing the
                             * object-event easier. */
                            listSET_LIST_ITEM_VALUE( &( pxEvtMplxObject->xEvtMplxListItem ),
                                                     ( portTickType ) uxObjectEventIndex );

                            /* MCDC Test Point: STD_IF "xEvtMplxAddObjectEventsKrnl" */
                        }
                        /* MCDC Test Point: ADD_ELSE "xEvtMplxAddObjectEventsKrnl" */

                        /* MCDC Test Point: STD_IF "xEvtMplxAddObjectEventsKrnl" */
                    }
                    /* MCDC Test Point: ADD_ELSE "xEvtMplxAddObjectEventsKrnl" */

                    /* MCDC Test Point: STD_IF "xEvtMplxAddObjectEventsKrnl" */
                }
                else
                {
                    /* The event multiplex object cannot accept any more
                     * object-events. */
                    xResult = errEVT_MPLX_OBJECT_EVENTS_LIMIT_REACHED;

                    /* MCDC Test Point: STD_ELSE "xEvtMplxAddObjectEventsKrnl" */
                }

                /* MCDC Test Point: STD_ELSE "xEvtMplxAddObjectEventsKrnl" */
            }
        }
        portEXIT_CRITICAL_WITHIN_API();

        /* MCDC Test Point: STD_IF "xEvtMplxAddObjectEventsKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xEvtMplxAddObjectEventsKrnl" */

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xEvtMplxModifyObjectEventsKrnl( evtMplxHandleType xEvtMplxHandle,
                                                             const void *pvTargetObjectHandle,
                                                             portUnsignedBaseType uxEvents )
{
    portBaseType xResult;
    evtMplxType *pxEvtMplxObject;
    portUnsignedBaseType uxObjectEventIndex = 0U;

    /* Obtain access to the event multiplex object. */
    pxEvtMplxObject = ( evtMplxType * ) xEvtMplxHandle;

    /* Check the input parameters. */
    xResult = prvCheckEvtMplxConfigureParameters( pxEvtMplxObject,
                                                  pvTargetObjectHandle,
                                                  uxEvents );
    if( pdPASS == xResult )
    {
        /* Is the specified object handle already registered with this event
         * multiplex object? */
        if( pdPASS == prvGetObjectEventIndex( pxEvtMplxObject,
                                              pvTargetObjectHandle,
                                              &uxObjectEventIndex ) )
        {
            /* Update the events associated with the specified object handle. */
            pxEvtMplxObject->paxRegisteredObjectEvents[ uxObjectEventIndex ].xObjectEvent.uxEvents = uxEvents;

            /* MCDC Test Point: STD_IF "xEvtMplxModifyObjectEventsKrnl" */
        }
        else
        {
            /* The specified object handle is not already registered with this
             * event multiplex object, therefore this call to
             * xEvtMplxModifyObjectEventsKrnl() is invalid. */
            xResult = errINVALID_EVT_MPLX_OPERATION;

            /* MCDC Test Point: STD_ELSE "xEvtMplxModifyObjectEventsKrnl" */
        }

        /* MCDC Test Point: STD_IF "xEvtMplxModifyObjectEventsKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xEvtMplxModifyObjectEventsKrnl" */

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xEvtMplxRemoveObjectEventsKrnl( evtMplxHandleType xEvtMplxHandle,
                                                             const void *pvTargetObjectHandle )
{
    portBaseType xResult;
    evtMplxType *pxEvtMplxObject;
    portUnsignedBaseType uxObjectEventIndex = 0U;
    evtMplxObjectEventControlType *pxObjectEvent;

    /* Obtain access to the event multiplex object. */
    pxEvtMplxObject = ( evtMplxType * ) xEvtMplxHandle;

    /* Check the input parameters. */
    xResult = prvCheckEvtMplxConfigureParameters( pxEvtMplxObject,
                                                  pvTargetObjectHandle,
                                                  ( portUnsignedBaseType ) ~evtmplxNO_EVENTS );
    if( pdPASS == xResult )
    {
        /* Is the specified object handle already registered with this event
         * multiplex object? */
        if( pdPASS == prvGetObjectEventIndex( pxEvtMplxObject,
                                              pvTargetObjectHandle,
                                              &uxObjectEventIndex ) )
        {
            portENTER_CRITICAL_WITHIN_API();
            {
                /* Locate the object-event element that is being removed. */
                pxObjectEvent = &( pxEvtMplxObject->paxRegisteredObjectEvents[ uxObjectEventIndex ] );

                /* Is the target object the task that owns the event multiplex
                 * object? If it is, then the object-event is a task
                 * notification and needs to be handled differently. */
                if( pvTargetObjectHandle == pxEvtMplxObject->pxOwnerTCB )
                {
                    /* Reset the xItemValue member of the event multiplex list item
                     * to indicate that the event multiplex object is no longer
                     * interested in task notification events. */
                    listSET_LIST_ITEM_VALUE( &( pxEvtMplxObject->xEvtMplxListItem ),
                                             evtmplxINVALID_OBJECT_EVENT_INDEX );

                    /* MCDC Test Point: STD_IF "xEvtMplxRemoveObjectEventsKrnl" */
                }
                else
                {
                    /* Remove the object event list item from the target
                     * object's event list. */
                    vListRemove( &( pxObjectEvent->xObjectEventListItem ) );

                    /* MCDC Test Point: STD_ELSE "xEvtMplxRemoveObjectEventsKrnl" */
                }

                /* Free the element in the object-events array for this object. */
                prvFreeObjectEvent( pxEvtMplxObject, pxObjectEvent );
            }
            portEXIT_CRITICAL_WITHIN_API();

            /* MCDC Test Point: STD_IF "xEvtMplxRemoveObjectEventsKrnl" */
        }
        else
        {
            /* The specified object handle is not already registered with this
             * event multiplex object, therefore this call to
             * xEvtMplxRemoveObjectEventsKrnl() is invalid. */
            xResult = errINVALID_EVT_MPLX_OPERATION;

            /* MCDC Test Point: STD_ELSE "xEvtMplxRemoveObjectEventsKrnl" */
        }

        /* MCDC Test Point: STD_IF "xEvtMplxRemoveObjectEventsKrnl" */
    }
    /* MCDC Test Point: ADD_ELSE "xEvtMplxRemoveObjectEventsKrnl" */

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xEvtMplxWaitKrnl( evtMplxHandleType xEvtMplxHandle,
                                               evtMplxObjectEventsType axObjectEvents[],
                                               portUnsignedBaseType uxObjectEventsArraySize,
                                               portUnsignedBaseType *puxNumberOfObjectEvents,
                                               portTickType xTicksToWait )
{
    portBaseType xResult;
    evtMplxType *pxEvtMplxObject;
    xTimeOutType xTimeOut;

    /* Has the scheduler started? */
    if( pdFALSE == xTaskIsSchedulerStartedKrnl() )
    {
        /* An event multiplex object is tied to the pxCurrentTCB, therefore it cannot
         * be configured until the scheduler is running. */
        xResult = errSCHEDULER_IS_NOT_RUNNING;

        /* MCDC Test Point: STD_IF "xEvtMplxWaitKrnl" */
    }
    else if( pdFALSE != xTaskIsSchedulerSuspended() )
    {
        /* Calls to xEvtMplxWaitKrnl() while the scheduler is suspended are not
         * permitted. */
        xResult = errSCHEDULER_IS_SUSPENDED;

        /* MCDC Test Point: STD_ELSE_IF "xEvtMplxWaitKrnl" */
    }
    else if( NULL == xEvtMplxHandle )
    {
        /* A valid pointer to an event multiplex handle must be supplied. */
        xResult = errNULL_PARAMETER_SUPPLIED;

        /* MCDC Test Point: STD_ELSE_IF "xEvtMplxWaitKrnl" */
    }
    else if( NULL == axObjectEvents )
    {
        /* A valid array for storing object-events must be supplied. */
        xResult = errNULL_PARAMETER_SUPPLIED;

        /* MCDC Test Point: STD_ELSE_IF "xEvtMplxWaitKrnl" */
    }
    else if( 0U == uxObjectEventsArraySize )
    {
        /* The length of the array for storing object-events must be non-zero. */
        xResult = errINVALID_PARAMETERS;

        /* MCDC Test Point: STD_ELSE_IF "xEvtMplxWaitKrnl" */
    }
    else if( NULL == puxNumberOfObjectEvents )
    {
        /* A valid pointer must be supplied. */
        xResult = errNULL_PARAMETER_SUPPLIED;

        /* MCDC Test Point: STD_ELSE_IF "xEvtMplxWaitKrnl" */
    }
    else
    {
        /* Obtain access to the event multiplex object. */
        pxEvtMplxObject = ( evtMplxType * ) xEvtMplxHandle;

        /* Is this a valid event multiplex object? */
        if( ( portDataAddressType )( pxEvtMplxObject->pxOwnerTCB ) != ( portDataAddressType ) ~( pxEvtMplxObject->uxOwnerTCBMirror ) )
        {
            /* A valid event multiplex handle must be supplied. */
            xResult = errINVALID_EVT_MPLX_HANDLE;

            /* MCDC Test Point: STD_IF "xEvtMplxWaitKrnl" */
        }
        /* Is this event multiplex object owned by the calling task? */
        else if( pxCurrentTCB != pxEvtMplxObject->pxOwnerTCB )
        {
            /* A valid event multiplex handle must be supplied. */
            xResult = errINVALID_EVT_MPLX_HANDLE;

            /* MCDC Test Point: STD_ELSE_IF "xEvtMplxWaitKrnl" */
        }
        /* Are there any object-events registered with this event multiplex object? */
        else if( ( portUnsignedBaseType ) 0U == pxEvtMplxObject->uxNumberOfRegisteredObjectEvents )
        {
            /* At least one object-event must be registered before calling
             * xEvtMplxWaitKrnl(). */
            xResult = errINVALID_EVT_MPLX_OPERATION;

            /* MCDC Test Point: STD_ELSE_IF "xEvtMplxWaitKrnl" */
        }
        else
        {
            /* Enter a critical section to ensure that:
             * 1. No ticks occur during the call to vTaskSetTimeOut().
             * 2. The array of object-events is not modified while it is being
             *    accessed in this function.
             * 3. No ISR or context switch during call to
             *    vTaskAddCurrentTaskToDelayedList(). */
            portENTER_CRITICAL_WITHIN_API();
            {
                /* Record the time on entry to xEvtMplxWaitKrnl() so that a
                 * timeout can be checked for later. */
                vTaskSetTimeOut( &xTimeOut );

                do
                {
                    /* Have any object-events occurred? */
                    xResult = prvGetOccurredObjectEvents( pxEvtMplxObject,
                                                          axObjectEvents,
                                                          uxObjectEventsArraySize,
                                                          puxNumberOfObjectEvents );

                    /* If object-events have occurred or there was an error
                     * copying them to the application supplied array, there is
                     * nothing else to do before returning. */
                    if( errEVT_MPLX_NO_EVENTS_OCCURRED == xResult )
                    {
                        /* Need to call xTaskCheckForTimeout() as time could
                         * have passed since it was last called (if this is
                         * not the first time around this loop).
                         * NOTE: If no block time has been supplied, this call
                         * to xTaskCheckForTimeout() will return pdTRUE. */
                        if( xTaskCheckForTimeOut( &xTimeOut, &xTicksToWait ) == pdFALSE )
                        {
                            /* Add to the current task to the delayed list -
                             * this call MUST either be made with the
                             * scheduler suspended or from within a critical
                             * section. */
                            vTaskAddCurrentTaskToDelayedList( xTicksToWait );
                            pxEvtMplxObject->xTaskIsBlocked = pdTRUE;

                            /* Force a reschedule. */
                            taskYIELD_WITHIN_API();

                            /* Higher priority tasks and interrupts could have
                             * executed between this task being unblocked and
                             * entering the Running state, therefore the event
                             * that caused this task to unblock could possibly
                             * have been negated when this line is executed. */

                            /* Ensure the 'task is blocked' flag is cleared in
                             * case the unblock was due to a timeout. */
                            pxEvtMplxObject->xTaskIsBlocked = pdFALSE;

                            /* Check again if any events have occurred. */
                            xResult = errERRONEOUS_UNBLOCK;

                            /* MCDC Test Point: STD_IF "xEvtMplxWaitKrnl" */
                        }
                        /* MCDC Test Point: ADD_ELSE "xEvtMplxWaitKrnl" */

                        /* MCDC Test Point: STD_IF "xEvtMplxWaitKrnl" */
                    }
                    /* MCDC Test Point: ADD_ELSE "xEvtMplxWaitKrnl" */

                    /* MCDC Test Point: WHILE_INTERNAL "xEvtMplxWaitKrnl" "( errERRONEOUS_UNBLOCK == xResult )" */
                } while( errERRONEOUS_UNBLOCK == xResult );
            }
            portEXIT_CRITICAL_WITHIN_API();

            /* MCDC Test Point: STD_ELSE "xEvtMplxWaitKrnl" */
        }

        /* MCDC Test Point: STD_ELSE "xEvtMplxWaitKrnl" */
    }

    return xResult;
}
/*---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
 * Private API Function Definitions
 *---------------------------------------------------------------------------*/

KERNEL_FUNCTION void vEvtMplxInitQueueEvtMplxObjects( xQUEUE *const pxQueue )
{
    vListInitialise( &( pxQueue->xRegisteredEvtMplxObjects ) );

    /* MCDC Test Point: STD "vEvtMplxInitQueueEvtMplxObjects" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION void vEvtMplxInitTaskEvtMplxObjects( xTCB *const pxTCB )
{
    vListInitialise( &( pxTCB->xEvtMplxObjectsList ) );
    ( void ) pxTCB;
    /* MCDC Test Point: STD "vEvtMplxInitTaskEvtMplxObjects" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION void vEvtMplxInitEventGroupEvtMplxObjects( eventGroupType *pxEventGroup )
{
    vListInitialise( &( pxEventGroup->xRegisteredEvtMplxObjects ) );

    /* MCDC Test Point: STD "vEvtMplxInitEventGroupEvtMplxObjects" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xEvtMplxUpdateTaskEvtMplxObjects( const xTCB *pxTCB, portUnsignedBaseType uxCurrentStatus )
{
    portBaseType xContextSwitchRequired = pdFALSE;

    /* Does this task own any event multiplex objects? */
    if( ( portUnsignedBaseType ) listCURRENT_LIST_LENGTH( &( pxTCB->xEvtMplxObjectsList ) ) > ( portUnsignedBaseType )  0 )
    {
        xContextSwitchRequired = prvUpdateObjectList( &( pxTCB->xEvtMplxObjectsList ), uxCurrentStatus );

        /* MCDC Test Point: STD_IF "xEvtMplxUpdateTaskEvtMplxObjects" */
    }
    else
    {
        xContextSwitchRequired = pdFALSE;

        /* MCDC Test Point: STD_ELSE "xEvtMplxUpdateTaskEvtMplxObjects" */
    }
    return xContextSwitchRequired;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xEvtMplxUpdateQueueEvtMplxObjects( const xQUEUE *const pxQueue )
{
    portBaseType xContextSwitchRequired;
    portUnsignedBaseType uxCurrentStatus;

    /* Are there any event multiplex objects registered with this queue? */
    if( listCURRENT_LIST_LENGTH( &( pxQueue->xRegisteredEvtMplxObjects ) ) > 0U )
    {
        uxCurrentStatus = prvGetEvtMplxQueueStatus( pxQueue );

        xContextSwitchRequired = prvUpdateObjectList( &( pxQueue->xRegisteredEvtMplxObjects ), uxCurrentStatus );

        /* MCDC Test Point: STD_IF "xEvtMplxUpdateQueueEvtMplxObjects" */
    }
    else
    {
        xContextSwitchRequired = pdFALSE;

        /* MCDC Test Point: STD_ELSE "xEvtMplxUpdateQueueEvtMplxObjects" */
    }

    return xContextSwitchRequired;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION portBaseType xEvtMplxUpdateEventGroupEvtMplxObjects( const eventGroupType *pxEventGroup )
{
    portBaseType xContextSwitchRequired;
    portUnsignedBaseType uxCurrentEvents;

    portENTER_CRITICAL_WITHIN_API();
    {
        /* Are there any event multiplex objects registered with this event group? */
        if( listCURRENT_LIST_LENGTH( &( pxEventGroup->xRegisteredEvtMplxObjects ) ) > 0U )
        {
            uxCurrentEvents = prvAreAnyEventGroupBitsSet( pxEventGroup );

            xContextSwitchRequired = prvUpdateObjectList( &( pxEventGroup->xRegisteredEvtMplxObjects ), uxCurrentEvents);

            /* MCDC Test Point: STD_IF "xEvtMplxUpdateEventGroupEvtMplxObjects" */
        }
        else
        {
            xContextSwitchRequired = pdFALSE;

            /* MCDC Test Point: STD_ELSE "xEvtMplxUpdateEventGroupEvtMplxObjects" */
        }
    }
    portEXIT_CRITICAL_WITHIN_API();

    return xContextSwitchRequired;
}
/*---------------------------------------------------------------------------*/

KERNEL_DELETE_FUNCTION portBaseType xEvtMplxRemoveEventGroupEvtMplxObjects( const eventGroupType *pxEventGroup )
{
    portBaseType xContextSwitchRequired = pdFALSE;
    const xMiniListItem *pxEvtMplxObjectListEnd;
    xListItem *pxEvtMplxObjectListItem;

    portENTER_CRITICAL_WITHIN_API();
    {
        /* Are there any event multiplex objects registered with this event group? */
        if( listCURRENT_LIST_LENGTH( &( pxEventGroup->xRegisteredEvtMplxObjects ) ) > 0U )
        {
            /* Obtain the end of list marker for the list of registered event
             * multiplex objects. */
            pxEvtMplxObjectListEnd = listGET_END_MARKER( &( pxEventGroup->xRegisteredEvtMplxObjects ) );

            /* Obtain the head entry in the list of registered event multiplex
             * objects. */
            pxEvtMplxObjectListItem = listGET_HEAD_ENTRY( &( pxEventGroup->xRegisteredEvtMplxObjects ) );

            /* Loop through the registered event multiplex objects (this function has
             * already determined that there is at least one), removing the
             * association with this event group. */
            do
            {
                /* Remove the association with this event group from the event
                 * multiplex object-event (this will also remove this object-event
                 * list item from the list of registered event multiplex objects. */
                if( pdTRUE == prvEventGroupDeleted( pxEvtMplxObjectListItem ) )
                {
                    /* A higher priority task has been unblocked. */
                    xContextSwitchRequired = pdTRUE;

                    /* MCDC Test Point: STD_IF "xEvtMplxRemoveEventGroupEvtMplxObjects" */
                }
                /* MCDC Test Point: ADD_ELSE "xEvtMplxRemoveEventGroupEvtMplxObjects" */

                /* Obtain the new head entry in the list of registered event
                 * multiplex objects. */
                pxEvtMplxObjectListItem = listGET_HEAD_ENTRY( &( pxEventGroup->xRegisteredEvtMplxObjects ) );

                /* MCDC Test Point: WHILE_INTERNAL "xEvtMplxRemoveEventGroupEvtMplxObjects" "( ( const xMiniListItem * ) pxEvtMplxObjectListItem != pxEvtMplxObjectListEnd )" */
            } while( ( const xMiniListItem * ) pxEvtMplxObjectListItem != pxEvtMplxObjectListEnd );

            /* MCDC Test Point: STD_IF "xEvtMplxRemoveEventGroupEvtMplxObjects" */
        }
        /* MCDC Test Point: ADD_ELSE "xEvtMplxRemoveEventGroupEvtMplxObjects" */
    }
    portEXIT_CRITICAL_WITHIN_API();

    return xContextSwitchRequired;
}
/*---------------------------------------------------------------------------*/

KERNEL_DELETE_FUNCTION void vEvtMplxTaskDeleted( xTCB *pxTCB )
{
    const xMiniListItem *pxOwnedEvtMplxObjectListEnd;
    xListItem *pxOwnedEvtMplxObjectListItem;
    evtMplxType *pxEvtMplxObject;
    portUnsignedBaseType uxIndex;
    evtMplxObjectEventControlType *pxObjectEventControl;

    const xList *pxEvtMplxObjectsList = &( pxTCB->xEvtMplxObjectsList );

    /* THIS FUNCTION MUST BE CALLED FROM WITHIN A CRITICAL SECTION. */


    /* Obtain the end of list marker for the list of event multiplex objects owned by
     * the task that is being deleted. */
    pxOwnedEvtMplxObjectListEnd = listGET_END_MARKER( pxEvtMplxObjectsList );

    /* Obtain the head entry in the list of event multiplex objects owned by the task
     * that is being deleted. */
    pxOwnedEvtMplxObjectListItem = listGET_HEAD_ENTRY( pxEvtMplxObjectsList );

    /* Loop through the owned event multiplex objects. */
    /* MCDC Test Point: WHILE_EXTERNAL "vEvtMplxTaskDeleted" "( ( const xMiniListItem * ) pxOwnedEvtMplxObjectListItem != pxOwnedEvtMplxObjectListEnd )" */
    while( ( const xMiniListItem * ) pxOwnedEvtMplxObjectListItem != pxOwnedEvtMplxObjectListEnd )
    {
        pxEvtMplxObject = ( evtMplxType * ) listGET_LIST_ITEM_OWNER( pxOwnedEvtMplxObjectListItem );

        /* Loop through all the object-events associated with this event multiplex
         * object, removing the registration with any target objects. */
        for( uxIndex = 0U; uxIndex < pxEvtMplxObject->uxMaximumRegisteredObjectEvents; uxIndex++ )
        {
            /* Locate the next object-event element. */
            pxObjectEventControl = &( pxEvtMplxObject->paxRegisteredObjectEvents[ uxIndex ] );

            /* Is this object-event element associated with a target object? */
            if( pxObjectEventControl->xObjectEvent.pvObjectHandle != NULL )
            {
                /* Is the target object the task that owns the event multiplex
                 * object? If it is, then the object-event is a task
                 * notification and needs to be handled differently. */
                if( ( portUnsignedBaseType ) listGET_LIST_ITEM_VALUE( &( pxEvtMplxObject->xEvtMplxListItem ) ) == uxIndex )
                {
                    /* Reset the xItemValue member of the event multiplex list item
                     * to indicate that the event multiplex object is no longer
                     * interested in task notification events. */
                    listSET_LIST_ITEM_VALUE( &( pxEvtMplxObject->xEvtMplxListItem ),
                                             evtmplxINVALID_OBJECT_EVENT_INDEX );

                    /* MCDC Test Point: STD_IF "vEvtMplxTaskDeleted" */
                }
                else
                {
                    /* Remove the object event list item from the target
                     * object's event list. */
                    vListRemove( &( pxObjectEventControl->xObjectEventListItem ) );

                    /* MCDC Test Point: STD_ELSE "vEvtMplxTaskDeleted" */
                }

                /* Free the element in the object-events array for this
                 * object. */
                prvFreeObjectEvent( pxEvtMplxObject, pxObjectEventControl );

                /* MCDC Test Point: STD_IF "vEvtMplxTaskDeleted" */
            }
            /* MCDC Test Point: ADD_ELSE "vEvtMplxTaskDeleted" */

            /* MCDC Test Point: STD "vEvtMplxTaskDeleted" */
        }

        /* Remove the event multiplex object list item from the task's list of event
         * multiplex objects it owns. */
        vListRemove( &( pxEvtMplxObject->xEvtMplxListItem ) );

        /* Break the link between this event multiplex object and the task that owns
         * it. */
        pxEvtMplxObject->pxOwnerTCB = NULL;

        /* Set the uxOwnerTCBMirror member so that the event multiplex object is
         * invalid. */
        pxEvtMplxObject->uxOwnerTCBMirror = 0U;

        /* Get the new head entry in the list of event multiplex objects owned by the
         * task that is being deleted. */
        pxOwnedEvtMplxObjectListItem = listGET_HEAD_ENTRY( pxEvtMplxObjectsList );

        /* MCDC Test Point: WHILE_INTERNAL "vEvtMplxTaskDeleted" "( ( const xMiniListItem * ) pxOwnedEvtMplxObjectListItem != pxOwnedEvtMplxObjectListEnd )" */
    }
    ( void ) pxTCB;
}
/*---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * Private Function Definitions
 *---------------------------------------------------------------------------*/

KERNEL_CREATE_FUNCTION static portBaseType prvCheckEvtMplxCreateParameters( portInt8Type *pcEvtMplxMemoryBuffer,
                                                                            portUnsignedBaseType uxBufferLengthInBytes,
                                                                            portUnsignedBaseType uxMaximumRegisteredObjectEvents,
                                                                            portTaskHandleType xOwnerTaskHandle,
                                                                            const evtMplxHandleType *pxEvtMplxHandle )
{
    portBaseType xResult = pdPASS;

    /* Check the input parameters. */
    if( NULL == pcEvtMplxMemoryBuffer )
    {
        /* A valid pointer to a memory buffer must be supplied. */
        xResult = errNULL_PARAMETER_SUPPLIED;

        /* MCDC Test Point: STD_IF "prvCheckEvtMplxCreateParameters" */
    }
    else if( 0U != ( ( ( portDataAddressType ) pcEvtMplxMemoryBuffer ) & portWORD_ALIGNMENT_MASK ) )
    {
        /* The buffer must be aligned correctly as it will be cast to an
         * evtMplxType structure. */
        xResult = errINVALID_ALIGNMENT;

        /* MCDC Test Point: STD_ELSE_IF "prvCheckEvtMplxCreateParameters" */
    }
    else if( 0U == uxMaximumRegisteredObjectEvents )
    {
        /* The buffer must have space for at least one object-event control
         * structure. */
        xResult = errINVALID_PARAMETERS;

        /* MCDC Test Point: STD_ELSE_IF "prvCheckEvtMplxCreateParameters" */
    }
    else if( ( ( portUnsignedBaseType ) sizeof( evtMplxType ) + ( ( portUnsignedBaseType ) sizeof( evtMplxObjectEventControlType ) * uxMaximumRegisteredObjectEvents ) ) != uxBufferLengthInBytes )
    {
        /* The buffer must be sized correctly. */
        xResult = errINVALID_BUFFER_SIZE;

        /* MCDC Test Point: STD_ELSE_IF "prvCheckEvtMplxCreateParameters" */
    }
    else if( NULL == pxEvtMplxHandle )
    {
        /* A valid pointer to an event multiplex handle must be supplied. */
        xResult = errNULL_PARAMETER_SUPPLIED;

        /* MCDC Test Point: STD_ELSE_IF "prvCheckEvtMplxCreateParameters" */
    }
    else
    {
        /* Has the scheduler started? */
        if( pdFALSE == xTaskIsSchedulerStartedKrnl() )
        {
            /* The scheduler has not yet started, so check that a NULL pointer
             * has not been supplied. */
            if( NULL == xOwnerTaskHandle )
            {
                xResult = errNULL_PARAMETER_SUPPLIED;

                /* MCDC Test Point: STD_IF "prvCheckEvtMplxCreateParameters" */
            }
            /* MCDC Test Point: ADD_ELSE "prvCheckEvtMplxCreateParameters" */

            /* MCDC Test Point: STD_IF "prvCheckEvtMplxCreateParameters" */
        }
        else
        {
            /* The scheduler has been started, therefore the only valid values
             * for xOwnerTaskHandle are NULL (taken to mean the current task)
             * and the handle of the current task. */
            if( NULL != xOwnerTaskHandle )
            {
                if( pxCurrentTCB != ( xTCB * ) xOwnerTaskHandle )
                {
                    /* Report the error. */
                    xResult = errINVALID_TASK_HANDLE;

                    /* MCDC Test Point: STD_IF "prvCheckEvtMplxCreateParameters" */
                }
                /* MCDC Test Point: ADD_ELSE "prvCheckEvtMplxCreateParameters" */

                /* MCDC Test Point: STD_IF "prvCheckEvtMplxCreateParameters" */
            }
            /* MCDC Test Point: ADD_ELSE "prvCheckEvtMplxCreateParameters" */

            /* MCDC Test Point: STD_ELSE "prvCheckEvtMplxCreateParameters" */
        }

        /* MCDC Test Point: STD_ELSE "prvCheckEvtMplxCreateParameters" */
    }

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvCheckEvtMplxConfigureParameters( const evtMplxType *pxEvtMplxObject,
                                                                        const void *pvTargetObjectHandle,
                                                                        portUnsignedBaseType uxEvents )
{
    portBaseType xResult;

    /* Has the scheduler started? */
    if( pdFALSE == xTaskIsSchedulerStartedKrnl() )
    {
        /* An event multiplex object is tied to the pxCurrentTCB, therefore it cannot
         * be configured until the scheduler is running. */
        xResult = errSCHEDULER_IS_NOT_RUNNING;

        /* MCDC Test Point: STD_IF "prvCheckEvtMplxConfigureParameters" */
    }
    else if( NULL == pxEvtMplxObject )
    {
        /* A valid pointer to an event multiplex object must be supplied. */
        xResult = errNULL_PARAMETER_SUPPLIED;

        /* MCDC Test Point: STD_ELSE_IF "prvCheckEvtMplxConfigureParameters" */
    }
    else if( NULL == pvTargetObjectHandle )
    {
        /* A valid object handle must be supplied. */
        xResult = errNULL_PARAMETER_SUPPLIED;

        /* MCDC Test Point: STD_ELSE_IF "prvCheckEvtMplxConfigureParameters" */
    }
    else if( evtmplxNO_EVENTS == uxEvents )
    {
        /* At least one event should be specified. */
        xResult = errINVALID_EVT_MPLX_EVENTS;

        /* MCDC Test Point: STD_ELSE_IF "prvCheckEvtMplxConfigureParameters" */
    }
    /* Is this a valid event multiplex object? */
    else if( ( portDataAddressType )( pxEvtMplxObject->pxOwnerTCB ) != ( portDataAddressType ) ~( pxEvtMplxObject->uxOwnerTCBMirror ) )
    {
        /* A pointer to a valid event multiplex object must be supplied. */
        xResult = errINVALID_EVT_MPLX_HANDLE;

        /* MCDC Test Point: STD_ELSE_IF "prvCheckEvtMplxConfigureParameters" */
    }
    /* Is this event multiplex object owned by the calling task? */
    else if( pxCurrentTCB != pxEvtMplxObject->pxOwnerTCB )
    {
        /* The calling task must own this event multiplex object. */
        xResult = errINVALID_EVT_MPLX_HANDLE;

        /* MCDC Test Point: STD_ELSE_IF "prvCheckEvtMplxConfigureParameters" */
    }
    else
    {
        /* The configuration parameters are valid. */
        xResult = pdPASS;

        /* MCDC Test Point: STD_ELSE "prvCheckEvtMplxConfigureParameters" */
    }

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvGetObjectEventIndex( const evtMplxType *pxEvtMplxObject,
                                                            const void *pvTargetObjectHandle,
                                                            portUnsignedBaseType *puxObjectEventIndex )
{
    portBaseType xResult = pdFAIL;
    portUnsignedBaseType uxIndex;
    portUnsignedBaseType uxNumberOfObjectEvents = pxEvtMplxObject->uxMaximumRegisteredObjectEvents;
    evtMplxObjectEventControlType *pxObjectEvent;

    /* Set the return index to the default value. */
    *puxObjectEventIndex = ( portUnsignedBaseType ) evtmplxINVALID_OBJECT_EVENT_INDEX;

    /* Search through the array of object-events belonging to the event multiplex
     * object in order to determine the index of the object-events structure
     * that relates to the specified object handle. */
    for( uxIndex = 0U; uxIndex < uxNumberOfObjectEvents; uxIndex++ )
    {
        /* Does this element relate to the specified object handle? */
        pxObjectEvent = &( pxEvtMplxObject->paxRegisteredObjectEvents[ uxIndex ] );
        if( pvTargetObjectHandle == pxObjectEvent->xObjectEvent.pvObjectHandle )
        {
            /* Return the index of this element. */
            *puxObjectEventIndex = uxIndex;
            xResult = pdPASS;

            /* MCDC Test Point: STD_IF "prvGetObjectEventIndex" */

            /* Exit the loop now that the required element has been
             * identified. */
            break;
        }
        /* Has the first unused element been located? */
        else if( ( portUnsignedBaseType ) evtmplxINVALID_OBJECT_EVENT_INDEX == *puxObjectEventIndex )
        {
            /* Is this element currently unused? */
            if( NULL == pxObjectEvent->xObjectEvent.pvObjectHandle )
            {
                /* Set the index of the first unused element. */
                *puxObjectEventIndex = uxIndex;

                /* MCDC Test Point: STD_IF "prvGetObjectEventIndex" */
            }
            /* MCDC Test Point: ADD_ELSE "prvGetObjectEventIndex" */

            /* MCDC Test Point: STD_ELSE_IF "prvGetObjectEventIndex" */
        }
        else
        {
            /* This clause is deliberately left empty. */

            /* MCDC Test Point: STD_ELSE "prvGetObjectEventIndex" */
        }

        /* MCDC Test Point: STD "prvGetObjectEventIndex" */
    }

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvUpdateObjectList( const xList *pxRegisteredEvtMplxObjects, portUnsignedBaseType uxUpdatedStatus )
{
    portBaseType xContextSwitchRequired = pdFALSE;
    const xMiniListItem *pxEvtMplxObjectListEnd;
    xListItem *pxEvtMplxObjectListItem;

    /* THIS FUNCTION MUST BE CALLED FROM WITHIN A CRITICAL SECTION. */

    /* Obtain the end of list marker for the list of registered event
     * multiplex objects. */
    pxEvtMplxObjectListEnd = listGET_END_MARKER( pxRegisteredEvtMplxObjects );

    /* Obtain the head entry in the list of registered event multiplex
     * objects. */
    pxEvtMplxObjectListItem = listGET_HEAD_ENTRY( pxRegisteredEvtMplxObjects );

    /* Loop through the registered event multiplex objects (the calling function has
     * already determined that there is at least one), updating the
     * status of the objects. */
    do
    {
        /* Update the status of the event multiplex object-event. */
        if( pdTRUE == prvUpdateTargetObjectStatus( pxEvtMplxObjectListItem,
                                                   uxUpdatedStatus ) )
        {
            /* A higher priority task has been unblocked. */
            xContextSwitchRequired = pdTRUE;

            /* MCDC Test Point: STD_IF "prvUpdateObjectList" */
        }
        /* MCDC Test Point: ADD_ELSE "prvUpdateObjectList" */

        /* Get the next event multiplex object list item. */
        pxEvtMplxObjectListItem = listGET_NEXT( pxEvtMplxObjectListItem );

        /* MCDC Test Point: WHILE_INTERNAL "prvUpdateObjectList" "( ( const xMiniListItem * ) pxEvtMplxObjectListItem != pxEvtMplxObjectListEnd )" */
    } while( ( const xMiniListItem * ) pxEvtMplxObjectListItem != pxEvtMplxObjectListEnd );

    return xContextSwitchRequired;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvUpdateTargetObjectStatus( const xListItem *pxObjectEventListItem,
                                                                 portUnsignedBaseType uxCurrentEvents )
{
    evtMplxType *pxEvtMplxObject;
    portUnsignedBaseType uxObjectEventIndex;
    portBaseType xSwitchRequired = pdFALSE;

    /* THIS FUNCTION MUST BE CALLED FROM WITHIN A CRITICAL SECTION. */

    /* Obtain the handle of the event multiplex object from the object-event list
     * item. */
    pxEvtMplxObject = ( evtMplxType * ) listGET_LIST_ITEM_OWNER( pxObjectEventListItem );

    /* Obtain the index into the object-events array to update from the
     * object-event list item. */
    uxObjectEventIndex = ( portUnsignedBaseType ) listGET_LIST_ITEM_VALUE( pxObjectEventListItem );

    /* If this call to prvUpdateTargetObjectStatus() has been made due to
     * a task notification but the event multiplex object isn't interested in the
     * notification, then the uxObjectEventIndex will not be valid. */
    if( ( portUnsignedBaseType ) evtmplxINVALID_OBJECT_EVENT_INDEX != uxObjectEventIndex )
    {
        /* Update the event multiplex object. */
        pxEvtMplxObject->paxRegisteredObjectEvents[ uxObjectEventIndex ].uxCurrentEvents = uxCurrentEvents;

        /* If the task that owns the event multiplex object is currently blocked
         * waiting for object-events, unblock it now. */
        if( pdTRUE == pxEvtMplxObject->xTaskIsBlocked )
        {
            if( pdFALSE == xTaskIsTaskSuspended( pxEvtMplxObject->pxOwnerTCB ) )
            {
                /* Unblock the task and return it to the appropriate ready list. */
                xSwitchRequired = xTaskMoveTaskToReadyList( pxEvtMplxObject->pxOwnerTCB );

                /* Clear the 'task is blocked' flag. */
                pxEvtMplxObject->xTaskIsBlocked = pdFALSE;

                /* MCDC Test Point: STD_IF "prvUpdateTargetObjectStatus" */
            }
            /* MCDC Test Point: ADD_ELSE "prvUpdateTargetObjectStatus" */

            /* MCDC Test Point: STD_IF "prvUpdateTargetObjectStatus" */
        }
        /* MCDC Test Point: ADD_ELSE "prvUpdateTargetObjectStatus" */

        /* MCDC Test Point: STD_IF "prvUpdateTargetObjectStatus" */
    }
    /* MCDC Test Point: ADD_ELSE "prvUpdateTargetObjectStatus" */

    return xSwitchRequired;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvRegisterEvtMplxObject( void *pvTargetObjectHandle,
                                                              portUnsignedBaseType uxEvents,
                                                              xListItem *pxEvtMplxObjectEventListItem )
{
    portBaseType xResult;
    portUnsignedBaseType uxCurrentEvents = evtmplxNO_EVENTS;

    /* Do the supplied events relate to a queue? */
    if( ( uxEvents & evtmplxALL_QUEUE_EVENTS ) != evtmplxNO_EVENTS )
    {
        /* Check that no spurious events have been requested. */
        if( evtmplxNO_EVENTS == ( uxEvents & ( portUnsignedBaseType ) ~evtmplxALL_QUEUE_EVENTS ) )
        {
            /* Register the event multiplex object with the specified queue. */
            xResult = prvQueueAddEvtMplxListItem( pvTargetObjectHandle,
                                                  pxEvtMplxObjectEventListItem );

            /* MCDC Test Point: STD_IF "prvRegisterEvtMplxObject" */
        }
        else
        {
            /* An invalid combination of events have been specified. */
            xResult = errINVALID_EVT_MPLX_EVENTS;

            /* MCDC Test Point: STD_ELSE "prvRegisterEvtMplxObject" */
        }

        /* MCDC Test Point: STD_IF "prvRegisterEvtMplxObject" */
    }
    /* Is the event a task notification? */
    else if( evtmplxTASK_NOTIFICATION_RECEIVED == uxEvents )
    {
        /* Task notifications are a special case as the task that owns the event
         * multiplex object keeps a list of all event multiplex objects it owns, not just
         * those that are interested in task notifications. */

        /* Retrieve the current notification status for the specified task. Note
         * that this includes checking that the supplied task handle is that of
         * the currently running task. */
        xResult = prvQueryTaskNotificationStatus( pvTargetObjectHandle,
                                                  &uxCurrentEvents );
        if( pdPASS == xResult )
        {
            /* Update the the current events in the specified object-event.
             * Note: As this function is being called from within
             * xEvtMplxAddObjectEventsKrnl(), it will not cause the current task
             * to be unblocked, so the return value can be ignored. */
            ( void ) prvUpdateTargetObjectStatus( pxEvtMplxObjectEventListItem,
                                                  uxCurrentEvents );

            /* MCDC Test Point: STD_IF "prvRegisterEvtMplxObject" */
        }
        /* MCDC Test Point: ADD_ELSE "prvRegisterEvtMplxObject" */

        /* MCDC Test Point: STD_ELSE_IF "prvRegisterEvtMplxObject" */
    }
    /* Is the event the setting of bits in an event group? */
    else if( evtmplxEVENT_GROUP_BITS_SET == uxEvents )
    {
        /* Register the event multiplex object with the specified event group. */
        xResult = prvEventGroupAddEvtMplxListItem( pvTargetObjectHandle,
                                                   pxEvtMplxObjectEventListItem );

        /* MCDC Test Point: STD_ELSE_IF "prvRegisterEvtMplxObject" */
    }
    else
    {
        /* An invalid set of events have been specified. */
        xResult = errINVALID_EVT_MPLX_EVENTS;

        /* MCDC Test Point: STD_ELSE "prvRegisterEvtMplxObject" */
    }

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvGetOccurredObjectEvents( evtMplxType *pxEvtMplxObject,
                                                                evtMplxObjectEventsType axObjectEvents[],
                                                                portUnsignedBaseType uxObjectEventsArraySize,
                                                                portUnsignedBaseType *puxNumberOfObjectEvents )
{
    portBaseType xResult = errEVT_MPLX_NO_EVENTS_OCCURRED;
    portUnsignedBaseType uxEvtMplxObjectIndex;
    portUnsignedBaseType uxNumberOfObjectEvents = pxEvtMplxObject->uxMaximumRegisteredObjectEvents;
    evtMplxObjectEventControlType *pxObjectEvent;
    portUnsignedBaseType uxObjectEventArrayIndex = 0U;
    evtMplxObjectEventsType uxOccurredObjectEvent;

    /* Loop through the object-events associated with the event multiplex object to
     * determine if any have occurred - if any have, copy as many as possible
     * into the supplied array. */
    for( uxEvtMplxObjectIndex = 0U; uxEvtMplxObjectIndex < uxNumberOfObjectEvents; uxEvtMplxObjectIndex++ )
    {
        /* Have any of the events of interest associated with this object
         * occurred? */
        pxObjectEvent = &( pxEvtMplxObject->paxRegisteredObjectEvents[ uxEvtMplxObjectIndex ] );
        uxOccurredObjectEvent.uxEvents = pxObjectEvent->uxCurrentEvents;
        uxOccurredObjectEvent.uxEvents &= pxObjectEvent->xObjectEvent.uxEvents;

        /* A special case is if this object-event relates to an event group that
         * has been deleted. */
        if( evtmplxEVENT_GROUP_DELETED == pxObjectEvent->uxCurrentEvents )
        {
            /* Free the element in the object-events array for this object. */
            prvFreeObjectEvent( pxEvtMplxObject, pxObjectEvent );

            /* Report the error and exit the loop. */
            xResult = errEVENT_GROUP_DELETED;

            /* MCDC Test Point: STD_IF "prvGetOccurredObjectEvents" */
            break;
        }
        else if( uxOccurredObjectEvent.uxEvents != evtmplxNO_EVENTS )
        {
            /* Report the events of interest to the caller. */
            uxOccurredObjectEvent.pvObjectHandle = pxObjectEvent->xObjectEvent.pvObjectHandle;
            if( pdPASS != portCOPY_DATA_TO_TASK( &axObjectEvents[ uxObjectEventArrayIndex ],
                                                 &uxOccurredObjectEvent,
                                                 ( portUnsignedBaseType ) sizeof( evtMplxObjectEventsType ) ) )
            {
                /* Report the error and exit the loop. */
                xResult = errINVALID_DATA_RANGE;

                /* MCDC Test Point: STD_IF "prvGetOccurredObjectEvents" */
                break;
            }
            else
            {
                /* Set return value to report success. */
                xResult = pdPASS;

                /* MCDC Test Point: STD_ELSE "prvGetOccurredObjectEvents" */
            }

            /* Increment the index into the specified array. */
            uxObjectEventArrayIndex++;

            /* If the supplied array is now full, there is no point looking
             * for any more object-events. */
            if( uxObjectEventArrayIndex >= uxObjectEventsArraySize )
            {
                /* MCDC Test Point: STD_IF "prvGetOccurredObjectEvents" */
                break;
            }
            /* MCDC Test Point: ADD_ELSE "prvGetOccurredObjectEvents" */

            /* MCDC Test Point: STD_ELSE_IF "prvGetOccurredObjectEvents" */
        }
        else
        {
            /* Continue with the next object-event. */

            /* MCDC Test Point: STD_ELSE "prvGetOccurredObjectEvents" */
        }

        /* MCDC Test Point: STD "prvGetOccurredObjectEvents" */
    }

    if( pdPASS == xResult )
    {
        /* Report the number of object-events that have occurred. */
        if( pdPASS != portCOPY_DATA_TO_TASK( puxNumberOfObjectEvents,
                                             &uxObjectEventArrayIndex,
                                             ( portUnsignedBaseType ) sizeof( portUnsignedBaseType ) ) )
        {
            /* Report the error. */
            xResult = errINVALID_DATA_RANGE;

            /* MCDC Test Point: STD_IF "prvGetOccurredObjectEvents" */
        }
        /* MCDC Test Point: ADD_ELSE "prvGetOccurredObjectEvents" */

        /* MCDC Test Point: STD_IF "prvGetOccurredObjectEvents" */
    }
    /* MCDC Test Point: ADD_ELSE "prvGetOccurredObjectEvents" */

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvQueueAddEvtMplxListItem( xQueueHandle xQueue,
                                                                xListItem *pxEvtMplxObjectEventListItem )
{
    portBaseType xResult;
    /* Cast param 'xQueueHandle xQueue' to xQUEUE * type. */
    xQUEUE *pxQueue = ( xQUEUE * ) xQueue;
    portUnsignedBaseType uxCurrentEvents;

    /* THIS FUNCTION MUST BE CALLED FROM WITHIN A CRITICAL SECTION. */

    /* Check that a valid queue handle has been supplied. */
    if( xQueueIsQueueValid( pxQueue ) == pdFALSE )
    {
        xResult = errINVALID_QUEUE_HANDLE;

        /* MCDC Test Point: STD_IF "prvQueueAddEvtMplxListItem" */
    }
    else
    {
        /* A valid queue handle has been supplied. */
        xResult = pdPASS;

        /* Add the specified event multiplex object to the list of registered event
         * multiplex objects. */
        vListInsertEnd( &( pxQueue->xRegisteredEvtMplxObjects ),
                        pxEvtMplxObjectEventListItem );


        uxCurrentEvents = prvGetEvtMplxQueueStatus( pxQueue );


        /* Update the the status of the queue in the event multiplex object.
         * Note: This function is called from within xEvtMplxAddObjectEventsKrnl(),
         * therefore it will not cause the owner task to be unblocked. */
        ( void ) prvUpdateTargetObjectStatus( pxEvtMplxObjectEventListItem,
                                              uxCurrentEvents );

        /* MCDC Test Point: STD_ELSE "prvQueueAddEvtMplxListItem" */
    }

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvTaskAddEvtMplxListItem( xTCB *pxTCB,
                                                               xListItem *pxEvtMplxListItem )
{
    portBaseType xResult;

    /* THIS FUNCTION MUST BE CALLED FROM WITHIN A CRITICAL SECTION. */

    /* Check that the TCB is valid. */
    if( xPortIsTaskHandleValid( pxTCB ) == pdFALSE )
    {
        xResult = errINVALID_TASK_HANDLE;

        /* MCDC Test Point: STD_IF "prvTaskAddEvtMplxListItem" */
    }
    else
    {
        /* A valid TCB has been supplied. */
        xResult = pdPASS;

        /* Add the specified event multiplex list item to the list of event multiplex
         * objects owned by this task. */
        vListInsertEnd( &( pxTCB->xEvtMplxObjectsList ),
                        pxEvtMplxListItem );

        /* MCDC Test Point: STD_ELSE "prvTaskAddEvtMplxListItem" */
    }

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvEventGroupAddEvtMplxListItem( eventGroupHandleType xEventGroupHandle,
                                                                     xListItem *pxEvtMplxObjectEventListItem )
{
    portBaseType xResult;
    eventGroupType *pxEventGroup;
    portUnsignedBaseType uxCurrentEvents;

    /* THIS FUNCTION MUST BE CALLED FROM WITHIN A CRITICAL SECTION. */

    /* Obtain access to the Event Group structure. */
    pxEventGroup = ( eventGroupType * ) xEventGroupHandle;

    /* Check that handle of a valid event group has been supplied. */
    if( xEventGroupIsEventGroupHandleValid( pxEventGroup ) == pdFALSE )
    {
        /* A valid Event Group handle must be supplied. */
        xResult = errINVALID_EVENT_GROUP_HANDLE;

        /* MCDC Test Point: STD_IF "prvEventGroupAddEvtMplxListItem" */
    }
    else
    {
        /* The handle of a valid event group has been supplied. */
        xResult = pdPASS;

        /* Add the specified event multiplex object to the list of registered event
         * multiplex objects. */
        vListInsertEnd( &( pxEventGroup->xRegisteredEvtMplxObjects ),
                        pxEvtMplxObjectEventListItem );

        uxCurrentEvents = prvAreAnyEventGroupBitsSet( pxEventGroup );

        /* Update the the status of the event group in the event multiplex object.
         * Note: This function is called from within xEvtMplxAddObjectEventsKrnl(),
         * therefore it will not cause the owner task to be unblocked. */
        ( void ) prvUpdateTargetObjectStatus( pxEvtMplxObjectEventListItem,
                                              uxCurrentEvents );

        /* MCDC Test Point: STD_ELSE "prvEventGroupAddEvtMplxListItem" */
    }

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static void prvFreeObjectEvent( evtMplxType *pxEvtMplxObject,
                                                evtMplxObjectEventControlType *pxObjectEventControl )
{
    /* Free the element in the object-events array for this object. */
    pxObjectEventControl->xObjectEvent.pvObjectHandle = NULL;
    pxObjectEventControl->xObjectEvent.uxEvents = evtmplxNO_EVENTS;
    pxObjectEventControl->uxCurrentEvents = evtmplxNO_EVENTS;

    /* Decrement the number of registered object-events. */
    pxEvtMplxObject->uxNumberOfRegisteredObjectEvents--;

    /* MCDC Test Point: STD "prvFreeObjectEvent" */
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvQueryTaskNotificationStatus( portTaskHandleType xTask,
                                                                    portUnsignedBaseType *puxCurrentEvents )
{
    portBaseType xResult;
    xTCB *pxTCB;

    /* THIS FUNCTION MUST BE CALLED FROM WITHIN A CRITICAL SECTION. */

    /* Retrieve the TCB from the task handle - this is guaranteed to be
     * non-NULL. */
    taskGET_TCB_FROM_HANDLE( xTask, pxTCB );

    /* Check that this is the TCB of the current task. */
    if( pxTCB != pxCurrentTCB )
    {
        xResult = errINVALID_TASK_HANDLE;

        /* MCDC Test Point: STD_IF "prvQueryTaskNotificationStatus" */
    }
    else
    {
        /* This is the TCB of the current task. */
        xResult = pdPASS;

        /* Is there a task notification available? */
        if( taskNOTIFICATION_NOTIFIED == pxTCB->xNotifyState )
        {
            *puxCurrentEvents = evtmplxTASK_NOTIFICATION_RECEIVED;

            /* MCDC Test Point: STD_IF "prvQueryTaskNotificationStatus" */
        }
        else
        {
            *puxCurrentEvents = evtmplxNO_EVENTS;

            /* MCDC Test Point: STD_ELSE "prvQueryTaskNotificationStatus" */
        }

        /* MCDC Test Point: STD_ELSE "prvQueryTaskNotificationStatus" */
    }

    return xResult;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portUnsignedBaseType prvGetEvtMplxQueueStatus( const xQUEUE *const pxQueue )
{
    portUnsignedBaseType uxStatus = 0U;

    /* Is there a message available to receive? */
    if( pxQueue->uxItemsWaiting > 0U )
    {
        uxStatus |= evtmplxQUEUE_MESSAGE_WAITING;

        /* MCDC Test Point: STD_IF "prvGetEvtMplxQueueStatus" */
    }
    /* MCDC Test Point: ADD_ELSE "prvGetEvtMplxQueueStatus" */

    /* Is there space in the queue to send another message? */
    if( pxQueue->uxItemsWaiting < pxQueue->uxMaxNumberOfItems )
    {
        uxStatus |= evtmplxQUEUE_SPACE_AVAILABLE;

        /* MCDC Test Point: STD_IF "prvGetEvtMplxQueueStatus" */
    }
    /* MCDC Test Point: ADD_ELSE "prvGetEvtMplxQueueStatus" */

    return uxStatus;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portUnsignedBaseType prvAreAnyEventGroupBitsSet( const eventGroupType *pxEventGroup )
{
    portUnsignedBaseType uxCurrentEvents;

    /* Are there any event bits set in this event group? */
    if( evgrpNO_EVENT_BITS_SET != ( pxEventGroup->xEventBits & ~evgrpEVENT_BITS_CONTROL_BYTES ) )
    {
        uxCurrentEvents = evtmplxEVENT_GROUP_BITS_SET;

        /* MCDC Test Point: STD_IF "prvAreAnyEventGroupBitsSet" */
    }
    else
    {
        /* There are no event bits set in this event group. */
        uxCurrentEvents = evtmplxNO_EVENTS;

        /* MCDC Test Point: STD_ELSE "prvAreAnyEventGroupBitsSet" */
    }

    return uxCurrentEvents;
}
/*---------------------------------------------------------------------------*/

KERNEL_FUNCTION static portBaseType prvEventGroupDeleted( xListItem *pxObjectEventListItem )
{
    evtMplxType *pxEvtMplxObject;
    portUnsignedBaseType uxObjectEventIndex;
    evtMplxObjectEventControlType *pxObjectEvent;
    portBaseType xSwitchRequired;

    /* THIS FUNCTION MUST BE CALLED FROM WITHIN A CRITICAL SECTION. */

    /* Obtain the handle of the event multiplex object from the object-event list
     * item. */
    pxEvtMplxObject = ( evtMplxType * ) listGET_LIST_ITEM_OWNER( pxObjectEventListItem );

    /* Obtain the index into the object-events array to update from the
     * object-event list item. */
    uxObjectEventIndex = ( portUnsignedBaseType ) listGET_LIST_ITEM_VALUE( pxObjectEventListItem );

    /* Assign a pointer to the index to be updated. */
    pxObjectEvent = &( pxEvtMplxObject->paxRegisteredObjectEvents[ uxObjectEventIndex ] );

    /* Remove the object event list item from the target object's event list. */
    vListRemove( pxObjectEventListItem );

    /* If the task that owns the event multiplex object is not currently blocked
     * waiting for object-events, the event group can be removed from the array
     * of object-events now. */
    if( pdFALSE == pxEvtMplxObject->xTaskIsBlocked )
    {
        /* Free the element in the object-events array for this object. */
        prvFreeObjectEvent( pxEvtMplxObject, pxObjectEvent );

        /* The task is not blocked, therefore no switch is required. */
        xSwitchRequired = pdFALSE;

        /* MCDC Test Point: STD_IF "prvEventGroupDeleted" */
    }
    else
    {
        /* Update the status of the event group object-event to indicate that
         * the event group has been deleted. */
        pxObjectEvent->uxCurrentEvents = evtmplxEVENT_GROUP_DELETED;

        /* Unblock the task and return it to the appropriate ready list. */
        xSwitchRequired = xTaskMoveTaskToReadyList( pxEvtMplxObject->pxOwnerTCB );

        /* Clear the 'task is blocked' flag. */
        pxEvtMplxObject->xTaskIsBlocked = pdFALSE;

        /* MCDC Test Point: STD_ELSE "prvEventGroupDeleted" */
    }

    return xSwitchRequired;
}

/*-----------------------------------------------------------------------------
 * Weak stub Function Definitions
 *---------------------------------------------------------------------------*/

KERNEL_FUNCTION portWEAK_FUNCTION portBaseType xEventGroupIsEventGroupHandleValid( const eventGroupType *pxEventGroup )
{
    /* MCDC Test Point: STD "WEAK_xEventGroupIsEventGroupHandleValid" */

    ( void ) pxEventGroup;
    return pdFALSE;
}
/*---------------------------------------------------------------------------*/

#ifdef SAFERTOS_TEST
    #include "SectionLocationCheckList_evtmplxc.h"

    #ifdef SAFERTOS_MODULE_TEST
        #include "EvtMplxCTestHeaders.h"
        #include "EvtMplxCTest.h"
    #endif
#endif

