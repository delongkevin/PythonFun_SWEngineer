/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#ifndef API_WRAPPER_H
#define API_WRAPPER_H

#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------
 * API Wrapper version number
 *---------------------------------------------------------------------------*/

#define safertosAPI_WRAPPER_MAJOR_VERSION   ( 1 )
#define safertosAPI_WRAPPER_MINOR_VERSION   ( 0 )
#define safertosAPI_WRAPPER_RC_VERSION      ( 1 )

/*----------------------------------------------------------------------------
 * API Wrapper Definitions
 *--------------------------------------------------------------------------*/

#define xTaskGetTickCount               xTaskGetTickCountKrnl
#define xTaskGetCurrentTaskHandle       xTaskGetCurrentTaskHandleKrnl
#define xTaskCreate                     xTaskCreateKrnl
#define xTaskDelete                     xTaskDeleteKrnl
#define xTaskDelay                      xTaskDelayKrnl
#define xTaskDelayUntil                 xTaskDelayUntilKrnl
#define xTaskPriorityGet                xTaskPriorityGetKrnl
#define xTaskPrioritySet                xTaskPrioritySetKrnl
#define xTaskSuspend                    xTaskSuspendKrnl
#define xTaskResume                     xTaskResumeKrnl
#define xTaskStartScheduler             xTaskStartSchedulerKrnl
#define vTaskSuspendScheduler           vTaskSuspendSchedulerKrnl
#define xTaskResumeScheduler            xTaskResumeSchedulerKrnl
#define xTaskInitializeScheduler        xTaskInitializeSchedulerKrnl
#define xTaskIsSchedulerStarted         xTaskIsSchedulerStartedKrnl
#define xTaskNotifyWait                 xTaskNotifyWaitKrnl
#define xTaskNotifySend                 xTaskNotifySendKrnl
#define pvTaskTLSObjectGet              pvTaskTLSObjectGetKrnl

#define xQueueCreate                    xQueueCreateKrnl
#define xQueueSend                      xQueueSendKrnl
#define xQueueSendToFront               xQueueSendToFrontKrnl
#define xQueueReceive                   xQueueReceiveKrnl
#define xQueuePeek                      xQueuePeekKrnl
#define xQueueMessagesWaiting           xQueueMessagesWaitingKrnl

#define xTaskNotifySendFromISR          xTaskNotifySendFromISRKrnl
#define xTaskIsSchedulerStartedFromISR  xTaskIsSchedulerStartedFromISRKrnl
#define xTaskGetTickCountFromISR        xTaskGetTickCountFromISRKrnl
#define xQueueSendFromISR               xQueueSendFromISRKrnl
#define xQueueSendToFrontFromISR        xQueueSendToFrontFromISRKrnl
#define xQueueReceiveFromISR            xQueueReceiveFromISRKrnl

/*---------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif /* API_WRAPPER_H */
