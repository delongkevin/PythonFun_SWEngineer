/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court, Long Ashton
    Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

/*
    API documentation is included in the user manual.  Do not refer to this
    file for documentation.
*/

#ifndef TASK_H
#define TASK_H

#ifdef __cplusplus
extern "C" {
#endif

#include "taskAPI.h"

/*-----------------------------------------------------------------------------
 * Functions for internal use only.
 * Not to be called directly from a host application or task.
 *---------------------------------------------------------------------------*/

#define taskYIELD_WITHIN_API()                  portYIELD_WITHIN_API()

KERNEL_FUNCTION void vTaskPlaceOnEventList( xList *pxEventList, portTickType xTicksToWait );
KERNEL_FUNCTION portBaseType xTaskRemoveFromEventList( const xList *pxEventList );
KERNEL_FUNCTION void vTaskSelectNextTask( void );
KERNEL_FUNCTION portBaseType xTaskIsSchedulerSuspended( void );
KERNEL_FUNCTION void vTaskStackCheckFailed( void );
KERNEL_FUNCTION void vTaskSetTimeOut( xTimeOutType *pxTimeOut );
KERNEL_FUNCTION portBaseType xTaskCheckForTimeOut( xTimeOutType *pxTimeOut, portTickType *pxTicksToWait );
KERNEL_FUNCTION void vTaskPendYield( void );

/*
 * Set xNextTaskUnblockTime to the time at which the next Blocked state task
 * will exit the Blocked state.
 */
KERNEL_FUNCTION void vTaskResetNextTaskUnblockTime( void );

/* Returns pdTRUE if the specified task is currently in the Suspended state. */
KERNEL_FUNCTION portBaseType xTaskIsTaskSuspended( const xTCB *pxTCB );



/*
 * Place the task represented by pxTCB into the appropriate ready queue for
 * the task.  It is inserted at the end of the list.  One quirk of this is
 * that if the task being inserted is at the same priority as the currently
 * executing task, then it will only be rescheduled after the currently
 * executing task has been rescheduled.
 */
KERNEL_FUNCTION void vTaskAddTaskToReadyList( xTCB *pxTCB );


/* Place the currently executing task onto either pxDelayedTaskList or
 * pxOverflowDelayedTaskList. */
KERNEL_FUNCTION void vTaskAddCurrentTaskToDelayedList( portTickType xTicksToWait );

/* Remove the specified task from either the delayed or suspended list and add
 * it to the ready task list of the appropriate priority. Returns pdTRUE if the
 * task is of higher priority than the current task (in which case a context
 * switch is required); returns pdFALSE otherwise. */
KERNEL_FUNCTION portBaseType xTaskMoveTaskToReadyList( xTCB *pxTaskToMakeReady );

/*-----------------------------------------------------------------------------
 * Variables for internal use only.
 * Not to be accessed directly from a host application or task.
 *---------------------------------------------------------------------------*/

extern xList xReadyTasksLists[ configMAX_PRIORITIES ];
extern xList xPendingReadyList;

extern volatile portUnsignedBaseType uxMissedTicks;
extern volatile portTickType xTickCount;
extern volatile portDataAddressType xTickCountMirror;
extern volatile portTickType xNextTaskUnblockTime;


/*-----------------------------------------------------------------------------
 * TCB Related Macros.
 *---------------------------------------------------------------------------*/

/* Several functions take an portTaskHandleType parameter that can optionally be
 * NULL, where NULL is used to indicate that the handle of the currently
 * executing task should be used in place of the parameter.
 * This macro simply checks to see if the parameter is NULL and returns a
 * pointer to the appropriate TCB. */
#define taskGET_TCB_FROM_HANDLE( pxHandle, pxTCB )                                                  \
do                                                                                                  \
{                                                                                                   \
        xTCB* xTempTCB = pxCurrentTCB;                                                              \
        ( pxTCB ) = ( ( NULL == ( pxHandle ) ) ? ( xTCB * ) xTempTCB : ( xTCB * )( pxHandle ) );    \
} while( 0 )

/* The item value of the event list item is normally used to hold the priority
 * of the task to which it belongs (coded to allow it to be held in reverse
 * priority order).  However, it is occasionally borrowed for other purposes.
 * It is important its value is not updated due to a task priority change while
 * it is being used for another purpose.
 * The following bit definition is used to inform the scheduler that the value
 * should not be changed - in which case it is the responsibility of whichever
 * module is using the value to ensure it gets set back to its original value
 * when it is released. */
#define taskEVENT_LIST_ITEM_VALUE_IN_USE    ( ( portTickType ) evgrpEVENT_LIST_ITEM_VALUE_IN_USE )

#ifdef __cplusplus
}
#endif

#endif /* TASK_H */

