;    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.
;
;    This file is part of the SafeRTOS product, see projdefs.h for version number
;    information.
;
;    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
;    and is subject to the terms of the License granted to your organization,
;    including its warranties and limitations on use and distribution. It cannot be
;    copied or reproduced in any way except as permitted by the License.
;
;    Licenses authorise use by processor, compiler, business unit, and product.
;
;    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
;    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
;    Tel: +44 1275 395 600
;    Email: info@highintegritysystems.com
;    www.highintegritysystems.com
;

;
; ======== demoasm.asm ========
;
;
        .global vPortSystemCall
        .global vDemoApplicationScIncrValue
        .global ulDemoApplicationScAdd64Bit
        .global uxDemoApplicationScFourParams

;-------------------------------------------------------------------------------------------------

SYSCALL_INCREMENT_VALUE_NUMBER      .set    0
SYSCALL_ADD_64BIT_NUMBER            .set    1
SYSCALL_FOUR_PARAMS_NUMBER          .set    2

;-------------------------------------------------------------------------------------------------
; void vDemoApplicationScIncrValue( void )
;-------------------------------------------------------------------------------------------------
    .sect ".text:vDemoApplicationScIncrValue"
    .clink
vDemoApplicationScIncrValue:
    .asmfunc
            mvk64.l1    SYSCALL_INCREMENT_VALUE_NUMBER, a4  ; pass the syscall number
            b.b1        $PCR_OFFSET( vPortSystemCall )

    .endasmfunc


;-------------------------------------------------------------------------------------------------
; portUInt64Type ulDemoApplicationScAdd64Bit(  portUInt64Type uxValue  )
;-------------------------------------------------------------------------------------------------
    .sect ".text:ulDemoApplicationScAdd64Bit"
    .clink
ulDemoApplicationScAdd64Bit:
    .asmfunc
            mv.m1       a4, a5                          ; shift the value into parameter 2
            mvk64.l1    SYSCALL_ADD_64BIT_NUMBER, a4    ; pass the syscall number in parameter 1
            b.b1        $PCR_OFFSET( vPortSystemCall )

    .endasmfunc


;-------------------------------------------------------------------------------------------------
; portUnsignedBaseType uxDemoApplicationScFourParams( portUInt32Type ulArg1,
;                                                      portUInt32Type ulArg2,
;                                                      portUInt32Type ulArg3,
;                                                      portUInt32Type ulArg4 )
;-------------------------------------------------------------------------------------------------
    .sect ".text:uxDemoApplicationScFourParams"
    .clink
uxDemoApplicationScFourParams:
    .asmfunc
            mv.m1       a7, a8                          ; shift parameter 4 into parameter 5
            mv.m1       a6, a7                          ; shift parameter 3 into parameter 4
            mv.m1       a5, a6                          ; shift parameter 2 into parameter 3
            mv.m1       a4, a5                          ; shift parameter 1 into parameter 2
            mvk64.l1    SYSCALL_FOUR_PARAMS_NUMBER, a4  ; pass the syscall number in parameter 1
            b.b1        $PCR_OFFSET( vPortSystemCall )

    .endasmfunc




