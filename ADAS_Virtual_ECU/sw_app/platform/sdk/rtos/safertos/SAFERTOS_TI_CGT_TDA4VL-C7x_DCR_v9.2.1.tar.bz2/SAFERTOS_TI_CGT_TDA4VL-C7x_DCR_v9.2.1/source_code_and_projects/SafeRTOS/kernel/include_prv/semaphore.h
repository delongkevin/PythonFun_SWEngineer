/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court, Long Ashton
    Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/


#ifndef SEMAPHORE_H
#define SEMAPHORE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "semaphoreAPI.h"

/* The following macro's are part of the semaphore API however they can be
   mapped directly to the equivalent queue functions and hence are implemented
   as macro's for efficiency purposes. */

#define xSemaphoreTakeKrnl( xSemaphore, xBlockTime )                        xQueueReceiveKrnl( ( ( xQueueHandle ) ( xSemaphore ) ), NULL, ( xBlockTime ) )
#define xSemaphoreGiveKrnl( xSemaphore )                                    xQueueSendKrnl( ( ( xQueueHandle ) ( xSemaphore ) ), NULL, semSEM_GIVE_BLOCK_TIME )
#define xSemaphoreGiveFromISRKrnl( xSemaphore )                             xQueueSendFromISRKrnl( ( ( xQueueHandle ) ( xSemaphore ) ), NULL )
#define xSemaphoreTakeFromISRKrnl( xSemaphore )                             xQueueReceiveFromISRKrnl( ( ( xQueueHandle ) ( xSemaphore ) ), NULL )
#define xSemaphoreGetCountDepthKrnl( xSemaphore, puxCountDepth )            xQueueMessagesWaitingKrnl( ( ( xQueueHandle ) ( xSemaphore ) ), ( puxCountDepth ) )

#ifdef __cplusplus
}
#endif

#endif /* SEMAPHORE_H */


