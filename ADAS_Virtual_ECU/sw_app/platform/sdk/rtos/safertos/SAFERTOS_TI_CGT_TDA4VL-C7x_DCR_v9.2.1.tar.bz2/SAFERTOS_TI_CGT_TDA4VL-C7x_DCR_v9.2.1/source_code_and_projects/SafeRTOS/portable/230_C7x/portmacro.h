/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#ifndef PORTMACRO_H
#define PORTMACRO_H

#include "portCompiler.h"

#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------
 * Portable layer version number
 *---------------------------------------------------------------------------*/

/* Portable layer major version number. */
#define portPORT_ARCHITECTURE_MAJOR_VERSION ( 0 )

/* Portable layer minor version number. */
#define portPORT_ARCHITECTURE_MINOR_VERSION ( 0 )

/* Portable layer release candidate version number. */
#define portPORT_ARCHITECTURE_RC_VERSION    ( 3 )


/*-----------------------------------------------------------------------------
 * Function Attributes
 *---------------------------------------------------------------------------*/

#define portWEAK_FUNCTION               portcompilerWEAK_FUNCTION
#define portNO_INLINE_FUNC_DEF          portcompilerNO_INLINE_FUNC_DEF
#define portALWAYS_INLINE_FUNC_DEF      portcompilerALWAYS_INLINE_FUNC_DEF
#define portNO_RETURN                   portcompilerNO_RETURN

/*---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * Scheduler utilities
 *---------------------------------------------------------------------------*/

#define portSTART_FIRST_TASK()                  portapiSTART_FIRST_TASK()

#define portYIELD_WITHIN_API()                  portapiYIELD_WITHIN_API()
#define portREQUEST_YIELD()                     portapiREQUEST_YIELD()
#define portYIELD_FROM_ISR( xSwitchRequired )   portapiYIELD_FROM_ISR( xSwitchRequired )

/*-----------------------------------------------------------------------------
 * Critical Section management
 *---------------------------------------------------------------------------*/

void vPortEnterCritical( void );
void vPortExitCritical( void );

#define portENTER_CRITICAL_WITHIN_API()     vPortEnterCritical()
#define portEXIT_CRITICAL_WITHIN_API()      vPortExitCritical()

#define portTASK_HANDLE_ENTER_CRITICAL()
#define portTASK_HANDLE_EXIT_CRITICAL()

/* These macros are defined away because portTickType is atomic. */
#define portTICK_TYPE_ENTER_CRITICAL()
#define portTICK_TYPE_EXIT_CRITICAL()

/*---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * Utilities required by the common task code
 *---------------------------------------------------------------------------*/
portUnsignedBaseType xPortDisableInterrupts( void );
portUnsignedBaseType xPortEnableInterrupts( void );

#define portSET_INTERRUPT_MASK()        ( void )xPortDisableInterrupts()
#define portCLEAR_INTERRUPT_MASK()      ( void )xPortEnableInterrupts()

#define portTICK_TYPE_SET_INTERRUPT_MASK_FROM_ISR()                         ( 0U )
#define portTICK_TYPE_CLEAR_INTERRUPT_MASK_FROM_ISR( uxOriginalPriority )   ( ( void )( uxOriginalPriority ) )

/*-----------------------------------------------------------------------------
 * Architecture specifics
 *---------------------------------------------------------------------------*/

#define portMAX_LIST_ITEM_VALUE         ( ( portTickType ) 0xFFFFFFFFFFFFFFFFU )
#define portWORD_ALIGNMENT_MASK         ( ( portDataAddressType )( safertosapiWORD_ALIGNMENT - 1U ) )
#define portSTACK_ALIGNMENT_MASK        ( ( portDataAddressType )( safertosapiSTACK_ALIGNMENT - 1U ) )
#define portSTACK_IN_USE                ( ( portStackType ) 0xA5A5A5A5A5A5A5A5U )
#define portSTACK_NOT_IN_USE            ( ( portStackType ) 0x5A5A5A5A5A5A5A5AU )
#define portTICK_COUNT_NUM_BITS         ( sizeof( portTickType ) * 8U )

#define portCONTEXT_SIZE_BYTES          ( ( portUnsignedBaseType ) 496U * sizeof( portStackType ) )

#define portGET_CPU_ID()                ( 0U )

/*---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * Data copying utilities
 *---------------------------------------------------------------------------*/

/* vPortSetWordAlignedBuffer() is used for zeroing out memory blocks.
 * We know the last parameter is a constant (sizeof) and the middle parameter
 * is 0. */
void vPortSetWordAlignedBuffer( void *pvDestination, portUInt64Type ulValue, portUnsignedBaseType uxLength );

/* xPortCopyBytes copies where we do not know if bytes or words.
 * It will check if aligned and sized by words and copy by words, if so, as it
 * is faster. */
portBaseType xPortCopyBytes( void *pvDestination, const void *pvSource, portUnsignedBaseType uxLength );

/* Macros to allow data to be copied around with or without permissions checking in certain contexts */
#define portCOPY_DATA_TO_TASK                                       xPortCopyBytes
#define portCOPY_DATA_TO_NEW_TASK( handle, dest, source, length )   xPortCopyBytes( ( dest ), ( source ), ( length ) )
#define portCOPY_DATA_FROM_TASK                                     xPortCopyBytes
#define portCOPY_DATA_TO_ISR                                        xPortCopyBytes
#define portCOPY_DATA_FROM_ISR                                      xPortCopyBytes

/*---------------------------------------------------------------------------*/

/* MCDC Test Point: PROTOTYPE */

/*---------------------------------------------------------------------------*/

#ifdef __cplusplus
} /* extern C */
#endif

#endif /* PORTMACRO_H */
