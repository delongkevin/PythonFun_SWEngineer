/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#ifndef PORT_COMPILER_API_H
#define PORT_COMPILER_API_H

#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------
 * Portable layer version number
 *---------------------------------------------------------------------------*/

/* Portable layer major version number. */
#define portcompapiPORT_COMPILER_MAJOR_VERSION  ( 0 )

/* Portable layer minor version number. */
#define portcompapiPORT_COMPILER_MINOR_VERSION  ( 0 )

/* Portable layer release candidate version number. */
#define portcompapiPORT_COMPILER_RC_VERSION     ( 2 )



#ifdef __cplusplus
}
#endif

#endif /* PORT_COMPILER_API_H */
