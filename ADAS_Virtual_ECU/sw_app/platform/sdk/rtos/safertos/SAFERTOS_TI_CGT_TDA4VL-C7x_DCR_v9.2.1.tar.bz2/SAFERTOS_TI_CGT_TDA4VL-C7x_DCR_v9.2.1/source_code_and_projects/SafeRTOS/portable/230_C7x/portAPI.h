/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

#ifndef PORT_API_H
#define PORT_API_H

#include "portCompilerAPI.h"
#include "c7x.h"

#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------
 * Scheduler utilities
 *---------------------------------------------------------------------------*/

void vPortSystemCall( portBaseType uxSyscallNumber );

/* Task switch utilities. */
#define portapiREQUEST_YIELD()                                          \
do                                                                      \
{                                                                       \
    extern portBaseType xPortYieldRequired;                             \
    xPortYieldRequired = pdTRUE;                                        \
} while( 0 )
/*---------------------------------------------------------------------------*/

#define portapiYIELD_FROM_ISR()                                         \
do                                                                      \
{                                                                       \
    if( pdFALSE != xHigherPriorityTaskWoken )                           \
    {                                                                   \
        xHigherPriorityTaskWoken = pdFALSE;                             \
        portapiREQUEST_YIELD();                                         \
        /* MCDC Test Point: STD_IF_IN_MACRO "portapiYIELD_FROM_ISR" */  \
    }                                                                   \
    /* MCDC Test Point: ADD_ELSE_IN_MACRO "portapiYIELD_FROM_ISR" */    \
} while( 0 )
/*---------------------------------------------------------------------------*/

extern portUnsignedBaseType xPortEnableInterrupts( void );

#define portapiYIELD()                                                  \
do                                                                      \
{                                                                       \
    extern const portUnsignedBaseType uxPortYieldInterruptNum;          \
    __set_indexed( __EFSET, 0, 1L << uxPortYieldInterruptNum );         \
    ( void )xPortEnableInterrupts();                                    \
} while( 0 )
/*---------------------------------------------------------------------------*/

#define portapiYIELD_WITHIN_API()                   portapiYIELD()

extern void vPortStartFirstTask( void );
#define portapiSTART_FIRST_TASK()                   vPortStartFirstTask()

/*-----------------------------------------------------------------------------
 * Critical Section management
 *---------------------------------------------------------------------------*/

extern void vPortEnterCritical( void );
extern void vPortExitCritical( void );

#define portapiENTER_CRITICAL()                     vPortEnterCritical()
#define portapiEXIT_CRITICAL()                      vPortExitCritical()

/*-----------------------------------------------------------------------------
 * Utilities required by the common task code
 *---------------------------------------------------------------------------*/

extern portUnsignedBaseType xPortDisableInterrupts( void );
extern void vPortRestoreInterrupts( portUnsignedBaseType );

#define portapiSET_INTERRUPT_MASK_FROM_ISR()        ( portUnsignedBaseType ) xPortDisableInterrupts()
#define portapiCLEAR_INTERRUPT_MASK_FROM_ISR( x )   vPortRestoreInterrupts( ( portUnsignedBaseType ) x )

/*---------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif /* PORT_API_H */
