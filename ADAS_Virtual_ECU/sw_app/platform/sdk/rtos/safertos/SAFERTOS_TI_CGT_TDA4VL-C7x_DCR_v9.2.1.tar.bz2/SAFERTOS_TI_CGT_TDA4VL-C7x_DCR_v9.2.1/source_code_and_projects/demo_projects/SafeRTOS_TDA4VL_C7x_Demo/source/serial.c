/*
    Copyright (C)2006 onward WITTENSTEIN high integrity systems Limited. All rights reserved.

    This file is part of the SafeRTOS product, see projdefs.h for version number
    information.

    SafeRTOS is distributed exclusively by WITTENSTEIN high integrity systems,
    and is subject to the terms of the License granted to your organization,
    including its warranties and limitations on use and distribution. It cannot be
    copied or reproduced in any way except as permitted by the License.

    Licenses authorise use by processor, compiler, business unit, and product.

    WITTENSTEIN high integrity systems Limited, Registered Office: Brown's Court,
    Long Ashton Business Park, Yanley Lane, Long Ashton, Bristol, BS41 9LB, UK.
    Tel: +44 1275 395 600
    Email: info@highintegritysystems.com
    www.highintegritysystems.com
*/

/* Scheduler include files. */
#define COMTEST_C

#include "SafeRTOS_API.h"

/* Demo application includes. */
#include "serial.h"
#include "PortSpecifics.h"

/*-----------------------------------------------------------------------------
 * Constant definitions
 *---------------------------------------------------------------------------*/

#define serialCOM0                          ( 0 )
#define serialBAUD_RATE                     ( ( portUInt32Type ) 38400UL )
#define serialNO_BLOCK                      ( 0 )

/* Define the buffers to be used by the queues. These can hold 30 bytes. */
#define serialQUEUE_LENGTH                  ( 30 )
#define serialRX_QUEUE_BUFFER_LEN           ( serialQUEUE_LENGTH + safertosapiQUEUE_OVERHEAD_BYTES )
#define serialTX_QUEUE_BUFFER_LEN           ( serialQUEUE_LENGTH + safertosapiQUEUE_OVERHEAD_BYTES )

/*-----------------------------------------------------------------------------
 * Module scope variables
 *---------------------------------------------------------------------------*/

static portInt8Type acRxQueueBuffer[ serialRX_QUEUE_BUFFER_LEN ] __attribute__( ( aligned ( 8 ) ) ) = { 0 };
static portInt8Type acTxQueueBuffer[ serialTX_QUEUE_BUFFER_LEN ] __attribute__( ( aligned ( 8 ) ) ) = { 0 };

/* Queues used to hold received characters, and characters waiting to be
 * transmitted. */
/* Force all serial test variables into a defined section. */
portspecCOM_TEST_ZERO_DATA_SECTION static xQueueHandle xRxedChars = NULL;
portspecCOM_TEST_ZERO_DATA_SECTION static xQueueHandle xCharsForTx = NULL;
portspecCOM_TEST_ZERO_DATA_SECTION static volatile portBaseType xCharsWaitingForTx = pdFALSE;


portCharType    cRxChar;
portCharType    cTxChar;


/*-----------------------------------------------------------------------------
 * Public functions
 *---------------------------------------------------------------------------*/

void vSerialPortInit( void )
{
    portBaseType xRxQueueStatus, xTxQueueStatus;

    /* Create the queues used to hold Rx and Tx characters. */
    xRxQueueStatus = xQueueCreate( acRxQueueBuffer, serialRX_QUEUE_BUFFER_LEN, serialQUEUE_LENGTH, ( portUnsignedBaseType ) sizeof( portCharType ), &xRxedChars );
    xTxQueueStatus = xQueueCreate( acTxQueueBuffer, serialTX_QUEUE_BUFFER_LEN, serialQUEUE_LENGTH, ( portUnsignedBaseType ) sizeof( portCharType ), &xCharsForTx );

    if( ( pdPASS == xRxQueueStatus ) && ( pdPASS == xTxQueueStatus ) )
    {
        /* RX cRxChar */
    }
}
/*---------------------------------------------------------------------------*/

portBaseType xSerialGetChar( portCharType *pcRxedChar, portTickType xBlockTime )
{
    portBaseType xResult = pdFALSE;

    /* Get the next character from the buffer. Return false if no characters
     * are available, or arrive before xBlockTime expires. */
    if( xQueueReceive( xRxedChars, pcRxedChar, xBlockTime ) == pdPASS )
    {
        xResult = pdTRUE;
        /* RX cRxChar */
    }

    return xResult;
}
/*---------------------------------------------------------------------------*/

portBaseType xSerialPutChar( portCharType cOutChar, portTickType xBlockTime )
{
    portBaseType xReturn = pdPASS;

    /* Place the character in the queue of characters to be transmitted. */
    safertosapiENTER_CRITICAL();
    {
        /* Is there space to write directly to the UART? */
        if( pdFALSE == xCharsWaitingForTx )
        {
            /* There is no characters waiting to be sent, so write the
             * character directly to the UART. */
            xCharsWaitingForTx = pdTRUE;

            cTxChar = cOutChar;
            /* TX cTxChar */
        }
        else
        {
            /* We cannot write directly to the UART, so queue the character.
             * Block for a maximum of xBlockTime if there is no space in the
             * queue. It is ok to block within a critical section as each task
             * has its own critical section management. */
            if( xQueueSend( xCharsForTx, &cOutChar, xBlockTime ) != pdPASS )
            {
                xReturn = pdFAIL;
            }
            else
            {
                /* Depending on queue sizing and task prioritisation: While we
                 * were blocked waiting to post interrupts were not disabled.
                 * It is possible that the serial ISR has emptied the Tx queue,
                 * in which case we need to start the Tx off again. */
                if( pdFALSE == xCharsWaitingForTx )
                {
                    if( xQueueReceive( xCharsForTx, &cTxChar, serialNO_BLOCK ) == pdPASS )
                    {
                        xCharsWaitingForTx = pdTRUE;
                        /* TX cTxChar */
                    }
                }
            }
        }
    }
    safertosapiEXIT_CRITICAL();

    return xReturn;
}
/*---------------------------------------------------------------------------*/

void vSerialTestRxHandler( void )
{
    /* A character was received.
     * Place it in the queue of received characters. */
    ( void ) xQueueSendFromISR( xRxedChars, &cRxChar );
        /* RX cRxChar */
    /* Exit the ISR. If a task was woken by either a character being received
     * or transmitted then a context switch will occur. */
    safertosapiYIELD_FROM_ISR();
}
/*---------------------------------------------------------------------------*/

void vSerialTestTxHandler( void )
{
    /* The previous transmit has completed.
     * If there is another character in the Tx queue, send it now. */
    if( xQueueReceiveFromISR( xCharsForTx, &cTxChar ) == pdTRUE )
    {
        /* TX cTxChar */
    }
    else
    {
        /* There are no further characters queued to send. */
        xCharsWaitingForTx = pdFALSE;
    }

    /* Exit the ISR. If a task was woken by either a character being received
     * or transmitted then a context switch will occur. */
    safertosapiYIELD_FROM_ISR();
}
/*---------------------------------------------------------------------------*/
